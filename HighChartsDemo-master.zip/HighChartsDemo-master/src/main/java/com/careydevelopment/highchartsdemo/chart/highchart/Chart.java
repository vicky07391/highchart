package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Chart {

	String type = "";
	int margin = 0;
	String zoomType = "";
	Options3d options3d = new Options3d();

	public Chart() {}
	
	public Chart(String zoomType) {
		this.zoomType = zoomType;
	}
	
	public Chart(String type, Options3d options3d) {
		this.type = type;
		this.options3d = options3d;
	}
	
	public Chart(String type, int margin, Options3d options3d) {
		this.type = type;
		this.margin = margin;
		this.options3d = options3d;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	public Options3d getOptions3d() {
		return options3d;
	}

	public void setOptions3d(Options3d options3d) {
		this.options3d = options3d;
	}

	public String getZoomType() {
		return zoomType;
	}

	public void setZoomType(String zoomType) {
		this.zoomType = zoomType;
	}

	public int getMargin() {
		return margin;
	}

	public void setMargin(int margin) {
		this.margin = margin;
	}
	
	
}
