package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Column {

	String stacking = "";
	DataLabels dataLabels = new DataLabels();
	Point point = new Point();
	Integer depth = 0;
	
	public Column() {}
	
	public Column(String stacking, Integer depth) {
		this.stacking = stacking;
		this.depth = depth;
	}
	
	public Column(String stacking, Integer depth, Point point) {
		this.stacking = stacking;
		this.depth = depth;
		this.point = point;
	}
	
	public Column(String stacking, DataLabels dataLabels) {
		this.stacking = stacking;
		this.dataLabels = dataLabels;
	}
	
	public Column(String stacking, DataLabels dataLabels, Point point) {
		this.stacking = stacking;
		this.dataLabels = dataLabels;
		this.point = point;
	}

	public String getStacking() {
		return stacking;
	}

	public void setStacking(String stacking) {
		this.stacking = stacking;
	}

	public DataLabels getDataLabels() {
		return dataLabels;
	}

	public void setDataLabels(DataLabels dataLabels) {
		this.dataLabels = dataLabels;
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}

	public Integer getDepth() {
		return depth;
	}

	public void setDepth(Integer depth) {
		this.depth = depth;
	}
	
}
