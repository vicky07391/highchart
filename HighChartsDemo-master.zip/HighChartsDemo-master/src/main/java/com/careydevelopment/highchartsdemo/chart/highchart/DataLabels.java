package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class DataLabels {

	boolean enabled;
	String color = "";
	Style style = new Style();
	Integer distance = 0;
	Integer rotation = 0;
	String format = "";
	String formatter = "";
	Integer y = 0;
	Integer borderWidth = 0;
	Boolean useHTML=  false;
	
	public DataLabels() {}
	
	public DataLabels(boolean enabled, String color) {
		this.enabled = enabled;
		this.color = color;
	}
	
	public DataLabels(boolean enabled, Boolean useHTML, String format, Integer y, Integer borderWidth) {
		this.useHTML = useHTML;
		this.format = format;
		this.y = y;
		this.borderWidth = borderWidth;
		this.enabled = enabled;
	}
	
	public DataLabels(boolean enabled, Integer rotation, Integer y, String color) {
		this.enabled = enabled;
		this.color = color;
		this.y = y;
		this.rotation = rotation;
	}
	
	public DataLabels(boolean enabled, String color, String formatter) {
		this.enabled = enabled;
		this.color = color;
		this.formatter = formatter;
	}
	
	public DataLabels(boolean enabled, String color, Style style) {
		this.enabled = enabled;
		this.color = color;
		this.style = style;
	}
	
	public DataLabels(boolean enabled, String format, Integer distance) {
		this.enabled = enabled;
		this.format = format;
		this.distance = distance;
	}
	
	public DataLabels(boolean enabled, String format, Integer distance, Style style) {
		this.enabled = enabled;
		this.format = format;
		this.distance = distance;
		this.style = style;
	}
	
	public Integer getBorderWidth() {
		return borderWidth;
	}

	public void setBorderWidth(Integer borderWidth) {
		this.borderWidth = borderWidth;
	}

	public Boolean getUseHTML() {
		return useHTML;
	}

	public void setUseHTML(Boolean useHTML) {
		this.useHTML = useHTML;
	}

	public DataLabels(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Style getStyle() {
		return style;
	}

	public void setStyle(Style style) {
		this.style = style;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getFormatter() {
		return formatter;
	}

	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}

	public Integer getRotation() {
		return rotation;
	}

	public void setRotation(Integer rotation) {
		this.rotation = rotation;
	}

	public Integer getY() {
		return y;
	}

	public void setY(Integer y) {
		this.y = y;
	}
	
}
