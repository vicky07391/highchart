package com.careydevelopment.highchartsdemo.chart.highchart;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Highchart {

	Chart chart = new Chart();
	Title title = new Title();
	Subtitle subtitle = new Subtitle();
	
	Pane pane = new Pane();
	
	List<XAxis> xAxis = new ArrayList<XAxis>();
	List<YAxis> yAxis  = new ArrayList<YAxis>();
	
	PlotOptions plotOptions = new PlotOptions();
	List<Series> series = new ArrayList<>();
	Tooltip tooltip = new Tooltip();
	
	public Pane getPane() {
		return pane;
	}
	public void setPane(Pane pane) {
		this.pane = pane;
	}
	public Title getTitle() {
		return title;
	}
	public void setTitle(Title title) {
		this.title = title;
	}
	public List<XAxis> getxAxis() {
		return xAxis;
	}
	public void setxAxis(List<XAxis> xAxis) {
		this.xAxis = xAxis;
	}
	public List<YAxis> getyAxis() {
		return yAxis;
	}
	public void setyAxis(List<YAxis> yAxis) {
		this.yAxis = yAxis;
	}
	public List<Series> getSeries() {
		return series;
	}
	public void setSeries(List<Series> series) {
		this.series = series;
	}
	public Chart getChart() {
		return chart;
	}
	public void setChart(Chart chart) {
		this.chart = chart;
	}
	public PlotOptions getPlotOptions() {
		return plotOptions;
	}
	public void setPlotOptions(PlotOptions plotOptions) {
		this.plotOptions = plotOptions;
	}
	public Tooltip getTooltip() {
		return tooltip;
	}
	public void setTooltip(Tooltip tooltip) {
		this.tooltip = tooltip;
	}
	public Subtitle getSubtitle() {
		return subtitle;
	}
	public void setSubtitle(Subtitle subtitle) {
		this.subtitle = subtitle;
	}
	@Override
	public String toString() {
		return "Highchart [chart=" + chart + ", title=" + title + ", subtitle=" + subtitle + ", xAxis=" + xAxis
				+ ", yAxis=" + yAxis + ", plotOptions=" + plotOptions + ", series=" + series + ", tooltip=" + tooltip
				+ "]";
	}
	
}
