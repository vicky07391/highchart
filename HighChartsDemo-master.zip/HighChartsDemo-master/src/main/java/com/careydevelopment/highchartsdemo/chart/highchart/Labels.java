package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Labels {

	String align;
	String format;
	String formatter;
	Style style;
	
	Integer y;
	Integer step;
	Integer rotation;

	Boolean enabled;
	
	public Labels() {}
	
	public Labels(String align) {
		this.align = align;
	}
	
	public Labels(Integer y) {
		this.y = y;
	}
	
	public Labels(String format, Style style) {
		this.format = format;
		this.style = style;
	}
	
	public Labels(Integer rotation, Integer step) {
		this.rotation = rotation;
		this.step = step;
	}

	public Labels(Integer rotation, Integer step, Boolean enabled) {
		this.rotation = rotation;
		this.step = step;
		this.enabled = enabled;
	}
	
	public String getAlign() {
		return align;
	}

	public Integer getY() {
		return y;
	}

	public void setY(Integer y) {
		this.y = y;
	}

	public void setAlign(String align) {
		this.align = align;
	}

	public Integer getStep() {
		return step;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public void setStep(Integer step) {
		this.step = step;
	}

	public Integer getRotation() {
		return rotation;
	}

	public void setRotation(Integer rotation) {
		this.rotation = rotation;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public Style getStyle() {
		return style;
	}

	public void setStyle(Style style) {
		this.style = style;
	}

	public String getFormatter() {
		return formatter;
	}

	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}

	
}
