package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Options3d {

	Integer alpha = 0;
	Integer beta = 0;
	Integer depth = 0;
	boolean enabled;
	
	public Options3d() {}
	
	public Options3d(Integer alpha, boolean enabled) {
		this.alpha = alpha;
		this.enabled = enabled;
	}
	
	public Options3d(boolean enabled, Integer beta) {
		this.beta = beta;
		this.enabled = enabled;
	}
	
	public Options3d(Integer alpha, Integer beta, boolean enabled) {
		this.alpha = alpha;
		this.beta = beta;
		this.enabled = enabled;
	}
	
	public Options3d(boolean enabled, Integer alpha, Integer beta, Integer depth) {
		this.alpha = alpha;
		this.beta = beta;
		this.enabled = enabled;
		this.depth = depth;
	}

	public Integer getAlpha() {
		return alpha;
	}

	public void setAlpha(Integer alpha) {
		this.alpha = alpha;
	}

	public Integer getBeta() {
		return beta;
	}

	public void setBeta(Integer beta) {
		this.beta = beta;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Integer getDepth() {
		return depth;
	}

	public void setDepth(Integer depth) {
		this.depth = depth;
	}
	
}
