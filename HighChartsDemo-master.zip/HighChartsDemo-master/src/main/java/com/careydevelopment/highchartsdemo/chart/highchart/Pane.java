package com.careydevelopment.highchartsdemo.chart.highchart;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Pane {

	List<String> center=new ArrayList<String>();
	String size="";
	Integer startAngle=0;
	Integer endAngle=0;
	Background background=new Background();
	
	public Pane() {}
	
	public Pane(List<String> center, String size, Integer startAngle, Integer endAngle, Background background) {
		this.center = center;
		this.size = size;
		this.startAngle = startAngle;
		this.endAngle = endAngle;
		this.background = background;
	}

	public List<String> getCenter() {
		return center;
	}

	public void setCenter(List<String> center) {
		this.center = center;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public Integer getStartAngle() {
		return startAngle;
	}

	public void setStartAngle(Integer startAngle) {
		this.startAngle = startAngle;
	}

	public Integer getEndAngle() {
		return endAngle;
	}

	public void setEndAngle(Integer endAngle) {
		this.endAngle = endAngle;
	}

	public Background getBackground() {
		return background;
	}

	public void setBackground(Background background) {
		this.background = background;
	}
	
	
}
