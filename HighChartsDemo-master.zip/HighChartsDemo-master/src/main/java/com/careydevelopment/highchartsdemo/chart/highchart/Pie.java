package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Pie {

	boolean allowPointSelect;
	String cursor = "";
	Integer innerSize = 0;
	Integer depth = 0;
	DataLabels dataLabels = new DataLabels();
	Point point = new Point();
	
	public Pie() {}
	
	public Pie(boolean allowPointSelect, String cursor, Integer innerSize, Integer depth, DataLabels dataLabels, Point point) {
		this.allowPointSelect = allowPointSelect;
		this.cursor = cursor;
		this.innerSize = innerSize;
		this.depth = depth;
		this.dataLabels = dataLabels;
		this.point = point;
	}

	public Pie(boolean allowPointSelect,  Integer depth) {
		this.allowPointSelect = allowPointSelect;
		
		this.depth = depth;
		
	}

	public boolean isAllowPointSelect() {
		return allowPointSelect;
	}

	public void setAllowPointSelect(boolean allowPointSelect) {
		this.allowPointSelect = allowPointSelect;
	}

	public String getCursor() {
		return cursor;
	}

	public void setCursor(String cursor) {
		this.cursor = cursor;
	}

	public Integer getInnerSize() {
		return innerSize;
	}

	public void setInnerSize(Integer innerSize) {
		this.innerSize = innerSize;
	}

	public Integer getDepth() {
		return depth;
	}

	public void setDepth(Integer depth) {
		this.depth = depth;
	}

	public DataLabels getDataLabels() {
		return dataLabels;
	}

	public void setDataLabels(DataLabels dataLabels) {
		this.dataLabels = dataLabels;
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}
	
}
