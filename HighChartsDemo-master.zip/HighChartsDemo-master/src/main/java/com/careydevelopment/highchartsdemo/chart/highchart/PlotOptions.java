package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class PlotOptions {

	Column column = new Column();
	Pie pie = new Pie();
	Spline spline = new Spline();
	Area area = new Area();
	Line line = new Line();
	Solidgauge solidgauge = new Solidgauge();
	
	public PlotOptions() {}
	
	public PlotOptions(Solidgauge solidgauge) {
		this.solidgauge = solidgauge;
	}
	
	public PlotOptions(Column column) {
		this.column = column;
	}
	
	public PlotOptions(Pie pie) {
		this.pie = pie;
	}
	
	public PlotOptions(Spline spline) {
		this.spline = spline;
	}
	
	public PlotOptions(Area area) {
		this.area = area;
	}
	
	public PlotOptions(Line line) {
		this.line = line;
	}

	public Line getLine() {
		return line;
	}

	public void setLine(Line line) {
		this.line = line;
	}

	public Column getColumn() {
		return column;
	}

	public void setColumn(Column column) {
		this.column = column;
	}

	public Pie getPie() {
		return pie;
	}

	public Solidgauge getSolidgauge() {
		return solidgauge;
	}

	public void setSolidgauge(Solidgauge solidgauge) {
		this.solidgauge = solidgauge;
	}

	public void setPie(Pie pie) {
		this.pie = pie;
	}

	public Spline getSpline() {
		return spline;
	}

	public void setSpline(Spline spline) {
		this.spline = spline;
	}

	public Area getArea() {
		return area;
	}

	public void setArea(Area area) {
		this.area = area;
	}
	
	
}
