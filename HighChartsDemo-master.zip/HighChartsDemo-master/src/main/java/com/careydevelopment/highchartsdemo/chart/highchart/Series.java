package com.careydevelopment.highchartsdemo.chart.highchart;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Series {

	String name="";
	String type="";
	String color="";
	boolean colorByPoint;
	
	List<Object> data=new ArrayList<Object>();
	
	Long yAxis = 0L;
	Long xAxis = 0L;
	
	Long y=0L;
	
	public boolean isColorByPoint() {
		return colorByPoint;
	}

	public void setColorByPoint(boolean colorByPoint) {
		this.colorByPoint = colorByPoint;
	}

	Boolean showInLegend;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public List<Object> getData() {
		return data;
	}

	public void setData(List<Object> data) {
		this.data = data;
	}

	public Long getyAxis() {
		return yAxis;
	}

	public void setyAxis(Long yAxis) {
		this.yAxis = yAxis;
	}

	public Long getxAxis() {
		return xAxis;
	}

	public void setxAxis(Long xAxis) {
		this.xAxis = xAxis;
	}

	public Boolean getShowInLegend() {
		return showInLegend;
	}

	public void setShowInLegend(Boolean showInLegend) {
		this.showInLegend = showInLegend;
	}

	public Long getY() {
		return y;
	}

	public void setY(Long y) {
		this.y = y;
	}
	
	
}
