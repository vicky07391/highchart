package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class StackLabels {

	boolean enabled;
	Style style;
	Integer rotation;
	String formatter;
	
	public StackLabels() {}
	
	public StackLabels(boolean enabled) {
		this.enabled = enabled;
	}
	
	public StackLabels(boolean enabled, Style style) {
		this.enabled = enabled;
		this.style = style;
	}
	
	public StackLabels(boolean enabled, Style style, String formatter) {
		this.enabled = enabled;
		this.style = style;
		this.formatter = formatter;
	}
	
	public StackLabels(boolean enabled, Style style, Integer rotation, String formatter) {
		this.enabled = enabled;
		this.style = style;
		this.rotation = rotation;
		this.formatter = formatter;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public Style getStyle() {
		return style;
	}

	public void setStyle(Style style) {
		this.style = style;
	}

	public Integer getRotation() {
		return rotation;
	}

	public void setRotation(Integer rotation) {
		this.rotation = rotation;
	}

	public String getFormatter() {
		return formatter;
	}

	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}
	
}
