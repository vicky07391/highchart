package com.careydevelopment.highchartsdemo.chart.highchart;

public class Subtitle {

	String text = "";
	String align = "";
	String style = "";
	String verticalAlign = "";
	
	Long margin = 0L;
	Long x = 0L;
	Long y = 0L;
	
	Boolean floating=false;
	Boolean useHTML=false;
	
	public Subtitle() {}
	
	public Subtitle(String text) {
		this.text = text;
	}
	
	public Subtitle(String text, Long x) {
		this.text = text;
		this.x = x;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getAlign() {
		return align;
	}

	public void setAlign(String align) {
		this.align = align;
	}

	public String getStyle() {
		return style;
	}

	public void setStyle(String style) {
		this.style = style;
	}

	public String getVerticalAlign() {
		return verticalAlign;
	}

	public void setVerticalAlign(String verticalAlign) {
		this.verticalAlign = verticalAlign;
	}

	public Long getMargin() {
		return margin;
	}

	public void setMargin(Long margin) {
		this.margin = margin;
	}

	public Long getX() {
		return x;
	}

	public void setX(Long x) {
		this.x = x;
	}

	public Long getY() {
		return y;
	}

	public void setY(Long y) {
		this.y = y;
	}

	public Boolean getFloating() {
		return floating;
	}

	public void setFloating(Boolean floating) {
		this.floating = floating;
	}

	public Boolean getUseHTML() {
		return useHTML;
	}

	public void setUseHTML(Boolean useHTML) {
		this.useHTML = useHTML;
	}
	
	
}
