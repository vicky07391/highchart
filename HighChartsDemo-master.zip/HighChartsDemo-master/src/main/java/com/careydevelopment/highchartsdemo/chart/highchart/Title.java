package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Title {

	String text = "";
//	String align ;
//	String style= "";
//	String verticalAlign="";
//	
//	Long margin = 0L;
//	Long x=0L;
//	Long y=0L;
//	
//	Boolean floating=false;
//	Boolean useHTML=false;
//	Boolean enabled=false;
//	
	public Title() {}
	
	public Title(String text) {
		this.text = text;
	}

//	public Title(Boolean enabled) {
//		this.enabled = enabled;
//	}
//	
//	public Title(String text, Long y) {
//		this.text = text;
//		this.y = y;
//	}
//	
//	public Boolean getEnabled() {
//		return enabled;
//	}
//
//	public void setEnabled(Boolean enabled) {
//		this.enabled = enabled;
//	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

//	public String getAlign() {
//		return align;
//	}
//	public void setAlign(String align) {
//		this.align = align;
//	}
//	public String getStyle() {
//		return style;
//	}
//	public void setStyle(String style) {
//		this.style = style;
//	}
//	public String getVerticalAlign() {
//		return verticalAlign;
//	}
//	public void setVerticalAlign(String verticalAlign) {
//		this.verticalAlign = verticalAlign;
//	}
//	public Long getMargin() {
//		return margin;
//	}
//	public void setMargin(Long margin) {
//		this.margin = margin;
//	}
//	public Long getX() {
//		return x;
//	}
//	public void setX(Long x) {
//		this.x = x;
//	}
//	public Long getY() {
//		return y;
//	}
//	public void setY(Long y) {
//		this.y = y;
//	}
//	public Boolean getFloating() {
//		return floating;
//	}
//	public void setFloating(Boolean floating) {
//		this.floating = floating;
//	}
//	public Boolean getUseHTML() {
//		return useHTML;
//	}
//	public void setUseHTML(Boolean useHTML) {
//		this.useHTML = useHTML;
//	}
}
