package com.careydevelopment.highchartsdemo.chart.highchart;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class Tooltip {

	String formatter="";
	Boolean shared=false; 
	Boolean enabled=false;
	
	public Tooltip() {}
	
	public Tooltip(String formatter) {
		this.formatter = formatter;
	}
	
	public Tooltip(Boolean enabled) {
		this.enabled = enabled;
	}
	
	public Tooltip(String formatter, Boolean shared) {
		this.formatter = formatter;
		this.shared = shared;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public Boolean getShared() {
		return shared;
	}

	public void setShared(Boolean shared) {
		this.shared = shared;
	}

	public String getFormatter() {
		return formatter;
	}

	public void setFormatter(String formatter) {
		this.formatter = formatter;
	}
	
}
