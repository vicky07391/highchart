package com.careydevelopment.highchartsdemo.chart.highchart;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class XAxis {

	List<Object> categories;
	String tickmarkPlacement;
	Title title;
	Labels labels;
	
	Boolean allowDecimals;
	Boolean crosshair;
	
	Integer gridLineWidth;
	
	String type;
	DateTimeLabelFormats dateTimeLabelFormats;
	
	public XAxis() {}
	
	public XAxis(List<Object> catgories) {
		this.categories = catgories;
	}
	
	public XAxis(List<Object> catgories, String tickmarkPlacement, Title title, Integer gridLineWidth) {
		this.categories = catgories;
		this.tickmarkPlacement = tickmarkPlacement;
		this.title = title;
		this.gridLineWidth = gridLineWidth;
	}
	
	public XAxis(List<Object> catgories, Integer gridLineWidth) {
		this.categories = catgories;
		this.gridLineWidth = gridLineWidth;
	}
	
	public XAxis(List<Object> catgories, Labels labels) {
		this.categories = catgories;
		this.labels = labels;
	}
	
	public XAxis(List<Object> catgories, Labels labels, Integer gridLineWidth) {
		this.categories = catgories;
		this.labels = labels;
		this.gridLineWidth = gridLineWidth;
	}
	
	public XAxis(List<Object> catgories, boolean crosshair) {
		this.categories = catgories;
		this.crosshair = crosshair;
	}
	
	public XAxis(List<Object> catgories, Labels labels, boolean crosshair, Integer gridLineWidth) {
		this.categories = catgories;
		this.labels = labels;
		this.crosshair = crosshair;
		this.gridLineWidth = gridLineWidth;
	}
	
	public XAxis(List<Object> catgories, Labels labels, boolean crosshair) {
		this.categories = catgories;
		this.labels = labels;
		this.crosshair = crosshair;
	}
	
	public XAxis(List<Object> catgories, Labels labels, boolean crosshair, Title title) {
		this.categories = catgories;
		this.labels = labels;
		this.crosshair = crosshair;
		this.title = title;
	}
	
	public XAxis(List<Object> catgories, Title title) {
		this.categories = catgories;
		this.title = title;
	}
	
	public XAxis(List<Object> catgories, Title title, Boolean allowDecimals) {
		this.categories = catgories;
		this.title = title;
		this.allowDecimals = allowDecimals;
	}

	public String getTickmarkPlacement() {
		return tickmarkPlacement;
	}

	public void setTickmarkPlacement(String tickmarkPlacement) {
		this.tickmarkPlacement = tickmarkPlacement;
	}

	public List<Object> getCategories() {
		return categories;
	}
	public void setCategories(List<Object> categories) {
		this.categories = categories;
	}
	public Title getTitle() {
		return title;
	}
	public void setTitle(Title title) {
		this.title = title;
	}
	public Boolean getAllowDecimals() {
		return allowDecimals;
	}
	public void setAllowDecimals(Boolean allowDecimals) {
		this.allowDecimals = allowDecimals;
	}

	public Labels getLabels() {
		return labels;
	}

	public void setLabels(Labels labels) {
		this.labels = labels;
	}

	public Boolean getCrosshair() {
		return crosshair;
	}

	public void setCrosshair(Boolean crosshair) {
		this.crosshair = crosshair;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public DateTimeLabelFormats getDateTimeLabelFormats() {
		return dateTimeLabelFormats;
	}

	public void setDateTimeLabelFormats(DateTimeLabelFormats dateTimeLabelFormats) {
		this.dateTimeLabelFormats = dateTimeLabelFormats;
	}

	public Integer getGridLineWidth() {
		return gridLineWidth;
	}

	public void setGridLineWidth(Integer gridLineWidth) {
		this.gridLineWidth = gridLineWidth;
	}
	
}
