package com.careydevelopment.highchartsdemo.chart.highchart;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown=true)
public class YAxis {

	Title title;
	Boolean allowDecimals;
	Integer min;
	Integer max;
	StackLabels stackLabels;
	Labels labels;
	Boolean opposite;
	Integer gridLineWidth;
	List<Object> stops;
	
	public YAxis() {}
	
	public YAxis(Integer min, Integer max, Title title, Labels labels) {
		this.title = title;
		this.min = min;
		this.max = max;
		this.labels = labels;
	}
	
	public YAxis(List<Object> stops, Integer min, Integer max, Title title, Labels labels) {
		this.title = title;
		this.min = min;
		this.max = max;
		this.labels = labels;
		this.stops = stops;
	}
	
	public YAxis(Title title, Integer min, Labels labels, Boolean opposite, Boolean allowDecimals, StackLabels stackLabels) {
		this.title = title;
		this.min = min;
		this.labels = labels;
		this.opposite = opposite;
		this.allowDecimals = allowDecimals;
		this.stackLabels = stackLabels;
	}
	
	public YAxis(Title title, Integer min, Labels labels, Boolean opposite, Boolean allowDecimals, StackLabels stackLabels, Integer gridLineWidth) {
		this.title = title;
		this.min = min;
		this.labels = labels;
		this.opposite = opposite;
		this.allowDecimals = allowDecimals;
		this.stackLabels = stackLabels;
		this.gridLineWidth = gridLineWidth;
	}
	
	public YAxis(Title title, Integer min, Labels labels, Boolean opposite) {
		this.title = title;
		this.min = min;
		this.labels = labels;
		this.opposite = opposite;
	}
	
	public YAxis(Title title, Integer min, Labels labels, Boolean opposite, Integer gridLineWidth) {
		this.title = title;
		this.min = min;
		this.labels = labels;
		this.opposite = opposite;
		this.gridLineWidth = gridLineWidth;
	}
	
	public YAxis(Title title, Integer min, Labels labels, Boolean opposite, Boolean allowDecimals) {
		this.title = title;
		this.min = min;
		this.labels = labels;
		this.opposite = opposite;
		this.allowDecimals = allowDecimals;
	}
	
	public YAxis(Title title, Integer min, StackLabels stackLabels) {
		this.title = title;
		this.min = min;
		this.stackLabels = stackLabels;
	}
	
	public YAxis(Title title, Integer min, StackLabels stackLabels, Integer gridLineWidth) {
		this.title = title;
		this.min = min;
		this.stackLabels = stackLabels;
		this.gridLineWidth = gridLineWidth;
	}
	
	public YAxis(Title title) {
		this.title = title;
	}
	
	public YAxis(Title title, Integer gridLineWidth) {
		this.title = title;
		this.gridLineWidth = gridLineWidth;
	}
	
	public YAxis(Title title, Boolean allowDecimals) {
		this.title = title;
		this.allowDecimals = allowDecimals;
	}
	
	public YAxis(Title title, Labels labels) {
		this.title = title;
		this.labels = labels;
	}
	
	public Title getTitle() {
		return title;
	}
	public void setTitle(Title title) {
		this.title = title;
	}
	public Boolean getAllowDecimals() {
		return allowDecimals;
	}
	public void setAllowDecimals(Boolean allowDecimals) {
		this.allowDecimals = allowDecimals;
	}

	public Integer getMin() {
		return min;
	}

	public void setMin(Integer min) {
		this.min = min;
	}

	public Integer getMax() {
		return max;
	}

	public void setMax(Integer max) {
		this.max = max;
	}

	public List<Object> getStops() {
		return stops;
	}

	public void setStops(List<Object> stops) {
		this.stops = stops;
	}

	public StackLabels getStackLabels() {
		return stackLabels;
	}

	public void setStackLabels(StackLabels stackLabels) {
		this.stackLabels = stackLabels;
	}

	public Labels getLabels() {
		return labels;
	}

	public void setLabels(Labels labels) {
		this.labels = labels;
	}

	public Boolean getOpposite() {
		return opposite;
	}

	public void setOpposite(Boolean opposite) {
		this.opposite = opposite;
	}

	public Integer getGridLineWidth() {
		return gridLineWidth;
	}

	public void setGridLineWidth(Integer gridLineWidth) {
		this.gridLineWidth = gridLineWidth;
	}
	
}
