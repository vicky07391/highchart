package com.careydevelopment.highchartsdemo.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.careydevelopment.highchartsdemo.chart.highchart.Chart;
import com.careydevelopment.highchartsdemo.chart.highchart.Data;
import com.careydevelopment.highchartsdemo.chart.highchart.DataLabels;
import com.careydevelopment.highchartsdemo.chart.highchart.Events;
import com.careydevelopment.highchartsdemo.chart.highchart.Highchart;
import com.careydevelopment.highchartsdemo.chart.highchart.Options3d;
import com.careydevelopment.highchartsdemo.chart.highchart.Pie;
import com.careydevelopment.highchartsdemo.chart.highchart.PlotOptions;
import com.careydevelopment.highchartsdemo.chart.highchart.Point;
import com.careydevelopment.highchartsdemo.chart.highchart.Series;
import com.careydevelopment.highchartsdemo.chart.highchart.Title;
import com.careydevelopment.highchartsdemo.chart.highchart.Tooltip;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Controller
public class ChartController {

    @RequestMapping(value = "/chart", method=RequestMethod.GET)
    public String chart(Model model) {
        
        //first, add the regional sales
        Integer northeastSales = 17089;
        Integer westSales = 10603;
        Integer midwestSales = 5223;
        Integer southSales = 10111;
        
        model.addAttribute("northeastSales", northeastSales);
        model.addAttribute("southSales", southSales);
        model.addAttribute("midwestSales", midwestSales);
        model.addAttribute("westSales", westSales);
        
        //now add sales by lure type
        List<Integer> inshoreSales = Arrays.asList(4074, 3455, 4112);
        List<Integer> nearshoreSales = Arrays.asList(3222, 3011, 3788);
        List<Integer> offshoreSales = Arrays.asList(7811, 7098, 6455);
        
        model.addAttribute("inshoreSales", inshoreSales);
        model.addAttribute("nearshoreSales", nearshoreSales);
        model.addAttribute("offshoreSales", offshoreSales);
        
        
        List<Object> data = new ArrayList<Object>();
		Data d = new Data();
		d.setName("northeastSales");
		d.setY(17089);
//		d.setUrl(url);
		d.setColor("#D9534F");
		data.add(d);
		
		d = new Data();
		d.setName("southSales");
		d.setY(southSales);
//		d.setUrl(url);
		d.setColor("#1CAF9A");
		data.add(d);

		d = new Data();
		d.setName("midwestSales");
		d.setY(midwestSales);
//		d.setUrl(url);
//		d.setColor("#1CAF9A");
		data.add(d);
		

		d = new Data();
		d.setName("westSales");
		d.setY(westSales);
//		d.setUrl(url);
//		d.setColor("#1CAF9A");
		data.add(d);

//		 tooltip: {
//          	pointFormat: "${point.y:,.0f}"
//        },
		
      //constructing graph object
		Highchart highchart = new Highchart();
		List<Series> seriesList = new ArrayList<Series>();

		Series series = new Series();
		series.setData(data);
		series.setColorByPoint(true);
//		colorByPoint:true
		series.setName("Customers");
		seriesList.add(series);

		highchart.setChart(new Chart("pie", 40, new Options3d(45, 0, true)));
		Tooltip tp =  new Tooltip();
		tp.setFormatter("${point.y:,.0f}");
		highchart.setTooltip(tp);
		highchart.setTitle(new Title("Sales by Region"));
		
		//
		//highchart.setPlotOptions(new PlotOptions(new Pie(true, 35)));
		highchart.setPlotOptions(new PlotOptions(new Pie(true, "pointer", 0, 35, new DataLabels(true, "{point.name} ({point.y})", 10), new Point(new Events("function(e){if(typeof this.url != 'undefined') { window.location = this.url;}}")))));
		
		highchart.setSeries(seriesList);
		
		String v = null;
		Highchart ch = new Highchart();
		
		try {
			ObjectMapper mp = new ObjectMapper();
			v = mp.writeValueAsString(highchart);
			
			try {
				ch =  mp.readValue(v, Highchart.class);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("**************"+ch.toString());
		model.addAttribute("highchart", highchart);
		model.addAttribute("highchart1", highchart);
		model.addAttribute("highchart2", ch);
		
		
        return "chart";
    }
    
    
    //redirect to demo if user hits the root
    @RequestMapping("/")
    public String home(Model model) {
        return "redirect:chart";
    }
}
