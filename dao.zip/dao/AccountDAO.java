package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Account;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class AccountDAO extends BaseDAO<Account> {

	public AccountDAO() {
		String collectionName = "account";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Account.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(new BasicDBObject("code", 1), options);
	}
	
	public Set<String> getCollections() {
		return Mongo.getInstance().getDB(AppProps.getInstance().getStringValue("databaseName")).getCollectionNames();
	}
	
	public List<Account> findSuperAdminAccounts() {
		BasicDBObject basicDBObject = new BasicDBObject("superAdminAccount", true);
		List<Account> accounts = new ArrayList<Account>();
		DBCursor<Account> cursor = getJCol().find(basicDBObject);
		while(cursor.hasNext()) {
			accounts.add(cursor.next());
		}
		return accounts;
	}
}
