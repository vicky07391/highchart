package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.ActivityLog;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class ActivityLogDAO extends BaseDAO<ActivityLog> {

	public ActivityLogDAO() {
		String collectionName = "activitylog";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), ActivityLog.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {}
	
	public List<String> getDistinctProgramIdsByUser(String accountId, String userId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("userId", userId));
		query.put("$and", obj);
		
		return getJCol().distinct("programId", query);
	}
	
	public List<String> getDistinctUserIdsByProgram(String accountId, String programId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("programId", programId));
		query.put("$and", obj);
		
		return getJCol().distinct("userId", query);
	}
	
	public List<String> getDistinctUserIdsByAccount(String accountId) {
		BasicDBObject query = new BasicDBObject("accountId", accountId);
		return getJCol().distinct("userId", query);
	}
	
}
