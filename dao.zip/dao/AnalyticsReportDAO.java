package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.AnalyticsReportType;
import com.crucialbits.cy.model.Report;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class AnalyticsReportDAO extends BaseDAO<Report> {

	public AnalyticsReportDAO() {
		String collectionName = "analyticsaggregate";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Report.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {}
	
	public long countMailVolumeReportData(String accountId, String gId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("gId", gId));
		obj.add(new BasicDBObject("analyticsReportType", AnalyticsReportType.VOLUME));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public long countUnrespondedReportData(String accountId, String gId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("gId", gId));
		obj.add(new BasicDBObject("analyticsReportType", AnalyticsReportType.UNRESPONDED));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}
