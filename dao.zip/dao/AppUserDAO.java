package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.AppUser;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class AppUserDAO  extends BaseDAO<AppUser> {

	public AppUserDAO() {
		String collectionName = "appuser";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), AppUser.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("customerId", 1);
		compoundIndex.put("email", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(compoundIndex, options);
        
        BasicDBObject compoundIndex2 = new BasicDBObject();
        compoundIndex2.put("accountId", 1);
        compoundIndex2.put("customerId", 1);
        compoundIndex2.put("email", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("accountId", 1);
        compoundIndex3.put("customerId", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
	}

	
	public long countByCustomer(String accountId, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public AppUser findWhoForTask(String accountId, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("sfContactId", new BasicDBObject("$ne", null)));
		
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
	
}