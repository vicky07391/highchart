package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.C360FilterSetting;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;

public class C360FilterSettingDAO extends BaseDAO<C360FilterSetting>{

	public C360FilterSettingDAO() {
		String collectionName = "c360filtersetting";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), C360FilterSetting.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	private void buildIndexes() {
		
	}
	
}
