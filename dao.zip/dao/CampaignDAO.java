package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Campaign;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class CampaignDAO extends BaseDAO<Campaign>{

	public CampaignDAO() {
		String collectionName = "campaign";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Campaign.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("entityId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("listId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("campaignType", 1), new BasicDBObject("background", true));
	}

	public long countSurveyCampaigns(String accountId, String surveyId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public long countMessageStats(String accountId, String messageId, boolean campaignSent) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("messageId", messageId));
		obj.add(new BasicDBObject("campaignSent", campaignSent));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<Campaign> findUsingListIds(String accountId, List<String> listIds, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(listIds != null && listIds.size() > 0) {
			obj.add(new BasicDBObject("listId", new BasicDBObject("$in", listIds)));
		}
		andQuery.put("$and", obj);
		DBCursor<Campaign> cursor = getJCol().find(andQuery).sort(new BasicDBObject("createdAt", -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Campaign> campaigns = new ArrayList<Campaign>();
		while(cursor.hasNext()) {
			campaigns.add(cursor.next());
		}
		return campaigns;
	}
	
	public List<Campaign> findCampaignForSendingMails(int maxSize) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("campaignSent", null));
		obj.add(new BasicDBObject("campaignSent", false));
		orQuery.put("$or", obj);
		
		List<Campaign> campaigns = new ArrayList<Campaign>();
		DBCursor<Campaign> cursor = getJCol().find(orQuery);
		while(cursor.hasNext()) {
			campaigns.add(cursor.next());
			if (campaigns.size() == maxSize) {
				break;
			}
		}
		return campaigns;
	}
	
	public List<Campaign> findCampaignForSendingReminderMails(int maxSize) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("reminderSent", null));
		obj.add(new BasicDBObject("reminderSent", false));
		orQuery.put("$or", obj);
		
		List<Campaign> campaigns = new ArrayList<Campaign>();
		DBCursor<Campaign> cursor = getJCol().find(orQuery);
		while(cursor.hasNext()) {
			campaigns.add(cursor.next());
			if (campaigns.size() == maxSize) {
				break;
			}
		}
		return campaigns;
	}
}

