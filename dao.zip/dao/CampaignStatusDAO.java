package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.CampaignStatus;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class CampaignStatusDAO extends BaseDAO<CampaignStatus> {

	public CampaignStatusDAO() {
		String collectionName = "campaignstatus";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), CampaignStatus.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("campaignId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("type", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("email", 1), new BasicDBObject("background", true));
	}
	
	public long countStatus(String campaignId, String type) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("campaignId", campaignId));
		obj.add(new BasicDBObject("type", type.toUpperCase()));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}
