package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.CohortAnalysis;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class CohortAnalysisDAO extends BaseDAO<CohortAnalysis> {

	public CohortAnalysisDAO() {
		String collectionName = "cohortanalysis";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), CohortAnalysis.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("chartFriendlyId", 1);
		compoundIndex.put("filter", 1);
		compoundIndex.put("filterValue", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(compoundIndex, options);
        
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("chartFriendlyId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("filter", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("filterValue", 1), new BasicDBObject("background", true));
	}
}
