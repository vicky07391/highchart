package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Comment;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class CommentDAO extends BaseDAO<Comment> {

	public CommentDAO() {
		String collectionName = "comment";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Comment.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("userId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("articleId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("comment", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("contentType", 1), new BasicDBObject("background", true));
	}
	
	public long countByArticle(String accountId, String articleId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("articleId", articleId));
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countByAccount(String accountId) {
		BasicDBObject query = new BasicDBObject("accountId", accountId);
		return getJCol().count(query);
	}
}