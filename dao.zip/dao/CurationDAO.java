package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.ContentType;
import com.crucialbits.cy.app.Constants.CurationType;
import com.crucialbits.cy.model.Curation;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class CurationDAO extends BaseDAO<Curation> {
	
	public CurationDAO() {
		String collectionName = "curation";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Curation.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("articleId", 1);
		compoundIndex.put("accountId", 1);
		compoundIndex.put("curationType", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(compoundIndex, options);
        
        getJCol().ensureIndex(new BasicDBObject("contentType", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("articleId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("curationType", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("curated", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("sequence", 1), new BasicDBObject("background", true));
	}
	
	public void resetSequenceNumbers(String accountId, ContentType contentType) {
		BasicDBObject andQuery = new BasicDBObject();
		
		List<BasicDBObject> searchQuery = new ArrayList<BasicDBObject>();
		searchQuery.add(new BasicDBObject("contentType", contentType));
		searchQuery.add(new BasicDBObject("accountId", accountId));
		
		andQuery.put("$and", searchQuery);
		
		BasicDBObject newQuery = new BasicDBObject();
		newQuery.put("$inc", new BasicDBObject("sequence", 1));
		
		getJCol().updateMulti(andQuery, newQuery);
	}
	
	public List<Curation> findCuratedPosts(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		
		List<BasicDBObject> searchQuery = new ArrayList<BasicDBObject>();
		searchQuery.add(new BasicDBObject("curated", true));
		searchQuery.add(new BasicDBObject("accountId", accountId));
		searchQuery.add(new BasicDBObject("contentType", new BasicDBObject("$ne", ContentType.NEWSARTICLE)));
		
		andQuery.put("$and", searchQuery);
		
		List<Curation> content = new ArrayList<Curation>();
		DBCursor<Curation> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while (cursor.hasNext()) {
			content.add(cursor.next());
		}
		return content;
	}
	
	public List<Curation> findWidgetCuratedPosts(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		
		List<BasicDBObject> searchQuery = new ArrayList<BasicDBObject>();
		searchQuery.add(new BasicDBObject("curated", true));
		searchQuery.add(new BasicDBObject("accountId", accountId));
		searchQuery.add(new BasicDBObject("curationType", CurationType.WIDGET));
		searchQuery.add(new BasicDBObject("contentType", new BasicDBObject("$ne", ContentType.NEWSARTICLE)));
		
		andQuery.put("$and", searchQuery);
		
		List<Curation> content = new ArrayList<Curation>();
		DBCursor<Curation> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while (cursor.hasNext()) {
			content.add(cursor.next());
		}
		return content;
	}

}