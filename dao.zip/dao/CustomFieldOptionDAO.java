package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.CustomFieldOption;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class CustomFieldOptionDAO extends BaseDAO<CustomFieldOption> {

	public CustomFieldOptionDAO() {
		String collectionName = "customfieldoption";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), CustomFieldOption.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("fieldId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("option", 1), new BasicDBObject("background", true));
	}
}
