package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.bson.types.ObjectId;
import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Utility;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.Field;
import com.crucialbits.cy.model.FieldGroup;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class CustomerDAO extends BaseDAO<Customer> {

	public CustomerDAO() {
		String collectionName = "customer";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Customer.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("externalId", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(compoundIndex, options);

        BasicDBObject compoundIndex2 = new BasicDBObject();
		compoundIndex2.put("accountId", 1);
		compoundIndex2.put("ignored", 1);
		BasicDBObject options2 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex2, options2);
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("customFields.name", 1);
        compoundIndex3.put("customFields.value", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex4 = new BasicDBObject();
        compoundIndex4.put("accountId", 1);
        compoundIndex4.put("externalId", 1);
        getJCol().ensureIndex(compoundIndex4, new BasicDBObject("background", true));
        
        /*BasicDBObject compoundIndex5 = new BasicDBObject();
        compoundIndex5.put("accountId", 1);
        compoundIndex5.put("ignored", 1);
        compoundIndex5.put("customerTypeId", 1);
        getJCol().ensureIndex(compoundIndex5, new BasicDBObject("background", true));*/
        
        BasicDBObject compoundIndex6 = new BasicDBObject();
        compoundIndex6.put("accountId", 1);
        compoundIndex6.put("ignored", 1);
        compoundIndex6.put("accountManager", 1);
        getJCol().ensureIndex(compoundIndex6, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex7 = new BasicDBObject();
        compoundIndex7.put("accountId", 1);
        compoundIndex7.put("ignored", 1);
        compoundIndex7.put("csm", 1);
        getJCol().ensureIndex(compoundIndex7, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex8 = new BasicDBObject();
        compoundIndex8.put("accountId", 1);
        compoundIndex8.put("ignored", 1);
        compoundIndex8.put("cem", 1);
        getJCol().ensureIndex(compoundIndex8, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex9 = new BasicDBObject();
        compoundIndex9.put("accountId", 1);
        compoundIndex9.put("ignored", 1);
        compoundIndex9.put("customerTypes", 1);
        getJCol().ensureIndex(compoundIndex9, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex10 = new BasicDBObject();
        compoundIndex10.put("accountId", 1);
        compoundIndex10.put("ignored", 1);
        compoundIndex10.put("salesperson", 1);
        getJCol().ensureIndex(compoundIndex10, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex11 = new BasicDBObject();
        compoundIndex11.put("accountId", 1);
        compoundIndex11.put("ignored", 1);
        compoundIndex11.put("psManager", 1);
        getJCol().ensureIndex(compoundIndex11, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex12 = new BasicDBObject();
        compoundIndex12.put("accountId", 1);
        compoundIndex12.put("ignored", 1);
        compoundIndex12.put("customerTypes", 1);
        compoundIndex12.put("psManager", 1);
        getJCol().ensureIndex(compoundIndex12, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex13 = new BasicDBObject();
        compoundIndex13.put("accountId", 1);
        compoundIndex13.put("ignored", 1);
        compoundIndex13.put("customerTypes", 1);
        compoundIndex13.put("salesperson", 1);
        getJCol().ensureIndex(compoundIndex13, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex14 = new BasicDBObject();
        compoundIndex14.put("accountId", 1);
        compoundIndex14.put("ignored", 1);
        compoundIndex14.put("customerTypes", 1);
        compoundIndex14.put("cem", 1);
        getJCol().ensureIndex(compoundIndex14, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex15 = new BasicDBObject();
        compoundIndex15.put("accountId", 1);
        compoundIndex15.put("ignored", 1);
        compoundIndex15.put("customerTypes", 1);
        compoundIndex15.put("csm", 1);
        getJCol().ensureIndex(compoundIndex15, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex16 = new BasicDBObject();
        compoundIndex16.put("accountId", 1);
        compoundIndex16.put("ignored", 1);
        compoundIndex16.put("customerTypes", 1);
        compoundIndex16.put("accountManager", 1);
        getJCol().ensureIndex(compoundIndex16, new BasicDBObject("background", true));

        BasicDBObject compoundIndex17 = new BasicDBObject();
        compoundIndex17.put("accountId", 1);
        compoundIndex17.put("ignored", 1);
        compoundIndex17.put("groups", 1);
        getJCol().ensureIndex(compoundIndex17, new BasicDBObject("background", true));
        
        /*BasicDBObject compoundIndex18 = new BasicDBObject();
        compoundIndex18.put("accountId", 1);
        compoundIndex18.put("ignored", 1);
        compoundIndex18.put("groups", 1);
        compoundIndex18.put("customerTypes", 1);
        getJCol().ensureIndex(compoundIndex18, new BasicDBObject("background", true));*/
        
        getJCol().ensureIndex(new BasicDBObject("groups", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("ignored", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("customerTypes", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("partnerId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("externalId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("name", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("normalizedName", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("accountManager", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("healthy", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("age", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("users", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("mrrStatus", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("mrrRange", 1), new BasicDBObject("background", true));
//		getJCol().ensureIndex(new BasicDBObject("streetAddress", 1), new BasicDBObject("background", true));
//		getJCol().ensureIndex(new BasicDBObject("city", 1), new BasicDBObject("background", true));
//		getJCol().ensureIndex(new BasicDBObject("country", 1), new BasicDBObject("background", true));
//		getJCol().ensureIndex(new BasicDBObject("state", 1), new BasicDBObject("background", true));
//		getJCol().ensureIndex(new BasicDBObject("zip", 1), new BasicDBObject("background", true));
//		getJCol().ensureIndex(new BasicDBObject("phone", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("website", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("salesperson", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("salespersonEmail", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("accountManagerEmail", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("lastUsage", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("npsScore", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("renewalDays", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("initialMrr", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("currentMrr", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("initialArr", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("currentArr", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("contractStatus", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("customerStatus", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("lastMeeting", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("nextScheduledMeeting", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("customScores", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("sfAccountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("domains", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("csm", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("cem", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("groups", 1), new BasicDBObject("background", true));

	}

	public long countByAccount(String accountId, String licenseType, String partnerId, String accountManager, String age, String users,
			String health, String installationType, String ignored, String mrrStatus, String mrrRange, String cs02, String cl09, String customerType,
			Map<String, String> customParams, String currentTerm, String profileRisk, String behaviorRisk, String age3Months, String age6Months,
			String supportLevel, String trafficStatus, List<Field> customFields, String csm, String cem, String salesperson) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		obj.add(new BasicDBObject("deletedAt", null));

		if(!StringHelper.isEmpty(licenseType)) {
			obj.add(new BasicDBObject("licenses.licenseType", licenseType));
		}
		if(!StringHelper.isEmpty(installationType)) {
			obj.add(new BasicDBObject("licenses.installationType", installationType));
		}
		if(!StringHelper.isEmpty(partnerId)) {
			obj.add(new BasicDBObject("partnerId", partnerId));
		}
		if(!StringHelper.isEmpty(supportLevel)) {
			obj.add(new BasicDBObject("supportLevel", supportLevel));
		}
		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(age)) {
			obj.add(new BasicDBObject("age", age));
		}
		if(!StringHelper.isEmpty(users)) {
			obj.add(new BasicDBObject("users", users));
		}
		if(!StringHelper.isEmpty(health)) {
			obj.add(new BasicDBObject("healthy", Boolean.parseBoolean(health)));
		}
		if(!StringHelper.isEmpty(mrrStatus)) {
			obj.add(new BasicDBObject("mrrStatus", mrrStatus));
		}
		if(!StringHelper.isEmpty(mrrRange)) {
			obj.add(new BasicDBObject("mrrRange", mrrRange));
		}
		if(!StringHelper.isEmpty(currentTerm)) {
			obj.add(new BasicDBObject("currentTerm", Long.parseLong(currentTerm)));
		}
		if(!StringHelper.isEmpty(profileRisk)) {
			obj.add(new BasicDBObject("profileRisk", profileRisk));
		}
		if(!StringHelper.isEmpty(behaviorRisk)) {
			obj.add(new BasicDBObject("behaviorRisk", behaviorRisk));
		}
		if(!StringHelper.isEmpty(age3Months)) {
			obj.add(new BasicDBObject("age3Months", true));
		}
		if(!StringHelper.isEmpty(age6Months)) {
			obj.add(new BasicDBObject("age6Months", true));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		if(!StringHelper.isEmpty(trafficStatus)) {
			obj.add(new BasicDBObject("traficStatus", trafficStatus));
		}
		if(!StringHelper.isEmpty(csm)) {
			obj.add(new BasicDBObject("csm", csm));
		}
		if(!StringHelper.isEmpty(cem)) {
			obj.add(new BasicDBObject("cem", cem));
		}
		if(!StringHelper.isEmpty(salesperson)) {
			obj.add(new BasicDBObject("salesperson", salesperson));
		}
		if(customParams != null) {
			boolean groupsStructure = true;
			Customer c = findOne(new BasicDBObject("accountId", accountId));
			if(c != null && c.getCustomFields() != null && c.getCustomFields().size() > 0) {
				groupsStructure = false;
			}
			for(Map.Entry<String, String> entry : customParams.entrySet()) {
				for(com.crucialbits.cy.model.Field field : customFields) {
					if(field.getName().equals(entry.getKey()) && !StringHelper.isEmpty(entry.getValue()) && groupsStructure) {
						obj.add(new BasicDBObject("fieldGroups.fields.name", entry.getKey()));
						obj.add(new BasicDBObject("fieldGroups.fields.response", Utility.getInstance().resolveFieldType(entry.getValue(), field)));
					} else if(field.getName().equals(entry.getKey()) && !StringHelper.isEmpty(entry.getValue()) && !groupsStructure){
						obj.add(new BasicDBObject("customFields", new BasicDBObject("$elemMatch", new BasicDBObject("name", entry.getKey()).append("value", Utility.getInstance().resolveFieldType(entry.getValue(), field)))));
					}
				}
			}
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}

	public long countByAccountAndPattern(String accountId, String pattern, String ignored) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		obj.add(new BasicDBObject("deletedAt", null));
		obj.add(new BasicDBObject("name", Pattern.compile(pattern, 2)));
		query.put("$and", obj);
		return getJCol().count(query);
	}

	public List<Customer> findMonthlyRenewals(String accountId, String ignored, String accountManager, String customerType, String mrrFrom, String mrrTo, Date startDate, Date endDate, List<String> dates, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		if(startDate != null && endDate != null) {
			obj.add(new BasicDBObject("licenses.renewalDate",  new BasicDBObject("$gte", startDate).append("$lte", endDate)));
		}
		if(dates != null) {
			obj.add(new BasicDBObject("licenses.formattedRenewalDate", new BasicDBObject("$in", dates)));
		}
		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		if(!StringHelper.isEmpty(mrrFrom) && !StringHelper.isEmpty(mrrTo) && Double.parseDouble(mrrTo) != 0) {
			obj.add(new BasicDBObject("currentMrr",  new BasicDBObject("$gte", Float.parseFloat(mrrFrom)).append("$lte", Float.parseFloat(mrrTo))));
		}
		if(!StringHelper.isEmpty(mrrFrom) && !StringHelper.isEmpty(mrrTo) && Double.parseDouble(mrrTo) == 0) {
			obj.add(new BasicDBObject("currentMrr",  new BasicDBObject("$gte", Float.parseFloat(mrrFrom))));
		}

		andQuery.put("$and", obj);

		DBCursor<Customer> cursor = getJCol().find(andQuery).sort(new BasicDBObject("healthy", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Customer> customers = new ArrayList<Customer>();
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}

	public long countMonthlyRenewals(String accountId, String ignored, String accountManager, String customerType, String mrrFrom, String mrrTo, Date startDate, Date endDate, List<String> dates) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		if(startDate != null && endDate != null) {
			obj.add(new BasicDBObject("licenses.renewalDate",  new BasicDBObject("$gte", startDate).append("$lte", endDate)));
		}
		if(dates != null) {
			obj.add(new BasicDBObject("licenses.formattedRenewalDate", new BasicDBObject("$in", dates)));
		}
		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		if(!StringHelper.isEmpty(mrrFrom) && !StringHelper.isEmpty(mrrTo) && Double.parseDouble(mrrTo) != 0) {
			obj.add(new BasicDBObject("currentMrr",  new BasicDBObject("$gte", Float.parseFloat(mrrFrom)).append("$lte", Float.parseFloat(mrrTo))));
		}
		if(!StringHelper.isEmpty(mrrFrom) && !StringHelper.isEmpty(mrrTo) && Double.parseDouble(mrrTo) == 0) {
			obj.add(new BasicDBObject("currentMrr",  new BasicDBObject("$gte", Float.parseFloat(mrrFrom))));
		}

		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countCustomersHealth(String accountId, boolean healthy, Map<String, Object> paramMap) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("healthy", healthy));
		
		for(Map.Entry<String, Object> entry : paramMap.entrySet()) {
			if(!StringHelper.isEmpty(entry.getKey()) && entry.getValue() != null) {
				obj.add(new BasicDBObject(entry.getKey(), entry.getValue()));
			}
		}

		query.put("$and", obj);
		return getJCol().count(query);
	}

	public List<String> getDistinctAccountManagers(String accountId, String customerTypeId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("accountManager", andQuery);
	}
	
	
	public List<String> getDistinctAccountManagers(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		/*if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypeId", customerTypeId));
		}*/
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("accountManager", andQuery);
	}

	public List<Customer> findCustomersByMRRRange(String accountId, Map<String, Object> paramMap, float mrrFrom, float mrrTo, 
			int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));

		if(mrrTo != 0) {
			obj.add(new BasicDBObject("currentMrr",  new BasicDBObject("$gte", mrrFrom).append("$lte", mrrTo)));
		}
		
		if(mrrTo == 0) {
			obj.add(new BasicDBObject("currentMrr",  new BasicDBObject("$gte", mrrFrom)));
		}			
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}

		andQuery.put("$and", obj);

		DBCursor<Customer> cursor = getJCol().find(andQuery).sort(new BasicDBObject("normalizedName", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Customer> customers = new ArrayList<Customer>();
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}

	public List<String> getDistinctTextCustomField(String accountId, String customField) {
		BasicDBObject query = new BasicDBObject();
		query.put("accountId", accountId);
		return getJCol().distinct(customField, query);
	}

	public Set<Object> getDistinctCustomFieldValues(String accountId, String customField) {
		BasicDBObject query = new BasicDBObject();
		query.put("accountId", accountId);
		Set<Object> values = new HashSet<Object>();
		DBCursor<Customer> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			Customer customer = cursor.next();
			if(customer.getFieldGroups() != null) {
				for(FieldGroup fg : customer.getFieldGroups()) {
					if(fg.getFields() != null) {
						for(Field field : fg.getFields()) {
							if(field.getName().equalsIgnoreCase(customField) && field.getResponse() != null) {
								values.add(field.getResponse());
							}
						}
					}
				}
			}
		}
		return values;
	}
	
	public Set<Object> getDistinctCustomFieldValues(String accountId, String customField, Map<String, Object> paramMap) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
		query.put("$and", obj);
		Set<Object> values = new HashSet<Object>();
		DBCursor<Customer> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			Customer customer = cursor.next();
			if(customer.getFieldGroups() != null) {
				for(FieldGroup fg : customer.getFieldGroups()) {
					if(fg.getFields() != null) {
						for(Field field : fg.getFields()) {
							if(field.getName().equalsIgnoreCase(customField) && field.getResponse() != null) {
								values.add(field.getResponse());
							}
						}
					}
				}
			}
		}
		return values;
	}

	public List<Long> getDistinctNumericCustomField(String accountId, String customField) {
		BasicDBObject query = new BasicDBObject();
		query.put("accountId", accountId);
		return getJCol().distinct(customField, query);
	}

	public List<String> getDistinctLicenseTypes(String accountId, String customerTypeId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("licenses.licenseType", andQuery);
	}

	public List<String> getDistinctInstallationTypes(String accountId, String customerTypeId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("licenses.installationType", andQuery);
	}

	public List<Long> getDistinctCurrentTerms(String accountId, Map<String, Object> paramMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString()) && mp.getKey().equals("customerTypeId")) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}			
		andQuery.put("$and", obj);
		return getJCol().distinct("currentTerm", andQuery);
	}

	public long countCustomersByProfileAndBehaviorRisk(String accountId, Map<String, Object> paramMap, String profileRisk, String behaviorRisk) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));		
		if(!StringHelper.isEmpty(profileRisk)) {
			obj.add(new BasicDBObject("profileRisk", profileRisk));
		}
		if(!StringHelper.isEmpty(behaviorRisk)) {
			obj.add(new BasicDBObject("behaviorRisk", behaviorRisk));
		}
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString()) ) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<String> getDistinctProfileRisks(String accountId, Map<String, Object> paramMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));		
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString()) && mp.getKey().equals("customerTypeId")) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("profileRisk", andQuery);
	}


	public List<String> getDistinctBehaviorRisks(String accountId, Map<String, Object> paramMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString()) && mp.getKey().equals("customerTypeId")) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}		
		andQuery.put("$and", obj);
		return getJCol().distinct("behaviorRisk", andQuery);
	}

	public void resetMonthsCount(String accountId, Map<String, Object> paramMap) {
		BasicDBObject andQuery = new BasicDBObject();

		List<BasicDBObject> searchQuery = new ArrayList<BasicDBObject>();
		searchQuery.add(new BasicDBObject("accountId", accountId));
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				searchQuery.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
		
		andQuery.put("$and", searchQuery);

		BasicDBObject newQuery = new BasicDBObject();
		newQuery.put("$set", new BasicDBObject("age3Months", false).append("age6Months", false));

		getJCol().updateMulti(andQuery, newQuery);
	}

	public List<Customer> findSegmentedCustomers(String accountId, Map<String, Object> queryMap, int skip, int limit) {
		BasicDBObject query = new BasicDBObject(queryMap).append("accountId", accountId);
		DBCursor<Customer> cursor = getJCol().find(query).sort(new BasicDBObject("normalizedName", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Customer> customers = new ArrayList<Customer>();
		while (cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}

	public long countSegmentedCustomers(String accountId, Map<String, Object> queryMap) {
		BasicDBObject query = new BasicDBObject(queryMap).append("accountId", accountId);
		return getJCol().count(query);
	}

	public List<Object> getDistinctContractStatusValues(String accountId, String customerTypeId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypeId", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("contractStatus", andQuery);
	}

	public List<Object> getDistinctSupportLevelValues(String accountId, Map<String, Object> paramMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
		
		andQuery.put("$and", obj);
		return getJCol().distinct("supportLevel", andQuery);
	}

	public long countCustomersForDashboard(String accountId, Map<String, Object> paramMap) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}

		/*obj.add(new BasicDBObject("ignored", ignored));
		if(!StringHelper.isEmpty(partnerId)) {
			obj.add(new BasicDBObject("partnerId", partnerId));
		}
		
		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(csm)) {
			obj.add(new BasicDBObject("csm", csm));
		}
		if(!StringHelper.isEmpty(cem)) {
			obj.add(new BasicDBObject("cem", cem));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}*/
		query.put("$and", obj);
		return getJCol().count(query);
	}

	public List<Customer> findDeletedCustomers(String accountId, String sortBy, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deletedAt", new BasicDBObject("$ne", null)));
		andQuery.put("$and", obj);
		List<Customer> customers = new ArrayList<Customer>();
		DBCursor<Customer> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}

	public void deleteLastThirtyDaysDeletedCustomers(String accountId, Calendar calendar) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deletedAt", new BasicDBObject("$lte", calendar.getTime())));
		andQuery.put("$and", obj);
		getJCol().remove(andQuery);
	}


	public long countDeletedCustomers(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deletedAt", new BasicDBObject("$ne", null)));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}


	public List<Customer> findActiveCustomers(Map<String, Object> queryMap, Map<String, Object> fieldsMap, String pattern, String sortBy, boolean ascending, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
	    for(Map.Entry<String, Object> mp : queryMap.entrySet()){
	    	obj.add(new BasicDBObject(mp.getKey(),mp.getValue()));
	    }
	    if(!StringHelper.isEmpty(pattern)) {
			obj.add(new BasicDBObject("name", Pattern.compile(pattern, 2)));
		}
		obj.add(new BasicDBObject("deletedAt", null));
		andQuery.put("$and", obj);
		
		BasicDBObject fields = new BasicDBObject();
		if(fieldsMap != null) {
			for(Map.Entry<String, Object> mp : fieldsMap.entrySet()){
				fields.put(mp.getKey(), 1);
			}
		}
		
		List<Customer> customers = new ArrayList<Customer>();
		DBCursor<Customer> cursor = getJCol().find(andQuery, fields).sort(new BasicDBObject(sortBy, (ascending) ? 1 : -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	
	public long countUpsellData(String accountId, String accountManager, String customerType, String ignored, 
			String account_score_minValue, String clm_minValue, String dm_minValue, String xa_minValue, String ec_minValue, String rm_b_minValue, 
			String account_score_maxValue, String clm_maxValue, String dm_maxValue, String xa_maxValue, String ec_maxValue, String rm_b_maxValue) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		obj.add(new BasicDBObject("deletedAt", null));

		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		
		if(!StringHelper.isEmpty(account_score_minValue) && !StringHelper.isEmpty(account_score_maxValue)) {
			obj.add(new BasicDBObject("customScores.account_score", new BasicDBObject("$gte", Double.parseDouble(account_score_minValue)).append("$lte", Double.parseDouble(account_score_maxValue))));
		} else if(!StringHelper.isEmpty(account_score_minValue)) {
			obj.add(new BasicDBObject("customScores.account_score", new BasicDBObject("$gte", Double.parseDouble(account_score_minValue))));
		} else if(!StringHelper.isEmpty(account_score_maxValue)) {
			obj.add(new BasicDBObject("customScores.account_score", new BasicDBObject("$lte", Double.parseDouble(account_score_maxValue))));
		}
		
		if(!StringHelper.isEmpty(clm_minValue) && !StringHelper.isEmpty(clm_maxValue)) {
			obj.add(new BasicDBObject("customScores.clm", new BasicDBObject("$gte", Double.parseDouble(clm_minValue)).append("$lte", Double.parseDouble(clm_maxValue))));
		} else if(!StringHelper.isEmpty(clm_minValue)) {
			obj.add(new BasicDBObject("customScores.clm", new BasicDBObject("$gte", Double.parseDouble(clm_minValue))));
		} else if(!StringHelper.isEmpty(clm_maxValue)) {
			obj.add(new BasicDBObject("customScores.clm", new BasicDBObject("$lte", Double.parseDouble(clm_maxValue))));
		}
		
		if(!StringHelper.isEmpty(dm_minValue) && !StringHelper.isEmpty(dm_maxValue)) {
			obj.add(new BasicDBObject("customScores.dm", new BasicDBObject("$gte", Double.parseDouble(dm_minValue)).append("$lte", Double.parseDouble(dm_maxValue))));
		} else if(!StringHelper.isEmpty(dm_minValue)) {
			obj.add(new BasicDBObject("customScores.dm", new BasicDBObject("$gte", Double.parseDouble(dm_minValue))));
		} else if(!StringHelper.isEmpty(dm_maxValue)) {
			obj.add(new BasicDBObject("customScores.dm", new BasicDBObject("$lte", Double.parseDouble(dm_maxValue))));
		}
		
		if(!StringHelper.isEmpty(xa_minValue) && !StringHelper.isEmpty(xa_maxValue)) {
			obj.add(new BasicDBObject("customScores.xa", new BasicDBObject("$gte", Double.parseDouble(xa_minValue)).append("$lte", Double.parseDouble(xa_maxValue))));
		} else if(!StringHelper.isEmpty(xa_minValue)) {
			obj.add(new BasicDBObject("customScores.xa", new BasicDBObject("$gte", Double.parseDouble(xa_minValue))));
		} else if(!StringHelper.isEmpty(xa_maxValue)) {
			obj.add(new BasicDBObject("customScores.xa", new BasicDBObject("$lte", Double.parseDouble(xa_maxValue))));
		}
		
		if(!StringHelper.isEmpty(ec_minValue) && !StringHelper.isEmpty(ec_maxValue)) {
			obj.add(new BasicDBObject("customScores.ec", new BasicDBObject("$gte", Double.parseDouble(ec_minValue)).append("$lte", Double.parseDouble(ec_maxValue))));
		} else if(!StringHelper.isEmpty(ec_minValue)) {
			obj.add(new BasicDBObject("customScores.ec", new BasicDBObject("$gte", Double.parseDouble(ec_minValue))));
		} else if(!StringHelper.isEmpty(ec_maxValue)) {
			obj.add(new BasicDBObject("customScores.ec", new BasicDBObject("$lte", Double.parseDouble(ec_maxValue))));
		}
		
		if(!StringHelper.isEmpty(rm_b_minValue) && !StringHelper.isEmpty(rm_b_maxValue)) {
			obj.add(new BasicDBObject("customScores.rm_b", new BasicDBObject("$gte", Double.parseDouble(rm_b_minValue)).append("$lte", Double.parseDouble(rm_b_maxValue))));
		} else if(!StringHelper.isEmpty(rm_b_minValue)) {
			obj.add(new BasicDBObject("customScores.rm_b", new BasicDBObject("$gte", Double.parseDouble(rm_b_minValue))));
		} else if(!StringHelper.isEmpty(rm_b_maxValue)) {
			obj.add(new BasicDBObject("customScores.rm_b", new BasicDBObject("$lte", Double.parseDouble(rm_b_maxValue))));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<Customer> findUpsellData(String accountId, String accountManager, String customerType, String ignored, 
			String account_score_minValue, String clm_minValue, String dm_minValue, String xa_minValue, String ec_minValue, String rm_b_minValue, 
			String account_score_maxValue, String clm_maxValue, String dm_maxValue, String xa_maxValue, String ec_maxValue, String rm_b_maxValue,
			String sortby, boolean ascending, int skip, int limit) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		obj.add(new BasicDBObject("deletedAt", null));

		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		
		List<Customer> customers = new ArrayList<Customer>();
		
		if(!StringHelper.isEmpty(account_score_minValue) && !StringHelper.isEmpty(account_score_maxValue)) {
			obj.add(new BasicDBObject("customScores.account_score", new BasicDBObject("$gte", Double.parseDouble(account_score_minValue)).append("$lte", Double.parseDouble(account_score_maxValue))));
		} else if(!StringHelper.isEmpty(account_score_minValue)) {
			obj.add(new BasicDBObject("customScores.account_score", new BasicDBObject("$gte", Double.parseDouble(account_score_minValue))));
		} else if(!StringHelper.isEmpty(account_score_maxValue)) {
			obj.add(new BasicDBObject("customScores.account_score", new BasicDBObject("$lte", Double.parseDouble(account_score_maxValue))));
		}
		
		if(!StringHelper.isEmpty(clm_minValue) && !StringHelper.isEmpty(clm_maxValue)) {
			obj.add(new BasicDBObject("customScores.clm", new BasicDBObject("$gte", Double.parseDouble(clm_minValue)).append("$lte", Double.parseDouble(clm_maxValue))));
		} else if(!StringHelper.isEmpty(clm_minValue)) {
			obj.add(new BasicDBObject("customScores.clm", new BasicDBObject("$gte", Double.parseDouble(clm_minValue))));
		} else if(!StringHelper.isEmpty(clm_maxValue)) {
			obj.add(new BasicDBObject("customScores.clm", new BasicDBObject("$lte", Double.parseDouble(clm_maxValue))));
		}
		
		if(!StringHelper.isEmpty(dm_minValue) && !StringHelper.isEmpty(dm_maxValue)) {
			obj.add(new BasicDBObject("customScores.dm", new BasicDBObject("$gte", Double.parseDouble(dm_minValue)).append("$lte", Double.parseDouble(dm_maxValue))));
		} else if(!StringHelper.isEmpty(dm_minValue)) {
			obj.add(new BasicDBObject("customScores.dm", new BasicDBObject("$gte", Double.parseDouble(dm_minValue))));
		} else if(!StringHelper.isEmpty(dm_maxValue)) {
			obj.add(new BasicDBObject("customScores.dm", new BasicDBObject("$lte", Double.parseDouble(dm_maxValue))));
		}
		
		if(!StringHelper.isEmpty(xa_minValue) && !StringHelper.isEmpty(xa_maxValue)) {
			obj.add(new BasicDBObject("customScores.xa", new BasicDBObject("$gte", Double.parseDouble(xa_minValue)).append("$lte", Double.parseDouble(xa_maxValue))));
		} else if(!StringHelper.isEmpty(xa_minValue)) {
			obj.add(new BasicDBObject("customScores.xa", new BasicDBObject("$gte", Double.parseDouble(xa_minValue))));
		} else if(!StringHelper.isEmpty(xa_maxValue)) {
			obj.add(new BasicDBObject("customScores.xa", new BasicDBObject("$lte", Double.parseDouble(xa_maxValue))));
		}
		
		if(!StringHelper.isEmpty(ec_minValue) && !StringHelper.isEmpty(ec_maxValue)) {
			obj.add(new BasicDBObject("customScores.ec", new BasicDBObject("$gte", Double.parseDouble(ec_minValue)).append("$lte", Double.parseDouble(ec_maxValue))));
		} else if(!StringHelper.isEmpty(ec_minValue)) {
			obj.add(new BasicDBObject("customScores.ec", new BasicDBObject("$gte", Double.parseDouble(ec_minValue))));
		} else if(!StringHelper.isEmpty(ec_maxValue)) {
			obj.add(new BasicDBObject("customScores.ec", new BasicDBObject("$lte", Double.parseDouble(ec_maxValue))));
		}
		
		if(!StringHelper.isEmpty(rm_b_minValue) && !StringHelper.isEmpty(rm_b_maxValue)) {
			obj.add(new BasicDBObject("customScores.rm_b", new BasicDBObject("$gte", Double.parseDouble(rm_b_minValue)).append("$lte", Double.parseDouble(rm_b_maxValue))));
		} else if(!StringHelper.isEmpty(rm_b_minValue)) {
			obj.add(new BasicDBObject("customScores.rm_b", new BasicDBObject("$gte", Double.parseDouble(rm_b_minValue))));
		} else if(!StringHelper.isEmpty(rm_b_maxValue)) {
			obj.add(new BasicDBObject("customScores.rm_b", new BasicDBObject("$lte", Double.parseDouble(rm_b_maxValue))));
		}
		
		if(!sortby.equalsIgnoreCase("name")) {
			sortby = "customScores." + sortby;
		}
		
		query.put("$and", obj);
		DBCursor<Customer> cursor = getJCol().find(query).sort(new BasicDBObject(sortby, (ascending) ? 1 : -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	
	public Set<Object> getDistinctCustomFieldValuesEnhanced(String accountId, String customField, String ignored, 
			String partner, String accountManager, String csm, String cem, String customerType) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(csm)) {
			obj.add(new BasicDBObject("csm", csm));
		}
		if(!StringHelper.isEmpty(cem)) {
			obj.add(new BasicDBObject("cem", cem));
		}
		if(!StringHelper.isEmpty(partner)) {
			obj.add(new BasicDBObject("partnerId", partner));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		query.put("$and", obj);
		Set<Object> values = new HashSet<Object>();
		DBCursor<Customer> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			Customer customer = cursor.next();
			if(customer.getCustomFields() != null) {
				for(Field field : customer.getCustomFields()) {
					if(field.getName().equalsIgnoreCase(customField) && field.getValue() != null) {
						values.add(field.getValue());
					}
				}
			}
		}
		return values;
	}
	
	
	
	
	public long countByCustomFieldNameAndValue(String accountId, String ignored, 
			String partner, String accountManager, String csm, String cem, String customerType, String customField, Object value) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(csm)) {
			obj.add(new BasicDBObject("csm", csm));
		}
		if(!StringHelper.isEmpty(cem)) {
			obj.add(new BasicDBObject("cem", cem));
		}
		if(!StringHelper.isEmpty(partner)) {
			obj.add(new BasicDBObject("partnerId", partner));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		obj.add(new BasicDBObject("customFields", new BasicDBObject("$elemMatch", new BasicDBObject("name", customField).append("value", value))));
		query.put("$and", obj);
		
		return getJCol().count(query);
	}
	
	public Customer findCustomerWithDomainsOrWebsitePattern(String accountId, String pattern) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("externalId", new BasicDBObject("$regex", Pattern.compile(pattern, 2))));
		orList.add(new BasicDBObject("website", new BasicDBObject("$regex", Pattern.compile(pattern, 2))));
		orList.add(new BasicDBObject("domains", new BasicDBObject("$elemMatch", new BasicDBObject("$regex", Pattern.compile(pattern, 2)))));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		
		andList.add(orQuery);
		
		andQuery.put("$and", andList);
		
		return getJCol().findOne(andQuery);
	}
	
	public List<String> getDistinctCSMs(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		/*if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypeId", customerTypeId));
		}*/
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("csm", andQuery);
	}
	
	public List<String> getDistinctCSRs(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("csr", andQuery);
	}
	
	
	
	public List<String> getDistinctSalespersons(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("salesperson", andQuery);
	}
	
	public List<String> getDistinctCEMs(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		/*if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypeId", customerTypeId));
		}*/
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("cem", andQuery);
	}
	
	public List<Customer> findByWatcher(String accountId, String watcherId, String customerType, String partner, String accountManager, String csm, String cem, String ignored, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		
		if(!StringHelper.isEmpty(partner)) {
			obj.add(new BasicDBObject("partnerId", partner));
		}
		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(csm)) {
			obj.add(new BasicDBObject("csm", csm));
		}
		if(!StringHelper.isEmpty(cem)) {
			obj.add(new BasicDBObject("cem", cem));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		if(!StringHelper.isEmpty(watcherId)) {
			obj.add(new BasicDBObject("watchers", new BasicDBObject("$elemMatch", new BasicDBObject("userId", watcherId))));
		}

		andQuery.put("$and", obj);

		DBCursor<Customer> cursor = getJCol().find(andQuery).sort(new BasicDBObject("normalizedName", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Customer> customers = new ArrayList<Customer>();
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}

	public boolean isWatcher(String accountId, String customerId, String watcherId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));

		if(!StringHelper.isEmpty(watcherId)) {
			obj.add(new BasicDBObject("watchers", new BasicDBObject("$elemMatch", new BasicDBObject("userId", watcherId))));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("_id", new ObjectId(customerId)));
		}
		andQuery.put("$and", obj);
		return (getJCol().count(andQuery) > 0) ? true : false;
	}

	public long countByWatcher(String accountId, String watcherId, String customerType, String partner, String accountManager, String csm, String cem, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		
		if(!StringHelper.isEmpty(partner)) {
			obj.add(new BasicDBObject("partnerId", partner));
		}
		if(!StringHelper.isEmpty(accountManager)) {
			obj.add(new BasicDBObject("accountManager", accountManager));
		}
		if(!StringHelper.isEmpty(csm)) {
			obj.add(new BasicDBObject("csm", csm));
		}
		if(!StringHelper.isEmpty(cem)) {
			obj.add(new BasicDBObject("cem", cem));
		}
		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
		if(!StringHelper.isEmpty(watcherId)) {
			obj.add(new BasicDBObject("watchers", new BasicDBObject("$elemMatch", new BasicDBObject("userId", watcherId))));
		}

		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	

	public List<Customer> findCustomersForMyView(String accountId, String watcher, String ignored, String partner, String customerTypeId,
			String accountManager, String csm, String cem, int skip, int limit) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		
		if(!StringHelper.isEmpty(accountManager)) {
			orList.add(new BasicDBObject("accountManager", new BasicDBObject("$regex", Pattern.compile(accountManager, 2))));
		}
		if(!StringHelper.isEmpty(csm)) {
			orList.add(new BasicDBObject("csm", new BasicDBObject("$regex", Pattern.compile(csm, 2))));
		}
		if(!StringHelper.isEmpty(cem)) {
			orList.add(new BasicDBObject("cem", new BasicDBObject("$regex", Pattern.compile(cem, 2))));
		}
		if(!StringHelper.isEmpty(watcher)) {
			orList.add(new BasicDBObject("watchers", new BasicDBObject("$elemMatch", new BasicDBObject("userId", watcher))));
		}
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("ignored", ignored));
		if(!StringHelper.isEmpty(customerTypeId)) {
			andList.add(new BasicDBObject("customerTypeId", customerTypeId));
		}
		andList.add(orQuery);
		
		andQuery.put("$and", andList);
		
		List<Customer> customers = new ArrayList<Customer>();
		DBCursor<Customer> cursor = getJCol().find(andQuery).sort(new BasicDBObject("normalizedName", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	
	public long countCustomersForMyView(String accountId, String watcher, String ignored, String partner, String customerTypeId,
			String accountManager, String csm, String cem) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		
		if(!StringHelper.isEmpty(accountManager)) {
			orList.add(new BasicDBObject("accountManager", new BasicDBObject("$regex", Pattern.compile(accountManager, 2))));
		}
		if(!StringHelper.isEmpty(csm)) {
			orList.add(new BasicDBObject("csm", new BasicDBObject("$regex", Pattern.compile(csm, 2))));
		}
		if(!StringHelper.isEmpty(cem)) {
			orList.add(new BasicDBObject("cem", new BasicDBObject("$regex", Pattern.compile(cem, 2))));
		}
		if(!StringHelper.isEmpty(watcher)) {
			orList.add(new BasicDBObject("watchers", new BasicDBObject("$elemMatch", new BasicDBObject("userId", watcher))));
		}
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("ignored", ignored));
		if(!StringHelper.isEmpty(customerTypeId)) {
			andList.add(new BasicDBObject("customerTypeId", customerTypeId));
		}
		andList.add(orQuery);
		
		andQuery.put("$and", andList);
		return getJCol().count(andQuery);
	}

	
	
	public List<String> getDistinctCountries(String accountId, Map<String, Object> paramMap) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
			
		andQuery.put("$and", obj);
		return getJCol().distinct("country", andQuery);
	}
	
	public List<Customer> findCustomersByPattern(String accountId, String pattern, int skip, int limit) {
		/*BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("name", new BasicDBObject("$regex", Pattern.compile(pattern, 2))));
		orList.add(new BasicDBObject("externalId", new BasicDBObject("$regex", Pattern.compile(pattern, 2))));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(orQuery);
		
		andQuery.put("$and", andList);
		
		BasicDBObject fields = new BasicDBObject();
		fields.put("externalId", 1);
		fields.put("name", 1);
		fields.put("normalizedName", 1);
		fields.put("ignored", 1);
		fields.put("customerTypes", 1);
		
		fields.put("csm", 1);
		fields.put("csr", 1);
		fields.put("salesperson", 1);
		
		List<Customer> customers = new ArrayList<Customer>();
		DBCursor<Customer> cursor = getJCol().find(andQuery, fields).sort(new BasicDBObject("normalizedName", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;*/
		
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		
		BasicDBObject regex1 = new BasicDBObject();
		regex1.append("$regex", "^(?)" + Pattern.quote(pattern));
		regex1.append("$options", "i");
		
		orList.add(new BasicDBObject("name", regex1));
		orList.add(new BasicDBObject("externalId", regex1));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("deletedAt", null));
		andList.add(orQuery);
		
		andQuery.put("$and", andList);
		
		BasicDBObject fields = new BasicDBObject();
		fields.put("externalId", 1);
		fields.put("name", 1);
		fields.put("normalizedName", 1);
		fields.put("ignored", 1);
		fields.put("customerTypes", 1);
		
		fields.put("csm", 1);
		fields.put("csr", 1);
		fields.put("salesperson", 1);
		
		List<Customer> customers = new ArrayList<Customer>();
		DBCursor<Customer> cursor = getJCol().find(andQuery, fields).sort(new BasicDBObject("normalizedName", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	
	
	public long countByCustomFieldNameAndValue(String accountId, Map<String, Object> paramMap, String customField, Object value) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
		
		obj.add(new BasicDBObject("customFields", new BasicDBObject("$elemMatch", new BasicDBObject("name", customField).append("value", value))));
		query.put("$and", obj);
		
		return getJCol().count(query);
	}
	
	
	public Set<Object> getDistinctCustomFieldValuesEnhanced(String accountId, String customField, Map<String, Object> paramMap) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
		
		query.put("$and", obj);
		Set<Object> values = new HashSet<Object>();
		DBCursor<Customer> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			Customer customer = cursor.next();
			if(customer.getCustomFields() != null) {
				for(Field field : customer.getCustomFields()) {
					if(field.getName().equalsIgnoreCase(customField) && field.getValue() != null) {
						values.add(field.getValue());
					}
				}
			}
		}
		return values;
	}
	
	public List<String> getDistinctAccountManagersNew(String accountId, Map<String, Object> paramMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("accountManager", andQuery);
	}
	
	public List<String> getDistinctSalesPersons(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("salesperson", andQuery);
	}
	
	public List<String> getDistinctPSManagers(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("psManager", andQuery);
	}
	public long countByAccountEnhanced(String accountId, Map<String, String> standardParams, Map<String, String> customParams, List<Field> customFields) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", standardParams.get("ignored")));
		obj.add(new BasicDBObject("deletedAt", null));

		if(!StringHelper.isEmpty(standardParams.get("supportlevel"))) {
			obj.add(new BasicDBObject("supportLevel", standardParams.get("supportlevel")));
		}
		if(!StringHelper.isEmpty(standardParams.get("partner"))) {
			obj.add(new BasicDBObject("partnerId", standardParams.get("partner")));
		}
		if(!StringHelper.isEmpty(standardParams.get("installationType"))) {
			obj.add(new BasicDBObject("licenses.installationType", standardParams.get("installationType")));
		}
		if(!StringHelper.isEmpty(standardParams.get("licenseType"))) {
			obj.add(new BasicDBObject("licenses.licenseType", standardParams.get("licenseType")));
		}
		if(!StringHelper.isEmpty(standardParams.get("accountManager"))) {
			obj.add(new BasicDBObject("accountManager", standardParams.get("accountManager")));
		}
		if(!StringHelper.isEmpty(standardParams.get("age"))) {
			obj.add(new BasicDBObject("age", standardParams.get("age")));
		}
		if(!StringHelper.isEmpty(standardParams.get("users"))) {
			obj.add(new BasicDBObject("users", standardParams.get("users")));
		}
		if(!StringHelper.isEmpty(standardParams.get("health"))) {
			obj.add(new BasicDBObject("healthy", Boolean.parseBoolean(standardParams.get("health"))));
		}
		if(!StringHelper.isEmpty(standardParams.get("mrrStatus"))) {
			obj.add(new BasicDBObject("mrrStatus", standardParams.get("mrrStatus")));
		}
		if(!StringHelper.isEmpty(standardParams.get("mrrRange"))) {
			obj.add(new BasicDBObject("mrrRange", standardParams.get("mrrRange")));
		}
		if(!StringHelper.isEmpty(standardParams.get("customerType"))) {
			obj.add(new BasicDBObject("customerTypes", standardParams.get("customerType")));
		}
		if(!StringHelper.isEmpty(standardParams.get("profileRisk"))) {
			obj.add(new BasicDBObject("profileRisk", standardParams.get("profileRisk")));
		}
		if(!StringHelper.isEmpty(standardParams.get("behaviorRisk"))) {
			obj.add(new BasicDBObject("behaviorRisk", standardParams.get("behaviorRisk")));
		}
		if(!StringHelper.isEmpty(standardParams.get("trafficStatus"))) {
			obj.add(new BasicDBObject("traficStatus", standardParams.get("trafficStatus")));
		}
		if(!StringHelper.isEmpty(standardParams.get("csmFilter"))) {
			obj.add(new BasicDBObject("csm", standardParams.get("csmFilter")));
		}
		if(!StringHelper.isEmpty(standardParams.get("csrFilter"))) {
			obj.add(new BasicDBObject("csr", standardParams.get("csrFilter")));
		}
		if(!StringHelper.isEmpty(standardParams.get("cemFilter"))) {
			obj.add(new BasicDBObject("cem", standardParams.get("cemFilter")));
		}	
		if(!StringHelper.isEmpty(standardParams.get("salesManagerFilter"))) {
			obj.add(new BasicDBObject("salesperson", standardParams.get("salesManagerFilter")));
		}
		if(!StringHelper.isEmpty(standardParams.get("psManagerFilter"))) {
			obj.add(new BasicDBObject("psManager", standardParams.get("psManagerFilter")));
		}	
		if(!StringHelper.isEmpty(standardParams.get("currentTerm"))) {
			obj.add(new BasicDBObject("currentTerm", Long.parseLong(standardParams.get("currentTerm"))));
		}
		if(!StringHelper.isEmpty(standardParams.get("groupsFilter"))) {
			obj.add(new BasicDBObject("groups", standardParams.get("groupsFilter")));
		}
		if(!StringHelper.isEmpty(standardParams.get("age3Months"))) {
			obj.add(new BasicDBObject("age3Months", true));
		}

		if(!StringHelper.isEmpty(standardParams.get("age6Months"))) {
			obj.add(new BasicDBObject("age6Months", true));
		}
		if(customParams != null) {
			boolean groupsStructure = true;
			Customer c = findOne(new BasicDBObject("accountId", accountId));
			if(c != null && c.getCustomFields() != null && c.getCustomFields().size() > 0) {
				groupsStructure = false;
			}
			for(Map.Entry<String, String> entry : customParams.entrySet()) {
				for(com.crucialbits.cy.model.Field field : customFields) {
					if(field.getName().equals(entry.getKey()) && !StringHelper.isEmpty(entry.getValue()) && groupsStructure) {
						obj.add(new BasicDBObject("fieldGroups.fields.name", entry.getKey()));
						obj.add(new BasicDBObject("fieldGroups.fields.response", Utility.getInstance().resolveFieldType(entry.getValue(), field)));
					} else if(field.getName().equals(entry.getKey()) && !StringHelper.isEmpty(entry.getValue()) && !groupsStructure){
						obj.add(new BasicDBObject("customFields", new BasicDBObject("$elemMatch", new BasicDBObject("name", entry.getKey()).append("value", Utility.getInstance().resolveFieldType(entry.getValue(), field)))));
					}
				}
			}
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<Customer> findCustomersForNormalization(String accountId, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("normalizedName", null));
		andQuery.put("$and", obj);
		DBCursor<Customer> cursor = getJCol().find(andQuery).sort(new BasicDBObject("externalId", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Customer> customers = new ArrayList<Customer>();
		while (cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	
	public List<Customer> findNewCustomers(String accountId, String ignored, Date from, Date to, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		if(from == null && to != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$lte", to)));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
		}
		andQuery.put("$and", obj);
		DBCursor<Customer> cursor = getJCol().find(andQuery).sort(new BasicDBObject("normalizedName", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Customer> customers = new ArrayList<Customer>();
		while (cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	
	public long countCustomersByGroupId(String accountId, String groupId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("groups", groupId));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<String> getDistinctGroups(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("ignored", ignored));
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypes", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("groups", andQuery);
	}
	
	public Customer findCustomerByPattern(String accountId, String name) {

		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("name",  Pattern.compile(name, 2)));

		andQuery.put("$and", obj);
		
		return getJCol().findOne(andQuery);
	}
	
	public List<Customer> findGroupedCustomers(String accountId, String groupId, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("groups", groupId));
		andQuery.put("$and", obj);
		DBCursor<Customer> cursor = getJCol().find(andQuery).sort(new BasicDBObject("normalizedName", 1).append("externalId", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Customer> customers = new ArrayList<Customer>();
		while (cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	
	public List<Customer> findCustomersByInIds(String accountId, List<ObjectId> ids, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		if(ids != null && ids.size() > 0) {
			andList.add(new BasicDBObject("_id", new BasicDBObject("$in", ids)));
		}
		andQuery.put("$and", andList);
		
		BasicDBObject fields = new BasicDBObject();
		fields.put("externalId", 1);
		fields.put("name", 1);
		fields.put("normalizedName", 1);
		fields.put("ignored", 1);
		fields.put("customerTypes", 1);
		
		fields.put("csm", 1);
		fields.put("csr", 1);
		fields.put("salesperson", 1);
		
		List<Customer> customers = new ArrayList<Customer>();
		DBCursor<Customer> cursor = getJCol().find(andQuery, fields).sort(new BasicDBObject("normalizedName", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	
	public Customer findByAccountAndPattern(String accountId, String pattern) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("name", Pattern.compile(pattern, 2)));
		query.put("$and", obj);
		return getJCol().findOne(query);
	}
}