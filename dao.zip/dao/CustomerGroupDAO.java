package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.CustomerGroup;
import com.crucialbits.cy.model.SimpleeTransaction;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class CustomerGroupDAO extends BaseDAO<CustomerGroup>{

	public CustomerGroupDAO() {
		String collectionName = "customergroup";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), CustomerGroup.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	
	public void buildIndexes() {
		
	}
	
	
	public long countByCustomerGroupName(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	public List<String> getDistinctGroups(String accountId, String customerTypeId, String ignored) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		andQuery.put("$and", obj);
		return getJCol().distinct("groups", andQuery);
	}
	
	public List<CustomerGroup> findCustomerGroups(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		andQuery.put("$and", obj);
		DBCursor<CustomerGroup> cursor = getJCol().find(andQuery).sort(new BasicDBObject("groupName", 1));
		
		List<CustomerGroup> customerGroups = new ArrayList<CustomerGroup>();
		while (cursor.hasNext()) {
			customerGroups.add(cursor.next());
		}
		return customerGroups;
	}
}
