
package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.CustomerTaskPriority;
import com.crucialbits.cy.app.Constants.CustomerTaskStatus;
import com.crucialbits.cy.model.CustomerTask;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class CustomerTaskDAO extends BaseDAO<CustomerTask>{
	public CustomerTaskDAO() {
		String collectionName = "customertask";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), CustomerTask.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));	
	}
	
	public List<CustomerTask> findFilteredTasks(String accountId, List<String> customerIds,
			String priority, String status, String assignee, String sortBy, Boolean ascending, int skip, int limit) {
		List<CustomerTask> tasks = new ArrayList<CustomerTask>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(accountId)) {
			obj.add(new BasicDBObject("accountId", accountId));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", CustomerTaskPriority.valueOf(priority.toUpperCase())));
		}
		if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("!COMPLETED")) {
			String[] statusList = {CustomerTaskStatus.NOTSTARTED.toString(), CustomerTaskStatus.IN_PROGRESS.toString()};
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		} else
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", CustomerTaskStatus.valueOf(status.toUpperCase())));
		}
		if(!StringHelper.isEmpty(assignee)) {
			obj.add(new BasicDBObject("assignedTo", assignee));
		}
		
		andQuery.put("$and", obj);
		
		DBCursor<CustomerTask> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, (ascending) ? 1 : -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			tasks.add(cursor.next());
		}
		
		return tasks;
	}
	
	public long countFilteredTasks(String accountId, List<String> customerIds,
			String priority, String status, String assignee) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(accountId)) {
			obj.add(new BasicDBObject("accountId", accountId));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", CustomerTaskPriority.valueOf(priority.toUpperCase())));
		}
		if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("!COMPLETED")) {
			String[] statusList = {CustomerTaskStatus.NOTSTARTED.toString(), CustomerTaskStatus.IN_PROGRESS.toString()};
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		} else
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", CustomerTaskStatus.valueOf(status.toUpperCase())));
		}
		if(!StringHelper.isEmpty(assignee)) {
			obj.add(new BasicDBObject("assignedTo", assignee));
		}
		
		andQuery.put("$and", obj);
		
		return getJCol().count(andQuery);
	}
	

	public List<CustomerTask> findAllByMonth(String accountId, List<String> customerIds,
			Date from, Date to ) {
		List<CustomerTask> cts = new ArrayList<CustomerTask>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));
		}

		obj.add(new BasicDBObject("dueDate", new BasicDBObject("$gte", from).append("$lte", to)));
		andQuery.put("$and", obj);
		DBCursor<CustomerTask> cursor = getJCol().find(andQuery);
		while (cursor.hasNext()) {
			cts.add(cursor.next());
		}
		return cts;
	}
	
	public List<CustomerTask> findCustomerTasksByDateRange(String accountId, String assignedTo, Date from, Date to, String type) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(assignedTo)) {
			obj.add(new BasicDBObject("assignedTo", assignedTo));
		}
		if(from != null && to != null) {
			if(!StringHelper.isEmpty(type) && type.equals("NEW")) {
				obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
			} else if(!StringHelper.isEmpty(type) && type.equals("ALL")) {
				obj.add(new BasicDBObject("updatedAt", new BasicDBObject("$gte", from).append("$lte", to)));
			}
		}
		if(from == null && to != null) {
			if(!StringHelper.isEmpty(type) && type.equals("NEW")) {
				obj.add(new BasicDBObject("createdAt", new BasicDBObject("$lte", to)));
			} else if(!StringHelper.isEmpty(type) && type.equals("ALL")) {
				obj.add(new BasicDBObject("updatedAt", new BasicDBObject("$lte", to)));
			}
		}
		andQuery.put("$and", obj);
		
		DBCursor<CustomerTask> cursor = getJCol().find(andQuery).sort(new BasicDBObject("dueDate", 1));
		List<CustomerTask> tasks = new ArrayList<CustomerTask>();
		while (cursor.hasNext()) {
			tasks.add(cursor.next());
		}
		return tasks;
	}
	
	public List<CustomerTask> findCustomerTasksByNotComletedStatus(String accountId, String assignedTo, String type) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(type) && !type.equals("All")) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$ne", CustomerTaskStatus.COMPLETED)));
		}
		if(!StringHelper.isEmpty(assignedTo)) {
			obj.add(new BasicDBObject("assignedTo", assignedTo));
		}
		andQuery.put("$and", obj);
		
		DBCursor<CustomerTask> cursor = getJCol().find(andQuery).sort(new BasicDBObject("dueDate", 1));
		List<CustomerTask> tasks = new ArrayList<CustomerTask>();
		while (cursor.hasNext()) {
			tasks.add(cursor.next());
		}
		return tasks;
	}

	public long countAll(String accountId, List<String> customerIds,
			Date from, Date to ) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));

		obj.add(new BasicDBObject("dueDate", new BasicDBObject("$gte", from)));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}