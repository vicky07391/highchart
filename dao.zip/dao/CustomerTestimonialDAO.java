package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.CustomerNote;
import com.crucialbits.cy.model.CustomerTestimonial;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class CustomerTestimonialDAO extends BaseDAO<CustomerTestimonial>{
	public CustomerTestimonialDAO() {
		String collectionName = "customertestimonial";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), CustomerTestimonial.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {		
		/*BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("customerId", 1);
		compoundIndex.put("accountId", 1);
		compoundIndex.put("note", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);*/
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
//        getJCol().ensureIndex(new BasicDBObject("note", 1), new BasicDBObject("background", true));
	}
	
	public List<CustomerTestimonial> findActiveTestimonials(String accountId, String customerId, String sortBy, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerId)){
		obj.add(new BasicDBObject("customerId", customerId));
		}
		obj.add(new BasicDBObject("deletedAt", null));
		andQuery.put("$and", obj);
		List<CustomerTestimonial> testimonials = new ArrayList<CustomerTestimonial>();
		DBCursor<CustomerTestimonial> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			testimonials.add(cursor.next());
		}
		return testimonials;
	}
	
	public long countTestimonials(String accountId, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerId)){
		obj.add(new BasicDBObject("customerId", customerId));
		}
		obj.add(new BasicDBObject("deletedAt", null));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	

}
