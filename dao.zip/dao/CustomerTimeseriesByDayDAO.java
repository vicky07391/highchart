package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.CustomerTimeseriesByDay;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class CustomerTimeseriesByDayDAO extends BaseDAO<CustomerTimeseriesByDay> {

	public CustomerTimeseriesByDayDAO() {
		String collectionName = "customertimeseriesbyday";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), CustomerTimeseriesByDay.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("customerId", 1);
		compoundIndex.put("accountId", 1);
		compoundIndex.put("date", 1);
		compoundIndex.put("fieldName", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(compoundIndex, options);

        BasicDBObject compoundIndex2 = new BasicDBObject();
        compoundIndex2.put("customerId", 1);
        compoundIndex2.put("accountId", 1);
        compoundIndex2.put("fieldName", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));

        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("accountId", 1);
        compoundIndex3.put("fieldName", 1);
        compoundIndex3.put("date", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));

		getJCol().ensureIndex(new BasicDBObject("indexed", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("date", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("fieldName", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("fieldValue", 1), new BasicDBObject("background", true));
	}

	public List<CustomerTimeseriesByDay> getData(String accountId, String customerId, String fieldName, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("fieldName", fieldName));
		if(from != null && today != null) {
			obj.add(new BasicDBObject("date", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		andQuery.put("$and", obj);
		List<CustomerTimeseriesByDay> dates = new ArrayList<CustomerTimeseriesByDay>();
		DBCursor<CustomerTimeseriesByDay> cursor = getJCol().find(andQuery).sort(new BasicDBObject("date", 1));
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}

	public List<CustomerTimeseriesByDay> getDataForMetricsChange(String accountId, String customerId, String fieldName, Date date) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("fieldName", fieldName));
		if(date != null) {
			obj.add(new BasicDBObject("date", new BasicDBObject("$gte", date)));
		}
		andQuery.put("$and", obj);
		List<CustomerTimeseriesByDay> dates = new ArrayList<CustomerTimeseriesByDay>();
		DBCursor<CustomerTimeseriesByDay> cursor = getJCol().find(andQuery).sort(new BasicDBObject("date", -1));
		cursor.skip(0);
		cursor.limit(2);
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}

	public List<CustomerTimeseriesByDay> getDateSpecificData(String accountId, String fieldName, Date from, Date today, int skip, int limit) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("date", from));
		orList.add(new BasicDBObject("date", today));
		orQuery.put("$or", orList);

		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("fieldName", fieldName));

		obj.add(orQuery);

		andQuery.put("$and", obj);
		List<CustomerTimeseriesByDay> dates = new ArrayList<CustomerTimeseriesByDay>();
		DBCursor<CustomerTimeseriesByDay> cursor = getJCol().find(andQuery).sort(new BasicDBObject("customerId", 1));
		cursor.skip(skip);
		cursor.limit(limit);
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}

	public List<CustomerTimeseriesByDay> getDateSpecificData(String accountId, List<String> fieldNames, Date from, int skip, int limit) {

		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("fieldName", new BasicDBObject("$in", fieldNames)));
		obj.add(new BasicDBObject("date", from));

		andQuery.put("$and", obj);
		List<CustomerTimeseriesByDay> dates = new ArrayList<CustomerTimeseriesByDay>();
		DBCursor<CustomerTimeseriesByDay> cursor = getJCol().find(andQuery);
		cursor.skip(skip);
		cursor.limit(limit);
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}

	public List<CustomerTimeseriesByDay> getRawData(String temp, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject("temp", new BasicDBObject("$ne", temp));

		List<CustomerTimeseriesByDay> dates = new ArrayList<CustomerTimeseriesByDay>();
		DBCursor<CustomerTimeseriesByDay> cursor = getJCol().find(andQuery);
		cursor.skip(skip);
		cursor.limit(limit);
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}
	
	public List<CustomerTimeseriesByDay> getUnindexedData(int limit) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("indexed", null));
		obj.add(new BasicDBObject("indexed", false));
		orQuery.put("$or", obj);

		List<CustomerTimeseriesByDay> dates = new ArrayList<CustomerTimeseriesByDay>();
		DBCursor<CustomerTimeseriesByDay> cursor = getJCol().find(orQuery);
		while(cursor.hasNext()) {
			if(dates.size() == limit) {
				break;
			}
			dates.add(cursor.next());
		}
		return dates;
	}
	
	public List<CustomerTimeseriesByDay> getDataWithMulitpleFields(String accountId, String customerId, String[] fieldNames, Date date) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("fieldName", new BasicDBObject("$in", fieldNames)));
		obj.add(new BasicDBObject("date", date));
		
		andQuery.put("$and", obj);
		List<CustomerTimeseriesByDay> dates = new ArrayList<CustomerTimeseriesByDay>();
		DBCursor<CustomerTimeseriesByDay> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}

	
}
