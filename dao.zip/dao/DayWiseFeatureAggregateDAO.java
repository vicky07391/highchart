package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.DayWiseFeatureAggregate;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class DayWiseFeatureAggregateDAO extends BaseDAO<DayWiseFeatureAggregate> {

	public DayWiseFeatureAggregateDAO() {
		String collectionName = "daywiseaggregate";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), DayWiseFeatureAggregate.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("calculatedAt", 1), new BasicDBObject("background", true));
	}
	
	public DayWiseFeatureAggregate getTodaysAggregate(String accountId, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("calculatedAt", new BasicDBObject("$gte", today)));
		
		andQuery.put("$and", obj);
		return findOne(andQuery);
	}
	
	public DayWiseFeatureAggregate getYesterdaysAggregate(String accountId, Date yesterday, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("calculatedAt",  new BasicDBObject("$gte", yesterday).append("$lt", today)));
		
		andQuery.put("$and", obj);
		return findOne(andQuery);
	}
	
	public List<DayWiseFeatureAggregate> findAggregates(String accountId, Date today, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("calculatedAt",  new BasicDBObject("$lte", today)));
		
		andQuery.put("$and", obj);
		
		DBCursor<DayWiseFeatureAggregate> cursor = getJCol().find(andQuery).sort(new BasicDBObject("calculatedAt", -1));
		cursor.skip(0);
		cursor.limit(limit);
		List<DayWiseFeatureAggregate> aggregates = new ArrayList<DayWiseFeatureAggregate>();
		while(cursor.hasNext()) {
			aggregates.add(cursor.next());
		}
		return aggregates;
	}
}
