package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.EmailUser;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class EmailUserDAO extends BaseDAO<EmailUser>{

	public EmailUserDAO () {		
		String collectionName = "emailuser";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), EmailUser.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {		
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("email", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(compoundIndex, options);
        
        getJCol().ensureIndex(new BasicDBObject("email", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
	}
}
