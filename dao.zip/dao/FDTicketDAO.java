package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.client.freshdesk.Ticket;
import com.crucialbits.client.zendesk.Status;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class FDTicketDAO extends BaseDAO<Ticket>{

	public FDTicketDAO() {
		String collectionName = "fdticket";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Ticket.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}	
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("id", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
 
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("id", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("priorityName", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("priority_name", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("statusName", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("status_name", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));

	}
	
	public long countTicketsForDashboard(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	
	public long countAllTicketsForDashboard(String accountId, List<String> statusList, String type, String priority, 
			List<String> customerIds, String recent) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status_name", new BasicDBObject("$in", statusList)));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DAY_OF_MONTH, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countAllOpenTicketsByCustomer(String accountId, String status, String customerId, Date date) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(status)) {
			String[] statusArr = {status};
			obj.add(new BasicDBObject("status_name", new BasicDBObject("$in", statusArr)));
		} 
		obj.add(new BasicDBObject("customerId", customerId));
		
		if(date != null) {
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gte", date)));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<Ticket> findAllOpenTicketsWithCustomerImpact(String accountId, String customerId, List<String> statusList, String type, String priority, List<String> customerIdsByManager, String recent, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status_name", new BasicDBObject("$in", statusList)));
		}
		if(customerIdsByManager != null && customerIdsByManager.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIdsByManager)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority_name", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query).sort(new BasicDBObject("updated_at", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public long countAllOpenTicketsWithCustomerImpact(String accountId, String customerId, List<String> statusList, String type, String priority, List<String> customerIdsByManager, String recent, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status_name", new BasicDBObject("$in", statusList)));
		}
		if(customerIdsByManager != null && customerIdsByManager.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIdsByManager)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority_name", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<String> getDistinctPriority(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().distinct("priority_name", query);
	}
	
	public long countAllTicketsByFilters(String accountId, List<String> statusList, String status, String type, String priority, 
			List<String> customerIds, String customerId, String recent) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status_name", new BasicDBObject("$in", statusList)));
		}
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status_name", status));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DAY_OF_MONTH, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}	
}