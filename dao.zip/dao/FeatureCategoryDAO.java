package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.ContentType;
import com.crucialbits.cy.model.FeatureCategory;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class FeatureCategoryDAO extends BaseDAO<FeatureCategory> {

	public FeatureCategoryDAO() {
		String collectionName = "category";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), FeatureCategory.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("parentId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("urlFriendlyName", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("contentType", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("sectionId", 1), new BasicDBObject("background", true));
	}
	
	public void resetSequenceNumbers(String accountId, String parentId, String sectionId, String contentType) {
		BasicDBObject andQuery = new BasicDBObject();
		
		List<BasicDBObject> searchQuery = new ArrayList<BasicDBObject>();
		searchQuery.add(new BasicDBObject("accountId", accountId));
		searchQuery.add(new BasicDBObject("parentId", parentId));
		searchQuery.add(new BasicDBObject("sectionId", sectionId));
		searchQuery.add(new BasicDBObject("contentType", contentType));
		
		andQuery.put("$and", searchQuery);
		
		BasicDBObject newQuery = new BasicDBObject();
		newQuery.put("$inc", new BasicDBObject("sequence", 1));
		
		getJCol().updateMulti(andQuery, newQuery);
	}
	
	public FeatureCategory findByFriendlyId(String accountId, String friendlyId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("urlFriendlyName", friendlyId));
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
}
