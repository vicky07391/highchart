
package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.FormFieldType;
import com.crucialbits.cy.model.Field;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;
import com.sun.org.apache.xalan.internal.xsltc.compiler.Pattern;

public class FieldDAO extends BaseDAO<Field> {

	public FieldDAO() {
		String collectionName = "field";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Field.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("type", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("name", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("label", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("entity", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("isTimeSeries", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("isSalesforce", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("isDisabled", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("isReadOnly", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("mappedWithFieldName", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("formFieldType", 1), new BasicDBObject("background", true));
	}
	
	public List<Field> findCustomByEntityForCustomer(String accountId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	

	public List<Field> findCustomByEntity(String accountId, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("entity", entity));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	

	public Field findCustomFieldByNameForCustomer(String accountId, String name) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("name", name));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andQuery.put("$and", andList);
		
		return getJCol().findOne(andQuery);
	}
	

	public List<Field> findCustomTimeseriesFieldsByEntity(String accountId, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("entity", entity));
		andList.add(new BasicDBObject("isTimeSeries", true));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public List<Field> findCustomTimeseriesFieldsForCustomer(String accountId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("isTimeSeries", true));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	
	public List<Field> findCustomTimeseriesFieldsForLicense(String accountId) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("isTimeSeries", true));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andList.add(new BasicDBObject("entity", "CONTRACT"));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public long countCustomByEntity(String accountId, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(accountId)) {
			andList.add(new BasicDBObject("accountId", accountId));
		}
		if(!StringHelper.isEmpty(entity)) {
			andList.add(new BasicDBObject("entity", entity));
		}
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andQuery.put("$and", andList);
		
		return getJCol().count(andQuery);
	}
	
	public List<Field> findStandardByEntity(String accountId, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("entity", entity));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.STANDARD));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public List<Field> searchTimeseriesFieldsForCustomer(String accountId, String pattern) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		if(!StringHelper.isEmpty(pattern)) {
			andList.add(new BasicDBObject("name", java.util.regex.Pattern.compile(pattern, 2)));
		}
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("isTimeSeries", true));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public List<Field> searchTimeseriesFieldsByEntity(String accountId, String pattern, String entity) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(pattern)) {
			andList.add(new BasicDBObject("name", java.util.regex.Pattern.compile(pattern, 2)));
		}
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("entity", entity));
		andList.add(new BasicDBObject("isTimeSeries", true));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public Field findFieldByNameForCustomer(String accountId, String name) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("name", name));
		andQuery.put("$and", andList);
		
		return getJCol().findOne(andQuery);
	}
	
	public Field findFieldByNameForEntity(String accountId, String name, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("name", name));
		andList.add(new BasicDBObject("entity", entity));
		andQuery.put("$and", andList);
		
		return getJCol().findOne(andQuery);
	}
	
	public List<Field> findCustomByEntityForCustomerLicense(String accountId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CONTRACT"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public List<Field> findCustomZendeskWidgetFieldsForCustomer(String accountId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("showOnZendeskWidget", true));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.CUSTOM));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public List<Field> findStandardZendeskWidgetFieldsForCustomer(String accountId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("showOnZendeskWidget", true));
		andList.add(new BasicDBObject("formFieldType", FormFieldType.STANDARD));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public List<Field> findFieldsByFormFieldTypeForCustomer(String accountId, FormFieldType formFieldType) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("formFieldType", formFieldType));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public List<Field> findFieldsByFormFieldType(String accountId, String entity, FormFieldType formFieldType) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("formFieldType", formFieldType));
		andList.add(new BasicDBObject("entity", entity));
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
	
	public List<Field> findFieldsByFormFieldTypeForCustomer(String accountId, FormFieldType formFieldType, Map<String, Object> classMap) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("formFieldType", formFieldType));
		
		if(classMap != null) {
			for(Map.Entry<String, Object> entry : classMap.entrySet()) {
				andList.add(new BasicDBObject(entry.getKey(), entry.getValue()));
			}
		}
		
		andQuery.put("$and", andList);
		
		List<Field> fields = new ArrayList<Field>();
		DBCursor<Field> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			fields.add(cursor.next());
		}
		return fields;
	}
}