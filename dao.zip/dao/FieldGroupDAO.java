package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.FieldGroup;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class FieldGroupDAO extends BaseDAO<FieldGroup> {

	public FieldGroupDAO() {
		String collectionName = "fieldgroup";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), FieldGroup.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("name", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("label", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("isMultiple", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("entity", 1), new BasicDBObject("background", true));
	}
	
	public List<FieldGroup> findByEntityForCustomer(String accountId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andQuery.put("$and", andList);
		
		List<FieldGroup> groups = new ArrayList<FieldGroup>();
		DBCursor<FieldGroup> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			groups.add(cursor.next());
		}
		return groups;
	}
	
	public List<FieldGroup> findNonRepeatableByEntityForCustomer(String accountId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("isMultiple", false));
		andQuery.put("$and", andList);
		
		List<FieldGroup> groups = new ArrayList<FieldGroup>();
		DBCursor<FieldGroup> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			groups.add(cursor.next());
		}
		return groups;
	}
	
	public List<FieldGroup> findRepeatableByEntityForCustomer(String accountId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("entity", null));
		orList.add(new BasicDBObject("entity", "CUSTOMER"));
		orList.add(new BasicDBObject("entity", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("isMultiple", true));
		andQuery.put("$and", andList);
		
		List<FieldGroup> groups = new ArrayList<FieldGroup>();
		DBCursor<FieldGroup> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			groups.add(cursor.next());
		}
		return groups;
	}
	
	public List<FieldGroup> findByEntity(String accountId, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("entity", entity));
		andQuery.put("$and", andList);
		
		List<FieldGroup> groups = new ArrayList<FieldGroup>();
		DBCursor<FieldGroup> cursor = getJCol().find(andQuery).sort(new BasicDBObject("sequence", 1));
		while(cursor.hasNext()) {
			groups.add(cursor.next());
		}
		return groups;
	}
}
