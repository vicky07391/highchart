package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.client.google.Message;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class GMessageDAO extends BaseDAO<Message> {

	public GMessageDAO() {
		String collectionName = "gmessage";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Message.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("id", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
	}
	
	public List<String> getDistinctThreadIdsByMailbox(String accountId, String gId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("gId", gId));
		query.put("$and", obj);
		
		return getJCol().distinct("threadId", query);
	}
	
	public List<Message> getDateSpecificMessage(String accountId, String gId, Date from, Date to) {
		List<Message> messages = new ArrayList<Message>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("gId", gId));
		if(to == null) {
			obj.add(new BasicDBObject("date", new BasicDBObject("$gte", from)));
		} else {
			obj.add(new BasicDBObject("date", new BasicDBObject("$gte", from).append("$lt", to)));
		}
		andQuery.put("$and", obj);
		DBCursor<Message> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			messages.add(cursor.next());
		}
		return messages;
	}
	
	public List<Message> getMonthSpecificMessage(String accountId, String gId, Date from, Date to) {
		System.out.println(from + "\t" + to);
		List<Message> messages = new ArrayList<Message>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("gId", gId));
		obj.add(new BasicDBObject("date", new BasicDBObject("$gte", from).append("$lt", to)));
		andQuery.put("$and", obj);
		DBCursor<Message> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			messages.add(cursor.next());
		}
		return messages;
	}
	
	public long countMessagesByFromAddress(String accountId, String gId, String from) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("gId", gId));
		obj.add(new BasicDBObject("from", from));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public long countUnrespondedMails(String accountId, String gId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("gId", gId));
		obj.add(new BasicDBObject("unresponded", true));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public void findAndUpdateUnrespondedStatus(String accountId, String gId, boolean status) {
		BasicDBObject updateQuery = new BasicDBObject();
		updateQuery.append("$set", new BasicDBObject("unresponded", status));
		
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.append("accountId", accountId).append("gId", gId);
		
		getJCol().updateMulti(searchQuery, updateQuery);
	}
}