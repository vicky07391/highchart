package com.crucialbits.cy.dao;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.ISGAdvisor;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class ISGAdvisorDAO extends BaseDAO<ISGAdvisor>{

	public ISGAdvisorDAO() {
		String collectionName = "isgadvisor";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), ISGAdvisor.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(new BasicDBObject("normalizedUser", 1), options);
	}
	
	public long countByFilters(Map<String, Object> fieldMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(fieldMap != null && fieldMap.size() > 0){
			for(Map.Entry<String, Object> mp : fieldMap.entrySet()){
				if(mp.getKey() != null && mp.getValue() != null ){
					obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
				}
			}
			andQuery.put("$and", obj);
		}
		
		return getJCol().count(andQuery);
	}
	public List<ISGAdvisor> findAdvisorsByPattern(String accountId, String pattern, int skip, int limit) {
	
		/*BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("user",  Pattern.compile(pattern, 2)));
		andQuery.put("$and", andList);
		
		List<ISGAdvisor> advisors = new ArrayList<ISGAdvisor>();
		DBCursor<ISGAdvisor> cursor = getJCol().find(andQuery).sort(new BasicDBObject("user", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			advisors.add(cursor.next());
		}
		return advisors;*/
		
		
		BasicDBObject regex1 = new BasicDBObject();
		regex1.append("$regex", "^(?)" + Pattern.quote(pattern));
		regex1.append("$options", "i");
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("user", regex1));
		
		andQuery.put("$and", andList);
		
		/*BasicDBObject fields = new BasicDBObject();
		fields.put("externalId", 1);
		fields.put("name", 1);
		fields.put("normalizedName", 1);
		fields.put("ignored", 1);
		fields.put("customerTypes", 1);
		
		fields.put("csm", 1);
		fields.put("csr", 1);
		fields.put("salesperson", 1);*/
		
		List<ISGAdvisor> advisors = new ArrayList<ISGAdvisor>();
		DBCursor<ISGAdvisor> cursor = getJCol().find(andQuery).sort(new BasicDBObject("user", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			advisors.add(cursor.next());
		}
		return advisors;
	}

	public List<ISGAdvisor> findAdvisorsByFilter(String accountId, String name, String country, String[] skills, Object[] skillValues, String[] certifications, Object[] certificationValues, String[] languages, Object languageValues[], String[] geographies, Object[] geographyValues, int skip, int limit, String sortBy, boolean ascending) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(name)) {
			obj.add(new BasicDBObject("user", Pattern.compile(name, 2)));
		}
		if(!StringHelper.isEmpty(country)) {
			obj.add(new BasicDBObject("country", country));
		}
		if(skills != null && skills.length > 0) {
			for(String skill : skills) {
				 obj.add(new BasicDBObject("skills." + skill, new BasicDBObject("$in", skillValues)));
			}
		}
		if(certifications != null && certifications.length > 0) {
			for(String certification : certifications) {
				 obj.add(new BasicDBObject("certifications." + certification, new BasicDBObject("$in", certificationValues)));
			}
		}
		if(languages != null && languages.length > 0) {
			for(String language : languages) {
				 obj.add(new BasicDBObject("languages." + language, new BasicDBObject("$in", languageValues)));
			}
		}
		if(geographies != null && geographies.length > 0) {
			for(String geography : geographies) {
				 obj.add(new BasicDBObject("geographies." + geography, new BasicDBObject("$in", geographyValues)));
			}
		}
		
		if(obj.size() > 0) {
			andQuery.put("$and", obj);
		}

		DBCursor<ISGAdvisor> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, (ascending == true ? 1 : -1 )));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<ISGAdvisor> advisors = new ArrayList<ISGAdvisor>();
		while(cursor.hasNext()) {
			advisors.add(cursor.next());
		}
		return advisors;
	}
	
	
	public long countAdvisorsByFilter(String accountId, String name, String country, String[] skills, Object[] skillValues, String[] certifications, Object[] certificationValues, String[] languages, Object languageValues[], String[] geographies, Object[] geographyValues) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(name)) {
			obj.add(new BasicDBObject("user", Pattern.compile(name, 2)));
		}
		if(!StringHelper.isEmpty(country)) {
			obj.add(new BasicDBObject("country", country));
		}
		if(skills != null && skills.length > 0) {
			for(String skill : skills) {
				 obj.add(new BasicDBObject("skills." + skill, new BasicDBObject("$in", skillValues)));
			}
		}
		if(certifications != null && certifications.length > 0) {
			for(String certification : certifications) {
				 obj.add(new BasicDBObject("certifications." + certification, new BasicDBObject("$in", certificationValues)));
			}
		}
		if(languages != null && languages.length > 0) {
			for(String language : languages) {
				 obj.add(new BasicDBObject("languages." + language, new BasicDBObject("$in", languageValues)));
			}
		}
		if(geographies != null && geographies.length > 0) {
			for(String geography : geographies) {
				 obj.add(new BasicDBObject("geographies." + geography, new BasicDBObject("$in", geographyValues)));
			}
		}
		if(obj.size() > 0) {
			andQuery.put("$and", obj);
		}
		return getJCol().count(andQuery);
	}
	
	public List<String> getDistinctCountries() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("country", andQuery);
	}
	
}

