package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.ISGAdvisorSkill;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class ISGAdvisorSkillDAO extends BaseDAO<ISGAdvisorSkill>{

	public ISGAdvisorSkillDAO() {
		String collectionName = "isgadvisorskill";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), ISGAdvisorSkill.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("type", 1), new BasicDBObject("background", true));
	}
	
	public long countByFilters(Map<String, Object> fieldMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(fieldMap != null && fieldMap.size() > 0){
			for(Map.Entry<String, Object> mp : fieldMap.entrySet()){
				if(mp.getKey() != null && mp.getValue() != null ){
					obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
				}
			}
			andQuery.put("$and", obj);
		}
		
		return getJCol().count(andQuery);
	}
}
