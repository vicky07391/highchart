package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.bson.types.ObjectId;
import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.CustomerTimeseriesByDay;
import com.crucialbits.cy.model.Field;
import com.crucialbits.cy.model.ISGAdvisor;
import com.crucialbits.cy.model.ISGRequest;
import com.crucialbits.cy.model.Meeting;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class ISGRequestDAO extends BaseDAO<ISGRequest>{

	public ISGRequestDAO() {
		String collectionName = "isgrequest";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), ISGRequest.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("accountId", 1);
        compoundIndex3.put("customerId", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
        
        /*BasicDBObject compoundIndex4 = new BasicDBObject();
        compoundIndex4.put("accountId", 1);
        compoundIndex4.put("externalId", 1);
        getJCol().ensureIndex(compoundIndex4, new BasicDBObject("background", true));*/
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
	}
	
	public List<String> getDistinctCustomerNames() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("customerName", andQuery);
	}
	
	public List<String> getDistinctInquiryStatus() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("inquiryStatus", andQuery);
	}
	
	public List<String> getDistinctInquiryType() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("inquiryType", andQuery);
	}
	
	public List<String> getDistinctRequestor() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("requestor", andQuery);
	}
	
	
	public List<String> getDistinctIsgLead() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("isgLead", andQuery);
	}
	

	public List<String> getDistinctGeography() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("geography", andQuery);
	}
	
	public List<String> getDistinctVertical() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("vertical", andQuery);
	}
	
	public List<String> getDistinctCSR() {
		BasicDBObject andQuery = new BasicDBObject();
		return getJCol().distinct("csm", andQuery);
	}
	
	public long countByCustomFieldNameAndValue(String customerId, String  fieldName, Object value) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(value != null){
			obj.add(new BasicDBObject(fieldName, value));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public long countByCustomFieldNameAndValueWithRange(String customerId, String  fieldName, Object value, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(from != null && today != null) {
			obj.add(new BasicDBObject("dateOfRequest", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		if(value != null){
			obj.add(new BasicDBObject(fieldName, value));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public long countByCustomFieldNameAndValueForInquiryType(String customerId, String inquiryType, String  fieldName, Object value) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(customerId)){
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(inquiryType)){
			obj.add(new BasicDBObject("inquiryType", inquiryType));
		}
		if(value != null){
		obj.add(new BasicDBObject(fieldName, value));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public long countByFilters(Map<String, Object> fieldMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(fieldMap != null && fieldMap.size() > 0){
			for(Map.Entry<String, Object> mp : fieldMap.entrySet()){
				if(mp.getKey() != null && mp.getValue() != null ){
					obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
				}
			}
			andQuery.put("$and", obj);
		}		
		return getJCol().count(andQuery);
	}

	public List<ISGRequest> findByAdvisors(String advisorId, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(from != null && today != null) {
			obj.add(new BasicDBObject("dateOfRequest", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		if(!StringHelper.isEmpty(advisorId)) {
			obj.add(new BasicDBObject("advisors", new BasicDBObject("$elemMatch", new BasicDBObject("_id", new ObjectId(advisorId)))));
		}
		andQuery.put("$and", obj);
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery);
		List<ISGRequest> customers = new ArrayList<ISGRequest>();
		while(cursor.hasNext()) {
			customers.add(cursor.next());
		}
		return customers;
	}
	

	public List<ISGRequest> findRequestByPattern(String accountId, String pattern, int skip, int limit) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("requestor", new BasicDBObject("$regex", Pattern.compile(pattern, 2))));
		orList.add(new BasicDBObject("summary", new BasicDBObject("$regex", Pattern.compile(pattern, 2))));
		orList.add(new BasicDBObject("inquiryType", new BasicDBObject("$regex", Pattern.compile(pattern, 2))));
		orList.add(new BasicDBObject("inquiryStatus", new BasicDBObject("$regex", Pattern.compile(pattern, 2))));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		
		andList.add(orQuery);
		
		andQuery.put("$and", andList);
		
		List<ISGRequest> requests = new ArrayList<ISGRequest>();
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery);
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			requests.add(cursor.next());
		}
		return requests;
	}
	//fieldMap, customerIds, sortBy, ascending, skip, limit
	public List<ISGRequest> findRequest(Map<String, Object> fieldMap, List<String> customerIds,  String sortBy, boolean ascending, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		if(customerIds != null) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
				
		andQuery.put("$and", obj);

		DBCursor<ISGRequest> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, (ascending == true ? 1 : -1 )));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<ISGRequest> advisors = new ArrayList<ISGRequest>();
		while(cursor.hasNext()) {
			advisors.add(cursor.next());
		}
		return advisors;
	}
	
	public long countByCustomerIds(Map<String, Object> fieldMap, List<String> customerIds) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		if(customerIds != null) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<ISGRequest> findByAdvisorsAndOtherFilters(Map<String, Object> map, Object advisor) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(map != null) {
			for(Map.Entry<String, Object> entry : map.entrySet()) {
				if(entry.getValue() != null) {
					obj.add(new BasicDBObject(entry.getKey(), entry.getValue()));
				}
			}
		}
		if(advisor != null) {
			obj.add(new BasicDBObject("advisors", new BasicDBObject("$elemMatch", new BasicDBObject("user", advisor))));
		}
		andQuery.put("$and", obj);
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery);
		List<ISGRequest> requests = new ArrayList<ISGRequest>();
		while(cursor.hasNext()) {
			requests.add(cursor.next());
		}
		return requests;
	}
	
	public List<ISGRequest> findByAdvisorsAndOtherFiltersWithRange(Map<String, Object> map, Object advisor, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(map != null) {
			for(Map.Entry<String, Object> entry : map.entrySet()) {
				if(entry.getValue() != null) {
					obj.add(new BasicDBObject(entry.getKey(), entry.getValue()));
				}
			}
		}
		if(from != null && today != null) {
			obj.add(new BasicDBObject("dateOfRequest", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		if(advisor != null) {
			obj.add(new BasicDBObject("advisors", new BasicDBObject("$elemMatch", new BasicDBObject("user", advisor))));
		}
		andQuery.put("$and", obj);
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery);
		List<ISGRequest> requests = new ArrayList<ISGRequest>();
		while(cursor.hasNext()) {
			requests.add(cursor.next());
		}
		return requests;
	}
	
	public List<ISGRequest> findByAdvisorWithFilters(String advisorId, String filter, Object filterValue, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(filter) && filterValue != null) {
			obj.add(new BasicDBObject(filter, filterValue));
		}
		if(!StringHelper.isEmpty(advisorId)) {
			obj.add(new BasicDBObject("advisors", new BasicDBObject("$elemMatch", new BasicDBObject("_id", new ObjectId(advisorId)))));
		}
		andQuery.put("$and", obj);
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery);
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<ISGRequest> requests = new ArrayList<ISGRequest>();
		while(cursor.hasNext()) {
			requests.add(cursor.next());
		}
		return requests;
	}
	

	public List<ISGRequest> findByPrimaryAdvisorWithFilters(String advisorId, String filter, Object filterValue, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(filter) && filterValue != null) {
			obj.add(new BasicDBObject(filter, filterValue));
		}
		if(!StringHelper.isEmpty(advisorId)) {
			obj.add(new BasicDBObject("primaryAdvisor", new BasicDBObject("$elemMatch", new BasicDBObject("_id", new ObjectId(advisorId)))));
		}
		andQuery.put("$and", obj);
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery);
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<ISGRequest> requests = new ArrayList<ISGRequest>();
		while(cursor.hasNext()) {
			requests.add(cursor.next());
		}
		return requests;
	}
	
	public List<ISGRequest> findAllByMonth(String accountId, List<String> customerIds,
			Date from, Date to ) {
		List<ISGRequest> requests = new ArrayList<ISGRequest>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

//		obj.add(new BasicDBObject("accountId", accountId));
		if(customerIds != null && customerIds.size() > 0){
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));
		}
		obj.add(new BasicDBObject("dateOfRequest", new BasicDBObject("$gte", from).append("$lte", to)));
		andQuery.put("$and", obj);
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery);
		while (cursor.hasNext()) {
			requests.add(cursor.next());
		}
		return requests;
	}
	
/*	
	public List<String> getDistinctByCustomerId(String name, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(customerId)){
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct(name, andQuery);
	}*/
	
	public List<ISGRequest> getRequests(String customerId, String inquiryStatus, String inquiryType, String geography, String vertical, Object advisor, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		if(!StringHelper.isEmpty(inquiryStatus)) {
			obj.add(new BasicDBObject("inquiryStatus", inquiryStatus));
		}
		if(!StringHelper.isEmpty(inquiryType)) {
			obj.add(new BasicDBObject("inquiryType", inquiryType));
		}
		if(!StringHelper.isEmpty(geography)) {
			obj.add(new BasicDBObject("geography", geography));
		}
		if(!StringHelper.isEmpty(vertical)) {
			obj.add(new BasicDBObject("vertical", vertical));
		}
		if(advisor != null) {
			obj.add(new BasicDBObject("advisors", new BasicDBObject("$elemMatch", new BasicDBObject("user", advisor))));
		}
		if(from != null && today != null) {
			obj.add(new BasicDBObject("dateOfRequest", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		andQuery.put("$and", obj);
		List<ISGRequest> requests = new ArrayList<ISGRequest>();
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery).sort(new BasicDBObject("dateOfRequest", 1));
		while(cursor.hasNext()) {
			requests.add(cursor.next());
		}
		return requests;
	}
	
	public List<ISGRequest> getRequestsEnhanced(String customerId, String inquiryStatus, String inquiryType, 
			String geography, String vertical, Object advisor, Object requestor, Object isgLead, Object csm, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		if(!StringHelper.isEmpty(inquiryStatus)) {
			obj.add(new BasicDBObject("inquiryStatus", inquiryStatus));
		}
		if(!StringHelper.isEmpty(inquiryType)) {
			obj.add(new BasicDBObject("inquiryType", inquiryType));
		}
		if(!StringHelper.isEmpty(geography)) {
			obj.add(new BasicDBObject("geography", geography));
		}
		if(!StringHelper.isEmpty(vertical)) {
			obj.add(new BasicDBObject("vertical", vertical));
		}
		if(requestor != null) {
			obj.add(new BasicDBObject("requestor", requestor));
		}
		if(isgLead != null) {
			obj.add(new BasicDBObject("isgLead", isgLead));
		}
		if(csm != null) {
			obj.add(new BasicDBObject("csm", csm));
		}
		if(advisor != null) {
			obj.add(new BasicDBObject("advisors", new BasicDBObject("$elemMatch", new BasicDBObject("user", advisor))));
		}
		if(from != null && today != null) {
			obj.add(new BasicDBObject("dateOfRequest", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		andQuery.put("$and", obj);
		List<ISGRequest> requests = new ArrayList<ISGRequest>();
		DBCursor<ISGRequest> cursor = getJCol().find(andQuery).sort(new BasicDBObject("dateOfRequest", 1));
		while(cursor.hasNext()) {
			requests.add(cursor.next());
		}
		return requests;
	}
	
}
