package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.CustomerTimeseriesByDay;
import com.crucialbits.cy.model.ISGUserLogin;
import com.crucialbits.cy.model.TimeseriesByDay;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class ISGUserLoginDAO extends BaseDAO<ISGUserLogin>{

	public ISGUserLoginDAO() {
		String collectionName = "isguserlogin";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), ISGUserLogin.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		
	}
	
	public List<ISGUserLogin> getData(String customerId,  Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		if(from != null && today != null) {
			obj.add(new BasicDBObject("date", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		andQuery.put("$and", obj);
		List<ISGUserLogin> dates = new ArrayList<ISGUserLogin>();
		DBCursor<ISGUserLogin> cursor = getJCol().find(andQuery).sort(new BasicDBObject("date", 1));
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}
	
	public List<ISGUserLogin> getDetailsData(String customerId, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(customerId)){
		obj.add(new BasicDBObject("customerId", customerId));
		}
		if(from != null && today != null) {
			obj.add(new BasicDBObject("date", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		andQuery.put("$and", obj);
		List<ISGUserLogin> dates = new ArrayList<ISGUserLogin>();
		DBCursor<ISGUserLogin> cursor = getJCol().find(andQuery).sort(new BasicDBObject("date", 1));
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}
}
