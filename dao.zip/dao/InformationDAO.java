
package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Account;
import com.crucialbits.cy.model.Information;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class InformationDAO extends BaseDAO<Information> {

	public InformationDAO() {
		String collectionName = "information";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Information.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
        
		BasicDBObject compoundIndex1 = new BasicDBObject();
        compoundIndex1.put("accountId", 1);
        compoundIndex1.put("type", 1);
        compoundIndex1.put("entity", 1);
        getJCol().ensureIndex(compoundIndex1, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex2 = new BasicDBObject();
        compoundIndex2.put("accountId", 1);
        compoundIndex2.put("type", 1);
        compoundIndex2.put("entity", 1);
        compoundIndex2.put("date", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex9 = new BasicDBObject();
        compoundIndex9.put("accountId", 1);
        compoundIndex9.put("ignored", 1);
        compoundIndex9.put("customerTypes", 1);
        compoundIndex9.put("rangeFilter", 1);
        compoundIndex9.put("entity", 1);
        compoundIndex9.put("type", 1);
        getJCol().ensureIndex(compoundIndex9, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex12 = new BasicDBObject();
        compoundIndex12.put("accountId", 1);
        compoundIndex12.put("ignored", 1);
        compoundIndex12.put("customerTypes", 1);
        compoundIndex12.put("psManager", 1);
        compoundIndex12.put("rangeFilter", 1);
        compoundIndex12.put("entity", 1);
        compoundIndex12.put("type", 1);
        getJCol().ensureIndex(compoundIndex12, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex13 = new BasicDBObject();
        compoundIndex13.put("accountId", 1);
        compoundIndex13.put("ignored", 1);
        compoundIndex13.put("customerTypes", 1);
        compoundIndex13.put("salesperson", 1);
        compoundIndex13.put("rangeFilter", 1);
        compoundIndex13.put("entity", 1);
        compoundIndex13.put("type", 1);
        getJCol().ensureIndex(compoundIndex13, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex14 = new BasicDBObject();
        compoundIndex14.put("accountId", 1);
        compoundIndex14.put("ignored", 1);
        compoundIndex14.put("customerTypes", 1);
        compoundIndex14.put("cem", 1);
        compoundIndex14.put("rangeFilter", 1);
        compoundIndex14.put("entity", 1);
        compoundIndex14.put("type", 1);
        getJCol().ensureIndex(compoundIndex14, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex15 = new BasicDBObject();
        compoundIndex15.put("accountId", 1);
        compoundIndex15.put("ignored", 1);
        compoundIndex15.put("customerTypes", 1);
        compoundIndex15.put("csm", 1);
        compoundIndex15.put("rangeFilter", 1);
        compoundIndex15.put("entity", 1);
        compoundIndex15.put("type", 1);
        getJCol().ensureIndex(compoundIndex15, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex16 = new BasicDBObject();
        compoundIndex16.put("accountId", 1);
        compoundIndex16.put("ignored", 1);
        compoundIndex16.put("customerTypes", 1);
        compoundIndex16.put("accountManager", 1);
        compoundIndex16.put("rangeFilter", 1);
        compoundIndex16.put("entity", 1);
        compoundIndex16.put("type", 1);
        getJCol().ensureIndex(compoundIndex16, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex17 = new BasicDBObject();
        compoundIndex17.put("accountId", 1);
        compoundIndex17.put("entity", 1);
        compoundIndex17.put("type", 1);
        compoundIndex17.put("entityId", 1);
        compoundIndex17.put("dateRange", 1);
        getJCol().ensureIndex(compoundIndex17, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex18 = new BasicDBObject();
        compoundIndex18.put("accountId", 1);
        compoundIndex18.put("entity", 1);
        compoundIndex18.put("type", 1);
        compoundIndex18.put("dateRange", 1);
        getJCol().ensureIndex(compoundIndex18, new BasicDBObject("background", true));
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("type", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("entity", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("entityId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("date", 1), new BasicDBObject("background", true));
	}
	
	public Information findCachedData(String accountId, Date date, String type, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("date", date));
		obj.add(new BasicDBObject("type", type));
		obj.add(new BasicDBObject("entity", entity));
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
	
	public Information findCachedDataEnhanced(String accountId, String rangeFilter, Date from, Date to, String type, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(from != null && to != null) {
			obj.add(new BasicDBObject("date", new BasicDBObject("$gte", from).append("$lte", to)));
		}
		if(!StringHelper.isEmpty(rangeFilter)) {
			obj.add(new BasicDBObject("rangeFilter", Long.parseLong(rangeFilter)));
		}
		obj.add(new BasicDBObject("type", type));
		obj.add(new BasicDBObject("entity", entity));
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
	
	public void deleteCachedData(String accountId, String rangeFilter, Date date, String type, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
//		obj.add(new BasicDBObject("date", date));
		obj.add(new BasicDBObject("type", type));
		obj.add(new BasicDBObject("entity", entity));
		if(!StringHelper.isEmpty(rangeFilter)) {
			obj.add(new BasicDBObject("rangeFilter", Long.parseLong(rangeFilter)));
		}
		andQuery.put("$and", obj);
		getJCol().remove(andQuery);
	}
	
	public void deleteCachedDataWithRange(String accountId, String rangeFilter, Date date, String type, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("type", type));
		obj.add(new BasicDBObject("entity", entity));
		obj.add(new BasicDBObject("rangeFilter", Long.parseLong(rangeFilter)));
		andQuery.put("$and", obj);
		getJCol().remove(andQuery);
	}
	
	public long countByFilters(String accountId, String type, String entity, Map<String, Object> paramMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("type", type));
		obj.add(new BasicDBObject("entity", entity));	
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}