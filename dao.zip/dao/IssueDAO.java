


package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.bson.types.ObjectId;
import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.client.google.Message;
import com.crucialbits.cy.app.Constants.IssuePriority;
import com.crucialbits.cy.app.Constants.IssueStatus;
import com.crucialbits.cy.app.Constants.IssuesSortBy;
import com.crucialbits.cy.app.Constants.SupportChannel;
import com.crucialbits.cy.model.CustomerNote;
import com.crucialbits.cy.model.Issue;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class IssueDAO extends BaseDAO<Issue> {

	public IssueDAO() {
		String collectionName = "issue";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Issue.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("key", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);

        getJCol().ensureIndex(compoundIndex, options);

        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("projectId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("componentId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("typeId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("title", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("key", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("priority", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("channel", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("status", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("submitter", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("assignee", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("spam", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("unassigned", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("supportIssue", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("addedToJira", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("jiraKey", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("jiraStatus", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("newReplyId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("newCommentId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("contactId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("linkedIssues", 1), new BasicDBObject("background", true));
	}

	public long countIssueByProject(String accountId, String projectId, String spam) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		obj.add(new BasicDBObject("deletedAt", null));
		if(!StringHelper.isEmpty(spam)) {
			obj.add(new BasicDBObject("spam", Boolean.parseBoolean(spam)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countMyIssues(String accountId, String projectId, String userId, String status, String spam) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		obj.add(new BasicDBObject("assignee", userId));
		obj.add(new BasicDBObject("deletedAt", null));
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", IssueStatus.valueOf(status.toUpperCase())));
		}
		if(!StringHelper.isEmpty(spam)) {
			obj.add(new BasicDBObject("spam", Boolean.parseBoolean(spam)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countIssueByProjectAndStatus(String accountId, String projectId, IssueStatus status, String spam) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		obj.add(new BasicDBObject("deletedAt", null));
		if(status != null) {
			obj.add(new BasicDBObject("status", status));
		}
		if(!StringHelper.isEmpty(spam)) {
			obj.add(new BasicDBObject("spam", Boolean.parseBoolean(spam)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public Issue findIssueByKey(String accountId, String issueKey) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("key", issueKey));
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}

	public List<Issue> findIssuesByKeys(String accountId, List<String> issueKeys) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("key", new BasicDBObject("$in", issueKeys)));
		andQuery.put("$and", obj);
		List<Issue> issues = new ArrayList<Issue>();
		DBCursor<Issue> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public List<Issue> findIssuesExistenceInLinkedObject(String accountId, Set<String> issueKeys) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("linkedIssues", new BasicDBObject("$in", issueKeys)));
		andQuery.put("$and", obj);
		List<Issue> issues = new ArrayList<Issue>();
		DBCursor<Issue> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public Issue findIssueByNumberAndProject(String accountId, String projectId, int number, String filter) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		obj.add(new BasicDBObject("number", number));
		if(!StringHelper.isEmpty(filter) && !filter.equalsIgnoreCase("spam")) {
			obj.add(new BasicDBObject("spam", false));
		}
		
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("fixed")) {
			obj.add(new BasicDBObject("status", IssueStatus.FIXED));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("spam")) {
			obj.add(new BasicDBObject("spam", true));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("unassigned")) {
			obj.add(new BasicDBObject("unassigned", true));
		}
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}

	public List<Issue> findUnindexedIssues(int maxSize) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("indexedInSearch", null));
		obj.add(new BasicDBObject("indexedInSearch", false));
		orQuery.put("$or", obj);

		List<Issue> issues = new ArrayList<Issue>();
		DBCursor<Issue> cursor = getJCol().find(orQuery);
		while(cursor.hasNext()) {
			issues.add(cursor.next());
			if (issues.size() == maxSize) {
				break;
			}
		}
		return issues;
	}

	public void markIndexed(String id) {
		Issue issue = getJCol().findOneById(id);
		issue.setIndexedInSearch(true);
		updateById(id, issue);
	}

	public long countfilteredIssues(String accountId, String loggedInUserId, String projectId,
			String filterKey, String filter, String channel, boolean supportIssue) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));

		if(StringHelper.isEmpty(channel)) {
			obj.add(new BasicDBObject("projectId", projectId));
		} else {
			obj.add(new BasicDBObject("channel", SupportChannel.valueOf(channel.toUpperCase())));
		}
		if(!StringHelper.isEmpty(filterKey) && filterKey.equalsIgnoreCase("submittedbyme")) {
			obj.add(new BasicDBObject("submitter", loggedInUserId));
		}
		if(!StringHelper.isEmpty(filterKey) && filterKey.equalsIgnoreCase("assignedtome")) {
			obj.add(new BasicDBObject("assignee", loggedInUserId));
		}
		obj.add(new BasicDBObject("supportIssue", supportIssue));
//		if(!StringHelper.isEmpty(filter)) {
//			obj.add(new BasicDBObject("status", IssueStatus.valueOf(filter)));
//		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("fixed")) {
			obj.add(new BasicDBObject("status", IssueStatus.FIXED));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("spam")) {
			obj.add(new BasicDBObject("spam", true));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("unassigned")) {
			obj.add(new BasicDBObject("unassigned", true));
		} else {
			obj.add(new BasicDBObject("spam", false));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<Issue> findFilteredIssues(String accountId, String loggedInUserId, String projectId,
			String filterKey, String filter, String channel, boolean supportIssue, int skip, int limit) {

		List<Issue> issues = new ArrayList<Issue>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(projectId) || !StringHelper.isEmpty(channel)){
			if(StringHelper.isEmpty(channel)) {
				obj.add(new BasicDBObject("projectId", projectId));
			} else {
				obj.add(new BasicDBObject("channel", SupportChannel.valueOf(channel.toUpperCase())));
			}

		}

		obj.add(new BasicDBObject("supportIssue", supportIssue));


		if(!StringHelper.isEmpty(filterKey) && filterKey.equalsIgnoreCase("submittedbyme")) {
			obj.add(new BasicDBObject("submitter", loggedInUserId));
			obj.add(new BasicDBObject("spam", false));
		}
		if(!StringHelper.isEmpty(filterKey) && filterKey.equalsIgnoreCase("assignedtome")) {
			obj.add(new BasicDBObject("assignee", loggedInUserId));
			obj.add(new BasicDBObject("spam", false));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("fixed")) {
			obj.add(new BasicDBObject("status", IssueStatus.FIXED));
			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("spam")) {
			obj.add(new BasicDBObject("spam", true));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("unassigned")) {
			obj.add(new BasicDBObject("unassigned", true));
			obj.add(new BasicDBObject("spam", false));
		} else {
			obj.add(new BasicDBObject("spam", false));
		}
		andQuery.put("$and", obj);
		DBCursor<Issue> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", -1));
		cursor.skip(skip);
		cursor.limit(limit);
		while (cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public List<Issue> findSupportFilteredIssues(String accountId, String projectId,
			String filter, String channel, IssuesSortBy issuesSortBy, String priority,
			String loggedInUserId, String filterKey, String customerId, String typeId, int skip, int limit) {

		List<Issue> issues = new ArrayList<Issue>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("deletedAt", null));


		if(!StringHelper.isEmpty(projectId)) {
			obj.add(new BasicDBObject("projectId", projectId));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(typeId)) {
			obj.add(new BasicDBObject("typeId", typeId));
		}
		if(!StringHelper.isEmpty(channel)) {
			obj.add(new BasicDBObject("channel", SupportChannel.valueOf(channel.toUpperCase())));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", IssuePriority.valueOf(priority.toUpperCase())));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("fixed")) {
			obj.add(new BasicDBObject("status", IssueStatus.FIXED));
//			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
//			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("all")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			inList.add("FIXED");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
//			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("unassigned")) {
			obj.add(new BasicDBObject("unassigned", true));
			obj.add(new BasicDBObject("status", new BasicDBObject("$ne", IssueStatus.FIXED)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("new")) {
			Calendar cal = Calendar.getInstance();
			Date to = cal.getTime();
			cal.add(Calendar.HOUR, -24);
			Date from = cal.getTime();
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
//			obj.add(new BasicDBObject("spam", false));
		} else {
//			obj.add(new BasicDBObject("spam", false));
		}
		if(!StringHelper.isEmpty(filterKey) && filterKey.equalsIgnoreCase("myissues")) {
			obj.add(new BasicDBObject("assignee", loggedInUserId));
			obj.add(new BasicDBObject("unassigned", false));
		}

		if(StringHelper.isEmpty(filter) || (!StringHelper.isEmpty(filter) && !filter.equalsIgnoreCase("spam"))) {
			obj.add(new BasicDBObject("spam", false));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("spam")) {
			obj.add(new BasicDBObject("spam", true));
		}

		String sortBy = "updatedAt";
		if(issuesSortBy.equals(IssuesSortBy.PRIORITY)) {
			sortBy = "priority";
//			obj.add(new BasicDBObject("priority", new BasicDBObject("$exists", true)));
		} else if(issuesSortBy.equals(IssuesSortBy.CUSTOMER)) {
			sortBy = "customerName";
//			obj.add(new BasicDBObject("customerName", new BasicDBObject("$exists", true)));
		} else if(issuesSortBy.equals(IssuesSortBy.TYPE)) {
			sortBy = "typeName";
//			obj.add(new BasicDBObject("typeName", new BasicDBObject("$exists", true)));
		} else if(issuesSortBy.equals(IssuesSortBy.COMPONENT)) {
			sortBy = "componentName";
//			obj.add(new BasicDBObject("componentName", new BasicDBObject("$exists", true)));
		} else if(issuesSortBy.equals(IssuesSortBy.STATUS)) {
			sortBy = "status";
//			obj.add(new BasicDBObject("status", new BasicDBObject("$exists", true)));
		} else if(issuesSortBy.equals(IssuesSortBy.LASTSEEN)) {
			sortBy = "lastSeenByName";
//			obj.add(new BasicDBObject("lastSeenByName", new BasicDBObject("$exists", true)));
		}

		andQuery.put("$and", obj);

		DBCursor<Issue> cursor = null;
		if(sortBy.equalsIgnoreCase("updatedat")) {
			cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, -1));
		} else {
			cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, 1));
		}
		cursor.skip(skip);
		cursor.limit(limit);
		while (cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public long countSupportFilteredIssues(String accountId, String projectId,
			String filter, String channel, String priority, String loggedInUserId, String filterKey,
			IssuesSortBy issuesSortBy, String customerId, String typeId, Map<String, Object> paramMap) {

		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("deletedAt", null));



		if(!StringHelper.isEmpty(projectId)) {
			obj.add(new BasicDBObject("projectId", projectId));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(typeId)) {
			obj.add(new BasicDBObject("typeId", typeId));
		}
		if(!StringHelper.isEmpty(channel)) {
			obj.add(new BasicDBObject("channel", SupportChannel.valueOf(channel.toUpperCase())));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", IssuePriority.valueOf(priority.toUpperCase())));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("fixed")) {
			obj.add(new BasicDBObject("status", IssueStatus.FIXED));
//			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
//			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("all")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			inList.add("FIXED");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
//			obj.add(new BasicDBObject("spam", false));
		}else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("unassigned")) {
			obj.add(new BasicDBObject("unassigned", true));
			obj.add(new BasicDBObject("status", new BasicDBObject("$ne", IssueStatus.FIXED)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("new")) {
			Calendar cal = Calendar.getInstance();
			Date to = cal.getTime();
			cal.add(Calendar.HOUR, -24);
			Date from = cal.getTime();
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
//			obj.add(new BasicDBObject("spam", false));
		} else {
//			obj.add(new BasicDBObject("spam", false));
		}
		if(!StringHelper.isEmpty(filterKey) && filterKey.equalsIgnoreCase("myissues")) {
			obj.add(new BasicDBObject("assignee", loggedInUserId));
			obj.add(new BasicDBObject("unassigned", false));
		}
		
/*		if(!StringHelper.isEmpty(customerType)) {
			obj.add(new BasicDBObject("customerTypeId", customerType));
		}
*/
		if(StringHelper.isEmpty(filter) || (!StringHelper.isEmpty(filter) && !filter.equalsIgnoreCase("spam"))) {
			obj.add(new BasicDBObject("spam", false));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("spam")) {
			obj.add(new BasicDBObject("spam", true));
		}
        if(paramMap != null){
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString()) && mp.getKey().equals("customerTypeId")) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}
        }
//		if(issuesSortBy.equals(IssuesSortBy.PRIORITY)) {
//			obj.add(new BasicDBObject("priority", new BasicDBObject("$exists", true)));
//		} else if(issuesSortBy.equals(IssuesSortBy.CUSTOMER)) {
//			obj.add(new BasicDBObject("customerName", new BasicDBObject("$exists", true)));
//		} else if(issuesSortBy.equals(IssuesSortBy.TYPE)) {
//			obj.add(new BasicDBObject("typeName", new BasicDBObject("$exists", true)));
//		} else if(issuesSortBy.equals(IssuesSortBy.COMPONENT)) {
//			obj.add(new BasicDBObject("componentName", new BasicDBObject("$exists", true)));
//		}

		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countMyIssues(String accountId, String userId, String status) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("assignee", userId));
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", IssueStatus.valueOf(status.toUpperCase())));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<Issue> findAgentIssues(String accountId, String userId, int skip, int limit) {
		List<Issue> issues = new ArrayList<Issue>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		String[] status = {IssueStatus.OPEN.toString(), IssueStatus.IN_PROGRESS.toString()};
		obj.add(new BasicDBObject("assignee", userId));
		obj.add(new BasicDBObject("status", new BasicDBObject("$in", status)));
		andQuery.put("$and", obj);
		DBCursor<Issue> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", -1));
		cursor.skip(skip);
		cursor.limit(limit);
		while (cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public long countAgentIssues(String accountId, String userId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		String[] status = {IssueStatus.OPEN.toString(), IssueStatus.IN_PROGRESS.toString()};
		obj.add(new BasicDBObject("assignee", userId));
		obj.add(new BasicDBObject("status", new BasicDBObject("$in", status)));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<Issue> getDateSpecificIssuesByUser(String accountId, IssueStatus status, String userId, Date from, Date to) {
		List<Issue> issues = new ArrayList<Issue>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("status", status));
		obj.add(new BasicDBObject("assignee", userId));
		if(to == null) {
			obj.add(new BasicDBObject("updatedAt", new BasicDBObject("$gte", from)));
		} else {
			obj.add(new BasicDBObject("updatedAt", new BasicDBObject("$gte", from).append("$lt", to)));
		}
		andQuery.put("$and", obj);
		DBCursor<Issue> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public long countUnassignedIssuesByProject(String accountId, String projectId, String spam) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		obj.add(new BasicDBObject("deletedAt", null));
		obj.add(new BasicDBObject("unassigned", true));
		obj.add(new BasicDBObject("status", new BasicDBObject("$ne", IssueStatus.FIXED)));
		if(!StringHelper.isEmpty(spam)) {
			obj.add(new BasicDBObject("spam", Boolean.parseBoolean(spam)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countNewIssuesByProject(String accountId, String projectId, String spam) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		obj.add(new BasicDBObject("deletedAt", null));
		if(!StringHelper.isEmpty(spam)) {
			obj.add(new BasicDBObject("spam", Boolean.parseBoolean(spam)));
		}
		Calendar cal = Calendar.getInstance();
		Date to = cal.getTime();
		cal.add(Calendar.HOUR, -24);
		Date from = cal.getTime();
		obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countSpamIssuesByProject(String accountId, String projectId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		obj.add(new BasicDBObject("deletedAt", null));
		obj.add(new BasicDBObject("spam", true));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countAllIssues(String accountId, String filter, String filterKey, String loggedInUserId, String spam) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("deletedAt", null));
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("fixed")) {
			obj.add(new BasicDBObject("status", IssueStatus.FIXED));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("spam")) {
			obj.add(new BasicDBObject("spam", true));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("unassigned")) {
			obj.add(new BasicDBObject("unassigned", true));
			obj.add(new BasicDBObject("status", new BasicDBObject("$ne", IssueStatus.FIXED)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("new")) {
			Calendar cal = Calendar.getInstance();
			Date to = cal.getTime();
			cal.add(Calendar.HOUR, -24);
			Date from = cal.getTime();
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));

		}
		if(!StringHelper.isEmpty(filterKey) && filterKey.equalsIgnoreCase("myissues")) {
			obj.add(new BasicDBObject("assignee", loggedInUserId));
			obj.add(new BasicDBObject("unassigned", false));
		}
		if(!StringHelper.isEmpty(spam)) {
			obj.add(new BasicDBObject("spam", Boolean.parseBoolean(spam)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<Issue> findCustomerIssues(String accountId, List<String> userIds,
			int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("deletedAt", null));
		obj.add(new BasicDBObject("submitter", new BasicDBObject("$in", userIds)));
		andQuery.put("$and", obj);
		List<Issue> issues = new ArrayList<Issue>();
		DBCursor<Issue> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public long countCustomerIssues(String accountId, List<String> userIds, IssueStatus issueStatus, IssuePriority issuePriority,
			String typeId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("submitter", new BasicDBObject("$in", userIds)));
		if(issueStatus != null) {
			obj.add(new BasicDBObject("status", issueStatus));
		}
		if(issuePriority != null) {
			obj.add(new BasicDBObject("priority", issuePriority));
		}
		if(!StringHelper.isEmpty(typeId)) {
			obj.add(new BasicDBObject("typeId", typeId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countCustomerIssuesByDateRange(String accountId, List<String> userIds, IssueStatus issueStatus,
			IssuePriority issuePriority, String typeId, Date from, Date to) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("submitter", new BasicDBObject("$in", userIds)));
		if(issueStatus != null) {
			obj.add(new BasicDBObject("status", issueStatus));
		}
		if(issuePriority != null) {
			obj.add(new BasicDBObject("priority", issuePriority));
		}
		if(!StringHelper.isEmpty(typeId)) {
			obj.add(new BasicDBObject("typeId", typeId));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countCustomerHistory(String accountId, List<String> userIds, String submitterId, String status) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("deletedAt", null));
		if(userIds != null && userIds.size() > 0) {
			obj.add(new BasicDBObject("submitter", new BasicDBObject("$in", userIds)));
		}
		if(!StringHelper.isEmpty(submitterId)) {
			obj.add(new BasicDBObject("submitter", submitterId));
		}
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", status.toUpperCase()));
		}
		/*if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("OPEN")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		}*/
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countAllSupportIssuesStatistics(String accountId, IssueStatus issueStatus,
			IssuePriority issuePriority, String spam) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("deletedAt", null));
		if(issueStatus != null && issueStatus.equals(IssueStatus.OPEN)) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		} else if(issueStatus != null) {
			obj.add(new BasicDBObject("status", issueStatus));
		}
		if(issuePriority != null) {
			obj.add(new BasicDBObject("priority", issuePriority));
		}
		if(!StringHelper.isEmpty(spam)) {
			obj.add(new BasicDBObject("spam", Boolean.parseBoolean(spam)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<Issue> findAllSupportIssuesForReplyStatistics(String accountId, IssueStatus issueStatus,
			Date from, Date to, String timeType) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("deletedAt", null));
		obj.add(new BasicDBObject("spam", false));
		if(issueStatus != null && issueStatus.equals(IssueStatus.OPEN)) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		} else if(issueStatus != null) {
			obj.add(new BasicDBObject("status", issueStatus));
		}
		if(!StringHelper.isEmpty(timeType) && timeType.equalsIgnoreCase("timesensitive")) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
		} else if(!StringHelper.isEmpty(timeType) && timeType.equalsIgnoreCase("pastdue")) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$lte", from)));
		}
		andQuery.put("$and", obj);
		List<Issue> issues = new ArrayList<Issue>();
		DBCursor<Issue> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public long countSupportNotificationIssues(String accountId, String loggedInUserId,
			Date lastDate, Date today) {

		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));

		if(lastDate != null && today != null) {
			obj.add(new BasicDBObject("updatedAt", new BasicDBObject("$gte", lastDate).append("$lte", today)));
			obj.add(new BasicDBObject("spam", false));
		}

		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<String> groupedDataByLinkedIssues(String accountId, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("linkedIssues", new BasicDBObject("$exists", true)));
		query.put("$and", obj);

		BasicDBObject match = new BasicDBObject("$match", query);

		BasicDBObject groupFields = new BasicDBObject("_id", "$linkedIssues");
		groupFields.put("total", new BasicDBObject("$sum", 1));

		BasicDBObject group = new BasicDBObject("$group", groupFields);

//		BasicDBObject sortFields = new BasicDBObject("total", -1);
//		BasicDBObject sort = new BasicDBObject("$sort", sortFields);

		AggregationOutput output = null;

		if(limit > 0) {
			BasicDBObject skipNum = new BasicDBObject("$skip", skip);
			BasicDBObject limitNum = new BasicDBObject("$limit", limit);
//			output = getCol().aggregate(match, group, sort, skipNum, limitNum);
			output = getCol().aggregate(match, group, skipNum, limitNum);
		} else {
			output = getCol().aggregate(match, group);
		}
//		System.out.println(output);
		List<String> issueKeys = new ArrayList<String>();
		for(DBObject object : output.results()) {
			issueKeys.add(object.get("_id").toString());
		}
		return issueKeys;
	}

	public List<Issue> findIssuesByIds(String accountId, List<ObjectId> issueIds) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("_id", new BasicDBObject("$in", issueIds)));
		andQuery.put("$and", obj);
		List<Issue> issues = new ArrayList<Issue>();
		DBCursor<Issue> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public List<Issue> findSupportIssuesForRecipe(String accountId, String filter, String priority, Date from) {

		List<Issue> issues = new ArrayList<Issue>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));

		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", IssuePriority.valueOf(priority.toUpperCase())));
		}
		if(from != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", new Date())));
			obj.add(new BasicDBObject("spam", false));
		}
		/*if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("fixed")) {
			obj.add(new BasicDBObject("status", IssueStatus.FIXED));
			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("all")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			inList.add("FIXED");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("spam")) {
			obj.add(new BasicDBObject("spam", true));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("unassigned")) {
			obj.add(new BasicDBObject("unassigned", true));
			obj.add(new BasicDBObject("spam", false));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("new")) {
			Calendar cal = Calendar.getInstance();
			Date to = cal.getTime();
			cal.add(Calendar.MINUTE, -5);
			Date from = cal.getTime();
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
			obj.add(new BasicDBObject("spam", false));
		} else {
			obj.add(new BasicDBObject("spam", false));
		}*/

		andQuery.put("$and", obj);

		DBCursor<Issue> cursor = getJCol().find(andQuery);
		while (cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public List<String> findDistinctIssueKeys(String accountId, String priority) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		List<String> inList = new ArrayList<String>();
		inList.add("OPEN");
		inList.add("IN_PROGRESS");
		obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", IssuePriority.valueOf(priority.toUpperCase())));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("key", andQuery);
	}

	public long countSupportFilteredIssuesByDateRange(String accountId, String customerId, Date from, Date to) {

		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));

		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
		}

		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}


	public List<Issue> findDeletedSupportIssues(String accountId, String sortBy, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deletedAt", new BasicDBObject("$ne", null)));
		andQuery.put("$and", obj);
		List<Issue> issues = new ArrayList<Issue>();
		DBCursor<Issue> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public long countDeletedSupportIssues(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deletedAt", new BasicDBObject("$ne", null)));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}


	public List<Issue> getSimilarIssues(String accountId, String title, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(title)) {
			obj.add(new BasicDBObject("title", Pattern.compile(title, 2)));
		}
		obj.add(new BasicDBObject("deletedAt", null));
		andQuery.put("$and", obj);
		List<Issue> issues = new ArrayList<Issue>();
		DBCursor<Issue> cursor = getJCol().find(andQuery);
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public void deleteLastThirtyDaysCustomerIssues(String accountId, Calendar calendar) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deletedAt", new BasicDBObject("$lte", calendar.getTime())));
		andQuery.put("$and", obj);
		getJCol().remove(andQuery);
	}



	public long countAllTicketsByWithoutCustomer(String accountId, String status, boolean supportIssue, String customerId, boolean spam) {

		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", supportIssue));

		if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		}


//		obj.add(new BasicDBObject("status", IssueStatus.valueOf(status.toUpperCase().trim())));
		obj.add(new BasicDBObject("spam", spam));

		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<Issue> findAllOpenIssuessWithCustomerImpact(String accountId, String customerId, String status, boolean supportIssue, String priority, List<String> customerIdsByManager, String recent, int skip, int limit) {

		List<Issue> issues = new ArrayList<Issue>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", supportIssue));

		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		}
		obj.add(new BasicDBObject("spam", false));
		if(customerIdsByManager != null && customerIdsByManager.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIdsByManager)));
		}


		andQuery.put("$and", obj);
		DBCursor<Issue> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", -1));
		/*if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}*/
		while (cursor.hasNext()) {
			issues.add(cursor.next());
		}
		return issues;
	}

	public List<String> getDistinctPriority(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().distinct("priority", query);
	}

	public long countAllTicketsByDateRange(String accountId, String status, boolean supportIssue, String customerId, boolean spam,
			Date back, Date today) {

		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", supportIssue));

		if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("open")) {
			List<String> inList = new ArrayList<String>();
			inList.add("OPEN");
			inList.add("IN_PROGRESS");
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		}

		if(back != null && today != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", back).append("$lte", today)));
		}

		obj.add(new BasicDBObject("spam", spam));

		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countCustomerIssuesByDateRange(String accountId, String customerId, IssueStatus issueStatus,
			IssuePriority issuePriority, String typeId, Date from, Date to) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("supportIssue", true));
		obj.add(new BasicDBObject("customerId", customerId));
		if(issueStatus != null) {
			obj.add(new BasicDBObject("status", issueStatus));
		}
		if(issuePriority != null) {
			obj.add(new BasicDBObject("priority", issuePriority));
		}
		if(!StringHelper.isEmpty(typeId)) {
			obj.add(new BasicDBObject("typeId", typeId));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}