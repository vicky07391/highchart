package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.Field;
import com.crucialbits.cy.model.License;
import com.crucialbits.cy.model.Meeting;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class LicenseDAO extends BaseDAO<License> {

	public LicenseDAO() {
		String collectionName = "license";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), License.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("customerId", 1);
		compoundIndex.put("accountId", 1);
		compoundIndex.put("contractId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(compoundIndex, options);

        BasicDBObject compoundIndex2 = new BasicDBObject();
		compoundIndex2.put("customerId", 1);
		compoundIndex2.put("accountId", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));

        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("contractId", 1), new BasicDBObject("background", true));
	}

	public long countByCustomer(String accountId, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public List<String> getDistinctInstallationTypes(String accountId) {
		BasicDBObject query = new BasicDBObject();
		query.put("accountId", accountId);
		return getJCol().distinct("installationType", query);
	}

	public List<String> getDistinctLicenseTypes(String accountId) {
		BasicDBObject query = new BasicDBObject();
		query.put("accountId", accountId);
		return getJCol().distinct("licenseType", query);
	}

	public List<String> getDistinctBillingFrequencies(String accountId) {
		BasicDBObject query = new BasicDBObject();
		query.put("accountId", accountId);
		return getJCol().distinct("billingFrequency", query);
	}

	public List<Integer> getDistinctCurrentTerms(String accountId, String customerTypeId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypeId", customerTypeId));
		}
		andQuery.put("$and", obj);
		return getJCol().distinct("contractPeriod", andQuery);
	}


	public List<String> getDistinctContractDescriptions(String accountId) {
		  BasicDBObject query = new BasicDBObject();
		  query.put("accountId", accountId);
		  return getJCol().distinct("licenseType", query);
	}

	public List<License> findAllByMonth(String accountId, List<String> customerIds,
			Date from, Date to ) {
		List<License> licenses = new ArrayList<License>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));
		obj.add(new BasicDBObject("renewalDate", new BasicDBObject("$gte", from).append("$lte", to)));
		andQuery.put("$and", obj);
		DBCursor<License> cursor = getJCol().find(andQuery);
		while (cursor.hasNext()) {
			licenses.add(cursor.next());
		}
		return licenses;

	}
	public long countAll(String accountId, List<String> customerIds,
			Date from, Date to ) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));

		obj.add(new BasicDBObject("dueDate", new BasicDBObject("$gte", from)));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	
	public Set<Object> getDistinctLicenseCustomFieldValuesEnhanced(String accountId, String customField ) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
//		obj.add(new BasicDBObject("customerId", customerId));
			
		query.put("$and", obj);
		Set<Object> values = new HashSet<Object>();
		DBCursor<License> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			License license = cursor.next();
			if(license.getCustomFields() != null) {
				for(Field field : license.getCustomFields()) {
					if(field.getName().equalsIgnoreCase(customField) && field.getValue() != null) {
						values.add(field.getValue());
					}
				}
			}
		}
		return values;
	}
	
	public long countByLicenseCustomFieldNameAndValue(String accountId, String customerId, String customField, Object value) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		
		obj.add(new BasicDBObject("customFields", new BasicDBObject("$elemMatch", new BasicDBObject("name", customField).append("value", value))));
		query.put("$and", obj);
		
		return getJCol().count(query);
	}
}
