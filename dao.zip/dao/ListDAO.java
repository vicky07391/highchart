package com.crucialbits.cy.dao;


import java.util.ArrayList;

import org.bson.types.ObjectId;
import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.List;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class ListDAO extends BaseDAO<List> {

	public ListDAO() {
		String collectionName = "list";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), List.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("name", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
		getJCol().ensureIndex(new BasicDBObject("name", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
	}
	
	public long countList(String accountId) {
		BasicDBObject query = new BasicDBObject("accountId", accountId);
		return getJCol().count(query);
	}
	
	public java.util.List<List> findAllInIds(String accountId, java.util.List<String> ids, int skip, int limit) {
		
		java.util.List<ObjectId> oIds = new ArrayList<ObjectId>();
		for(String id : ids) {
			oIds.add(new ObjectId(id));
		}
		
		java.util.List<List> lists = new ArrayList<List>();
		BasicDBObject andQuery = new BasicDBObject();
		java.util.List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("_id", new BasicDBObject("$in", oIds)));
		
		andQuery.put("$and", obj);
		DBCursor<List> cursor = getJCol().find(andQuery);
//		System.out.println(cursor.size());
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while (cursor.hasNext()) {
			lists.add(cursor.next());	
		}
		return lists;
	}
}
