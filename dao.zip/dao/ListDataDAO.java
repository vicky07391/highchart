package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.bson.types.ObjectId;
import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.ListData;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class ListDataDAO extends BaseDAO<ListData>{

	public ListDataDAO(String colName) {
		colName = "ld_" + colName;
		String collectionName = colName;
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), ListData.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("email", 1), new BasicDBObject("background", true));
	}
	
	public void dropCollection() {
		getJCol().drop();
	}
	
	public ListData getDataByEmail(String email, String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("email", email));
		query.put("$and", obj);
		return getJCol().findOne(query);
	}
	
	public long countListDataByEmailPattern(String pattern) {
		BasicDBObject query = new BasicDBObject();
		query.put("email", Pattern.compile(pattern, 2));
		return getJCol().count(query);
	}
	
	public List<ListData> findByIds(List<ObjectId> ids) {
		BasicDBObject query = new BasicDBObject();
		query.put("_id", new BasicDBObject("$in", ids));
		List<ListData> data = new ArrayList<ListData>();
		DBCursor<ListData> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			data.add(cursor.next());
		}
		return data;
	}

	public List<ListData> findByEmails(String id, List<String> emails,
			int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("email", new BasicDBObject("$in", emails)));
		query.put("$and", obj);
		
		List<ListData> data = new ArrayList<ListData>();
		DBCursor<ListData> cursor = getJCol().find(query);
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			data.add(cursor.next());
		}
		return data;
	}
	
	public long countByEmails(String id, List<String> emails) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("email", new BasicDBObject("$in", emails)));
		query.put("$and", obj);
		
		return getJCol().count(query);
	}
}
