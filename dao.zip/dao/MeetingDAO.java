
package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Issue;
import com.crucialbits.cy.model.Meeting;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class MeetingDAO extends BaseDAO<Meeting> {

	public MeetingDAO() {
		String collectionName = "meeting";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Meeting.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
	}


	public List<Meeting> findAllByMonth(String accountId, List<String> customerIds,
			Date from, Date to ) {
		List<Meeting> meetings = new ArrayList<Meeting>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));

		obj.add(new BasicDBObject("scheduledAt", new BasicDBObject("$gte", from).append("$lte", to)));
		andQuery.put("$and", obj);
		DBCursor<Meeting> cursor = getJCol().find(andQuery);
		while (cursor.hasNext()) {
			meetings.add(cursor.next());
		}
		return meetings;
	}



	public List<Meeting> findLastMeeting(String accountId, String customerId, Date now, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		if(now != null) {
			obj.add(new BasicDBObject("scheduledAt",  new BasicDBObject("$lt", now)));
		}
		andQuery.put("$and", obj);

		DBCursor<Meeting> cursor = getJCol().find(andQuery).sort(new BasicDBObject("scheduledAt", -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Meeting> meetings = new ArrayList<Meeting>();
		while(cursor.hasNext()) {
			meetings.add(cursor.next());
		}
		return meetings;
	}

	public List<Meeting> findNextMeeting(String accountId, String customerId, Date now, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		if(now != null) {
			obj.add(new BasicDBObject("scheduledAt",  new BasicDBObject("$gte", now)));
		}
		andQuery.put("$and", obj);

		DBCursor<Meeting> cursor = getJCol().find(andQuery).sort(new BasicDBObject("scheduledAt", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Meeting> meetings = new ArrayList<Meeting>();
		while(cursor.hasNext()) {
			meetings.add(cursor.next());
		}
		return meetings;
	}

	public long countAll(String accountId, List<String> customerIds,
			Date from, Date to ) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));

		obj.add(new BasicDBObject("dueDate", new BasicDBObject("$gte", from)));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	public long countMeetings(String accountId, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}


}