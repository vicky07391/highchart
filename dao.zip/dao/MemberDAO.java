package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.MemberRole;
import com.crucialbits.cy.model.Member;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class MemberDAO extends BaseDAO<Member> {

	public MemberDAO() {
		String collectionName = "member";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Member.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("projectId", 1);
		compoundIndex.put("userId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("projectId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("userId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("role", 1), new BasicDBObject("background", true));
	}

	public long countMembersByProject(String accountId, String projectId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<Member> findUsingUserIds(String accountId, String projectId, List<String> userIds, MemberRole role) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("projectId", projectId));
		if(role != null) {
			obj.add(new BasicDBObject("role", role));
		}
		obj.add(new BasicDBObject("userId", new BasicDBObject("$in", userIds)));
		andQuery.put("$and", obj);
		List<Member> members = new ArrayList<Member>();
		DBCursor<Member> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			members.add(cursor.next());
		}
		return members;
	}
	
	public List<String> getDistinctUserIds(String accountId, String projectId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(projectId)) {
			obj.add(new BasicDBObject("projectId", projectId));
		}
		query.put("$and", obj);
		return getJCol().distinct("userId", query);
	}
}