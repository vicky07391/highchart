package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.NETicket;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class NETicketDAO extends BaseDAO<NETicket> {

	public NETicketDAO() {
		String collectionName = "neticket";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), NETicket.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		
	}
	
	public long countTickets(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public long countTicketsForDashboard(String accountId, String status, String customerId, Date from, Date to, String priority,
			String ticketType) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", status));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(ticketType)) {
			obj.add(new BasicDBObject("ticketType", ticketType));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", new Date())));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<String> getDistinctStatus(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("status", query);
	}
	
	public List<String> getDistinctPriority(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("priority", query);
	}
	
	public List<String> getDistinctType(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("ticketType", query);
	}
}
