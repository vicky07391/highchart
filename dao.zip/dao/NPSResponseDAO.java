package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.CustomerTimeseriesByDay;
import com.crucialbits.cy.model.NPSResponse;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class NPSResponseDAO extends BaseDAO<NPSResponse> {

	public NPSResponseDAO () {		
		String collectionName = "npsresponse";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), NPSResponse.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		
		BasicDBObject compoundIndex2 = new BasicDBObject();
        compoundIndex2.put("customerId", 1);
        compoundIndex2.put("accountId", 1);
        compoundIndex2.put("responsedAt", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));
        
        getJCol().ensureIndex(new BasicDBObject("email", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("response", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("responsedAt", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("surveyId", 1), new BasicDBObject("background", true));
	}

	
	public long countNPSResponses(String accountId, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<NPSResponse> getData(String accountId, String customerId, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		if(from != null && today != null) {
			obj.add(new BasicDBObject("responsedAt", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		andQuery.put("$and", obj);
		List<NPSResponse> dates = new ArrayList<NPSResponse>();
		DBCursor<NPSResponse> cursor = getJCol().find(andQuery).sort(new BasicDBObject("responsedAt", 1));
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}
}
