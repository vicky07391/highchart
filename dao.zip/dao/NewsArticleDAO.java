
package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.NewsArticle;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class NewsArticleDAO extends BaseDAO<NewsArticle>{

	public NewsArticleDAO() {
		String collectionName = "newsarticle";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), NewsArticle.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex2 = new BasicDBObject();
		compoundIndex2.put("accountId", 1);
		compoundIndex2.put("url", 1);
		compoundIndex2.put("publishedDate", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
		compoundIndex3.put("accountId", 1);
		compoundIndex3.put("friendlyId", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex4 = new BasicDBObject();
		compoundIndex4.put("accountId", 1);
		compoundIndex4.put("topicName", 1);
        getJCol().ensureIndex(compoundIndex4, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex5 = new BasicDBObject();
		compoundIndex5.put("accountId", 1);
		compoundIndex5.put("tags", 1);
        getJCol().ensureIndex(compoundIndex5, new BasicDBObject("background", true));
		
		getJCol().ensureIndex(new BasicDBObject("indexedInSearch", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("friendlyId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
	}
	
	public long countByAccount(String accountId) {
		BasicDBObject query = new BasicDBObject("accountId", accountId);
		return getJCol().count(query);
	}
	
	public List<NewsArticle> findUnindexedArticles(int maxSize) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("indexedInSearch", null));
		obj.add(new BasicDBObject("indexedInSearch", false));
		orQuery.put("$or", obj);
		
		List<NewsArticle> articles = new ArrayList<NewsArticle>();
		DBCursor<NewsArticle> cursor = getJCol().find(orQuery);
		while(cursor.hasNext()) {
			articles.add(cursor.next());
			if (articles.size() == maxSize) {
				break;
			}
		}
		return articles;
	}
	
	public void markIndexed(String id) {		
		NewsArticle article = getJCol().findOneById(id);
		article.setIndexedInSearch(true);
		updateById(id, article);
	}
	
	public NewsArticle findOneByFriendlyId(String accountId, String friendlyId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("friendlyId", friendlyId));
		obj.add(new BasicDBObject("accountId", accountId));
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
	
	public List<NewsArticle> findByTag(String accountId, List<String> tags,
			int skip, int limit) {
		List<NewsArticle> articles = new ArrayList<NewsArticle>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("tags", new BasicDBObject("$in", tags)));
		
		andQuery.put("$and", obj);
		DBCursor<NewsArticle> cursor = getJCol().find(andQuery);
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			articles.add(cursor.next());
		}
		return articles;
	}
	
	public long countByTag(String accountId, List<String> tags) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("tags", new BasicDBObject("$in", tags)));
		
		andQuery.put("$and", obj);
		
		return getJCol().count(andQuery);
	}
}