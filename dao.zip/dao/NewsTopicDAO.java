package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.NewsTopic;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class NewsTopicDAO extends BaseDAO<NewsTopic>{

	public NewsTopicDAO() {
		String collectionName = "newstopic";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), NewsTopic.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("topic", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        getJCol().ensureIndex(new BasicDBObject("processedAt", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("disabled", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("blocked", 1), new BasicDBObject("background", true));
	}
	
	public List<NewsTopic> getTopicsToProcess(int maxTopicsToProcess, Date cutOff) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("processedAt", null));
		orList.add(new BasicDBObject("processedAt", new BasicDBObject("$lt", cutOff)));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("disabled", false));
		andList.add(new BasicDBObject("blocked", false));
		andQuery.put("$and", andList);
		
		return findAll(andQuery, 0, maxTopicsToProcess);
	}
	
	public List<NewsTopic> getBlockedTopics(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("blocked", true));
		andQuery.put("$and", andList);
		return findAll(andQuery);
	}
}
