package com.crucialbits.cy.dao;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Account;
import com.crucialbits.cy.model.CustomerTimeseriesByDay;
import com.crucialbits.cy.model.License;
import com.crucialbits.cy.model.Opportunity;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class OpportunityDAO extends BaseDAO<Opportunity>{
	public OpportunityDAO() {
		String collectionName = "opportunity";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Opportunity.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	

	public void buildIndexes() {

	}
	
	public long countByCustomer(String accountId, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}

	
	
	public List<Opportunity> getOpportunities(String accountId, int skip, int limit) {
	
	
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("isClosed", true));
		obj.add(new BasicDBObject("isWon", true));
		obj.add(new BasicDBObject("notifyCustomer", false));
		
		/*if(lastRunAt != null ) {
			obj.add(new BasicDBObject("updatedAt", new BasicDBObject("$gte", lastRunAt).append("$lte", today)));
		}*/
		andQuery.put("$and", obj);
		List<Opportunity> opportunities = new ArrayList<Opportunity>();
		DBCursor<Opportunity> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			opportunities.add(cursor.next());
		}
		return opportunities;
	}
	
	public List<Opportunity> getOpportunitiesForIsWon(String accountId, boolean isWon, int skip, int limit) {
		
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("isWon", isWon));
		
		/*if(lastRunAt != null ) {
			obj.add(new BasicDBObject("updatedAt", new BasicDBObject("$gte", lastRunAt).append("$lte", today)));
		}*/
		andQuery.put("$and", obj);
		List<Opportunity> opportunities = new ArrayList<Opportunity>();
		DBCursor<Opportunity> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			opportunities.add(cursor.next());
		}
		return opportunities;
	}
	
}
