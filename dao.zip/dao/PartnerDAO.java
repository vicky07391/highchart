package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.Partner;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class PartnerDAO extends BaseDAO<Partner> {

	public PartnerDAO() {
		String collectionName = "partner";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Partner.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("externalId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("name", 1), new BasicDBObject("background", true));
		
	}

	public long countPartners(String accountId, String customerRange) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));

		if(!StringHelper.isEmpty(customerRange)){
			obj.add(new BasicDBObject("customersRange", customerRange));
		}

		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	
	/*public List<Partner> getDistinctPartners(String accountId, String customerTypeId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerTypeId)) {
			obj.add(new BasicDBObject("customerTypeId", customerTypeId));
		}
		andQuery.put("$and", obj);
		DBCursor<Partner> cursor = getJCol().find(andQuery).sort(new BasicDBObject("name", 1));
		List<Partner> partners = new ArrayList<Partner>();
		while (cursor.hasNext()) {
			partners.add(cursor.next());
		}
	
		return partners;
	}*/
}
