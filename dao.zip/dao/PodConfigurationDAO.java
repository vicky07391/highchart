package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.PodConfiguration;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class PodConfigurationDAO extends BaseDAO<PodConfiguration> {

	public PodConfigurationDAO() {
		String collectionName = "podconfiguration";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), PodConfiguration.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {		
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("podId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("podId", 1), new BasicDBObject("background", true));
	}
}
