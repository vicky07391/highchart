package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.PodGroup;
import com.crucialbits.cy.model.Issue;
import com.crucialbits.cy.model.Pod;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class PodDAO extends BaseDAO<Pod> {

	public PodDAO() {
		String collectionName = "pod";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Pod.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("key", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
	}
	
	
	public List<Pod> findPods(String accountId, PodGroup podGroup, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(accountId)){
			obj.add(new BasicDBObject("accountId", accountId));
		}
		if(podGroup != null) {
			obj.add(new BasicDBObject("group", podGroup));
		}
		andQuery.put("$and", obj);
		List<Pod> pods = new ArrayList<Pod>();
		DBCursor<Pod> cursor = getJCol().find(andQuery).sort(new BasicDBObject("name", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			pods.add(cursor.next());
		}
		return pods;
	}
	

	
	public long countPods(String accountId, String group) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(accountId)){
			obj.add(new BasicDBObject("accountId", accountId));
		}
		if(!StringHelper.isEmpty(group)) {
			obj.add(new BasicDBObject("group", PodGroup.valueOf(group.toUpperCase())));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
}
