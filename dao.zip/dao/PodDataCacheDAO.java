package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.PodDataCache;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class PodDataCacheDAO extends BaseDAO<PodDataCache> {

	public PodDataCacheDAO() {
		String collectionName = "poddatacache";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), PodDataCache.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {		
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("podId", 1);
		compoundIndex.put("paramHash", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("podId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("paramHash", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("createdAt", 1), new BasicDBObject("background", true));
	}
	
	public PodDataCache findCacheByTime(String accountId, String podId, String paramHash, Date from, Date to) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("podId", podId));
		obj.add(new BasicDBObject("paramHash", paramHash));
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
		}
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
}
