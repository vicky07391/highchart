package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Tag;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class PopularTagDAO extends BaseDAO<Tag>{

	public PopularTagDAO() {
		String collectionName = "populartag";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Tag.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	private void buildIndexes() {
		BasicDBObject compoundIndex2 = new BasicDBObject();
		compoundIndex2.put("accountId", 1);
		compoundIndex2.put("name", 1);
		BasicDBObject options2 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex2, options2);
		
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("popularity", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("name", 1), new BasicDBObject("background", true));
	}
}
