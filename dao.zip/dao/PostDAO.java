package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.PostType;
import com.crucialbits.cy.model.Post;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class PostDAO extends BaseDAO<Post>{

	public PostDAO() {
		String collectionName = "post";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Post.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {		
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("friendlyId", 1);
		compoundIndex.put("postType", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        getJCol().ensureIndex(new BasicDBObject("friendlyId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("postType", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("draft", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("parentId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("ancestorId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("postType", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("indexedInSearch", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("updatedAt", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("level", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("categories", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("tags", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("userId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("answerAccepted", 1), new BasicDBObject("background", true));
	}
	
	public Post findOneByFriendlyId(String accountId, String friendlyId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("friendlyId", friendlyId));
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().findOne(query);
	}
	
	public Post findOneByFriendlyIdAndPostType(String accountId, String friendlyId, PostType postType) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("friendlyId", friendlyId));
		obj.add(new BasicDBObject("postType", postType));
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().findOne(query);
	}
	
//	public Post findOneByFriendlyId(String friendlyId) {
//		BasicDBObject query = new BasicDBObject("friendlyId", friendlyId);
//		return getJCol().findOne(query);
//	}
	
	public Post findOneByParentId(String parentId) {
		BasicDBObject query = new BasicDBObject();
		query.put("parentId", parentId);
		return getJCol().findOne(query);
	}
	
	public List<Post> findAllUpToLevel(int level) {
		BasicDBObject query = new BasicDBObject();
		query.put("level", new BasicDBObject("$gt", 0).append("$lte", level));
		DBCursor<Post> cursor = getJCol().find(query);
		List<Post> posts = new ArrayList<Post>();
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		return posts;
	}
	
	public long countByType(String accountId, PostType postType) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("postType", postType));
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countDraftArticles(String accountId, PostType postType, String loggedInUserId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("postType", postType));
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("userId", loggedInUserId));
		obj.add(new BasicDBObject("draft", true));
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countInternalArticles(String accountId, PostType postType) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("postType", postType));
		obj.add(new BasicDBObject("accountId", accountId));
//		obj.add(new BasicDBObject("internal", true));
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<Post> findUnindexedPosts(int maxSize) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("indexedInSearch", null));
		obj.add(new BasicDBObject("indexedInSearch", false));
		orQuery.put("$or", obj);
		
		List<Post> posts = new ArrayList<Post>();
		DBCursor<Post> cursor = getJCol().find(orQuery);
		while(cursor.hasNext()) {
			posts.add(cursor.next());
			if (posts.size() == maxSize) {
				break;
			}
		}
		return posts;
	}

	public void markIndexed(String id) {		
		Post post = getJCol().findOneById(id);
		post.setIndexedInSearch(true);
		updateById(id, post);
	}
	
	public long countPostsByUserId(String accountId, String userId, PostType postType) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("userId", userId));
		obj.add(new BasicDBObject("postType", postType));
		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<Post> findByCategory(String accountId, List<String> categories,
			int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("categories", new BasicDBObject("$in", categories)));
		
		andQuery.put("$and", obj);
		DBCursor<Post> cursor = getJCol().find(andQuery);
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		return posts;
	}
	
	public List<Post> findByTag(String accountId, List<String> tags,
			int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("tags", new BasicDBObject("$in", tags)));
		
		andQuery.put("$and", obj);
		DBCursor<Post> cursor = getJCol().find(andQuery);
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		return posts;
	}
	
	public long countByCategory(String accountId, List<String> categories) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("categories", new BasicDBObject("$in", categories)));
		
		andQuery.put("$and", obj);
		
		return getJCol().count(andQuery);
	}
	
	public long countByTag(String accountId, List<String> tags) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("tags", new BasicDBObject("$in", tags)));
		
		andQuery.put("$and", obj);
		
		return getJCol().count(andQuery);
	}
	
	public List<Post> acceptedAnswers(String accountId, String parentId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("parentId", parentId));
		obj.add(new BasicDBObject("answerAccepted", "yes"));
		
		andQuery.put("$and", obj);
		return findAll(andQuery);
	}
	
	public List<Post> yesterdayPosts(String accountId, PostType postType, Date yesterday, Date today, int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("postType", postType));
		obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", yesterday).append("$lt", today)));
		
		andQuery.put("$and", obj);
		DBCursor<Post> cursor = getJCol().find(andQuery).sort(new BasicDBObject("createdAt", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		return posts;
	}
	
	public List<Post> findPosts(String accountId, PostType postType, 
			boolean internal, boolean draft, String sortField, boolean ascending, 
			String loggedInUserId, int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("sectionId", null));
		orList.add(new BasicDBObject("sectionId", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
//		if(!draft) {
//			andList.add(new BasicDBObject("internal", internal));
//		}
		andList.add(new BasicDBObject("draft", draft));
		andList.add(new BasicDBObject("postType", postType));
		if(!StringHelper.isEmpty(loggedInUserId)) {
			andList.add(new BasicDBObject("userId", loggedInUserId));
		}
		andList.add(orQuery);
		andQuery.put("$and", andList);
		
		DBCursor<Post> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortField, Integer.valueOf(ascending ? 1 : -1)));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		
		return posts;
	}
	
	public List<Post> findSectionPosts(String accountId, PostType postType, 
			boolean internal, boolean draft, String sortField, boolean ascending, 
			String loggedInUserId, String sectionId, int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("sectionId", sectionId));
//		if(!draft) {
//			andList.add(new BasicDBObject("internal", internal));
//		}
		andList.add(new BasicDBObject("draft", draft));
		andList.add(new BasicDBObject("postType", postType));
		if(!StringHelper.isEmpty(loggedInUserId) && draft) {
			andList.add(new BasicDBObject("userId", loggedInUserId));
		}
		andQuery.put("$and", andList);
		
		DBCursor<Post> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortField, Integer.valueOf(ascending ? 1 : -1)));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		
		return posts;
	}
	
	public long countPosts(String accountId, PostType postType, 
			boolean internal, boolean draft, String loggedInUserId) {
		
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("sectionId", null));
		orList.add(new BasicDBObject("sectionId", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
//		if(!draft) {
//			andList.add(new BasicDBObject("internal", internal));
//		}
		andList.add(new BasicDBObject("draft", draft));
		andList.add(new BasicDBObject("postType", postType));
		if(!StringHelper.isEmpty(loggedInUserId) && draft) {
			andList.add(new BasicDBObject("userId", loggedInUserId));
		}
		andList.add(orQuery);
		andQuery.put("$and", andList);
		
		return getJCol().count(andQuery);
	}
	
	public long countAllPosts(String accountId, PostType postType) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("postType", postType));
		andQuery.put("$and", andList);
		
		return getJCol().count(andQuery);
	}
	
	public long countSectionPosts(String accountId, PostType postType, 
			boolean internal, boolean draft,
			String loggedInUserId, String sectionId) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("sectionId", sectionId));
//		if(!draft) {
//			andList.add(new BasicDBObject("internal", internal));
//		}
		andList.add(new BasicDBObject("draft", draft));
		andList.add(new BasicDBObject("postType", postType));
		if(!StringHelper.isEmpty(loggedInUserId)) {
			andList.add(new BasicDBObject("userId", loggedInUserId));
		}
		andQuery.put("$and", andList);
		
		return getJCol().count(andQuery);
	}
	
	public List<Post> findCategoryViewData(String accountId, String sectionId, PostType postType, String[] categories,
			int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("sectionId", sectionId));
		obj.add(new BasicDBObject("postType", postType));
		if(postType.equals(PostType.KNOWLEDGEBASE)) {
			obj.add(new BasicDBObject("draft", false));
		}
		obj.add(new BasicDBObject("categories", new BasicDBObject("$in", categories)));
		
		andQuery.put("$and", obj);
		DBCursor<Post> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		return posts;
	}
	
	public List<Post> findAllByIds(String accountId, List<ObjectId> ids, int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("_id", new BasicDBObject("$in", ids)));
		
		andQuery.put("$and", obj);
		DBCursor<Post> cursor = getJCol().find(andQuery);
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while (cursor.hasNext()) {
			posts.add(cursor.next());	
		}
		return posts;
	}
	
	public long findPostsViewCount(String accountId, PostType postType) {
		long count = 0;
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("postType", postType));
		
		andQuery.put("$and", obj);
		DBCursor<Post> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			Post post = cursor.next();
			count += (post.getViewCount() != null) ? post.getViewCount() : 0;
		}
		return count;
	}
	
	public List<Post> findPostsForBackup(String accountId, String sectionId, PostType postType, int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("sectionId", sectionId));
		obj.add(new BasicDBObject("postType", postType));
		
		andQuery.put("$and", obj);
		DBCursor<Post> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		return posts;
	}
	
	public List<Post> findCategorizedPostsForBackup(String accountId, String sectionId, PostType postType, String[] catIds, int skip, int limit) {
		List<Post> posts = new ArrayList<Post>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("sectionId", sectionId));
		obj.add(new BasicDBObject("postType", postType));
		obj.add(new BasicDBObject("categories", new BasicDBObject("$in", catIds)));
		
		andQuery.put("$and", obj);
		DBCursor<Post> cursor = getJCol().find(andQuery).sort(new BasicDBObject("updatedAt", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			posts.add(cursor.next());
		}
		return posts;
	}
}
