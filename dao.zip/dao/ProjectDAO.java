package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Project;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class ProjectDAO extends BaseDAO<Project> {

	public ProjectDAO() {
		String collectionName = "project";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Project.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("friendlyId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("friendlyId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("supportProject", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("channel", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("name", 1), new BasicDBObject("background", true));
	}
	
	public Project findOneByFriendlyId(String accountId, String friendlyId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("friendlyId", friendlyId));
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().findOne(query);
	}

	public long countProjects(String accountId, boolean supportProject) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("supportProject", supportProject));
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().count(query);
	}
}
