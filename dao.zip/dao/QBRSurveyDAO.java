
package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Meeting;
import com.crucialbits.cy.model.QBRSurvey;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class QBRSurveyDAO extends BaseDAO<QBRSurvey> {

	public QBRSurveyDAO() {
		String collectionName = "qbrsurvey";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), QBRSurvey.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	public void buildIndexes() {

	}

	public long countQBRSurveys(String accountId, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}


	public List<QBRSurvey> findAllByMonth(String accountId, List<String> customerIds,
			Date from, Date to ) {
		List<QBRSurvey> qbrs = new ArrayList<QBRSurvey>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

		obj.add(new BasicDBObject("accountId", accountId));
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));
		}

		obj.add(new BasicDBObject("scheduledAt", new BasicDBObject("$gte", from).append("$lte", to)));
		andQuery.put("$and", obj);
		DBCursor<QBRSurvey> cursor = getJCol().find(andQuery);
		while (cursor.hasNext()) {
			qbrs.add(cursor.next());
		}
		return qbrs;
	}
	public long countAll(String accountId, List<String> customerIds,
			Date from, Date to ) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();

		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));

		obj.add(new BasicDBObject("dueDate", new BasicDBObject("$gte", from)));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}