package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Reply;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class ReplyDAO extends BaseDAO<Reply> {

	public ReplyDAO() {
		String collectionName = "reply";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Reply.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("issueId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("title", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("submitter", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("feedback", 1), new BasicDBObject("background", true));
	}
	
	public List<Reply> findCustomerIssueReplies(String accountId, List<String> issueIds,
			int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("issueId", new BasicDBObject("$in", issueIds)));
		andQuery.put("$and", obj);
		List<Reply> replies = new ArrayList<Reply>();
		DBCursor<Reply> cursor = getJCol().find(andQuery);
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			replies.add(cursor.next());
		}
		return replies;
	}
}
