
package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.client.salesforce.SFCase;
import com.crucialbits.client.zendesk.Status;
import com.crucialbits.client.zendesk.Ticket;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class SFCaseDAO extends BaseDAO<SFCase> {

	public SFCaseDAO() {
		String collectionName = "sfcase";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SFCase.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("caseNumber", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("caseId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("caseNumber", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("ownerId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("contactId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("priority", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("status", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("type", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("webEmail", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("fetchedAt", 1), new BasicDBObject("background", true));
	}
	
	public List<SFCase> findOpenCases(String accountId, List<String> statusList, int skip, int limit) {
		List<SFCase> cases = new ArrayList<SFCase>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
//		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));

		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		andQuery.put("$and", obj);
		
		DBCursor<SFCase> cursor = getJCol().find(andQuery).sort(new BasicDBObject("modifiedDate", -1));
		if(skip > 0){
		cursor.skip(skip);
		}
		if(limit > 0){
		cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			cases.add(cursor.next());
		}
		return cases;
	}
	
	public List<SFCase> findAllCases(String accountId, int skip, int limit) {
		List<SFCase> cases = new ArrayList<SFCase>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
//		obj.add(new BasicDBObject("status", new BasicDBObject("$ne", "Closed")));
		andQuery.put("$and", obj);
		
		DBCursor<SFCase> cursor = getJCol().find(andQuery).sort(new BasicDBObject("modifiedDate", -1));
		cursor.skip(skip);
		cursor.limit(limit);
		while(cursor.hasNext()) {
			cases.add(cursor.next());
		}
		return cases;
	}
	
	public long countByStatusOrUser(String accountId, String requesterId, List<String> statusList) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
//		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));

		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(!StringHelper.isEmpty(requesterId)) {
			obj.add(new BasicDBObject("ownerId", requesterId));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countAllStatusOrUser(String accountId, String requesterId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(requesterId)) {
			obj.add(new BasicDBObject("ownerId", requesterId));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	
	public long countAllTicketsForDashboard(String accountId, List<String> statusList, String type, String priority, 
			List<String> customerIds, String recent) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DAY_OF_MONTH, -1);
			obj.add(new BasicDBObject("createdDate", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	
	public long countAllOpenTicketsByCustomer(String accountId, String status, String customerId, Date date) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("Open")) {
			
			String[] statusArr = {"Open", "New", "Approved", "CAB Review Completed","IAR Completed","Implementation Scheduled","Implementation-Completed","RMAed to Lanner","Rejected","Requested-IAR","Requested-Review","Turnup Completed","Turnup Halted","Verification-Completed","Wait-AM-Feedback","Wait-Cust-FeedBack","Wait-Eng-Feedback","Wait-Logistics-Feedback","Wait-NAE-Feedback","Wait-NetOps-FeedBack","Wait-SE-FeedBack","Wait-SalesOps-Feedback"};
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusArr)));
			
		} else if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", status));
		}
		obj.add(new BasicDBObject("customerId", customerId));
		
		if(date != null) {
			obj.add(new BasicDBObject("createdDate", new BasicDBObject("$gte", date)));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	
	public List<SFCase> findAllOpenTicketsWithCustomerImpact(String accountId, String customerId, List<String> statusList, String type, String priority, List<String> customerIdsByManager, String recent, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIdsByManager != null && customerIdsByManager.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIdsByManager)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("createdDate", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		DBCursor<SFCase> cursor = getJCol().find(query).sort(new BasicDBObject("modifiedDate", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<SFCase> tickets = new ArrayList<SFCase>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	
	public List<String> getDistinctPriority(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("priority", query);
	}
	
	public long countAllTicketsByCreationDateRangeWithCustomer(String accountId, String customerId, Date from, Date to) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		obj.add(new BasicDBObject("customerId", customerId));
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdDate", new BasicDBObject("$gte", from).append("$lte", new Date())));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<String> getDistinctStatus(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("status", query);
	}
	
	public long countAllTicketsByCustomer(String accountId, String status, String priority, String type, String customerId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", status));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<String> getDistinctType(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("type", query);
	}
	
	public long countCustomerIssuesByDateRange(String accountId, String status, Date from, Date to, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(status != null) {
			obj.add(new BasicDBObject("status", status));
		}
		if(customerId != null) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdDate", new BasicDBObject("$gte", from).append("$lte", to)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<SFCase> findTicketsForDashboard(String accountId, List<String> statusList, String type, String priority, 
			List<String> customerIds, String recent, int skip, int limit) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("createdDate", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		DBCursor<SFCase> cursor = getJCol().find(query).sort(new BasicDBObject("modifiedDate", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<SFCase> tickets = new ArrayList<SFCase>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public List<SFCase> findUnassignedCases(String accountId, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", null));
		
		andQuery.put("$and", obj);
		DBCursor<SFCase> cursor = getJCol().find(andQuery).sort(new BasicDBObject("caseId", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<SFCase> tickets = new ArrayList<SFCase>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
}