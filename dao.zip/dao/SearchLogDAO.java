package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.SearchLog;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class SearchLogDAO extends BaseDAO<SearchLog> {

	public SearchLogDAO () {		
		String collectionName = "searchlog";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SearchLog.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("userId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("term", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("category", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("searchedAt", 1), new BasicDBObject("background", true));
	}
	
	public long countLogsByAccount(String accountId) {
		BasicDBObject query = new BasicDBObject();
		query.put("accountId", accountId);
		return getJCol().count(query);
	}
}
