package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Segment;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class SegmentDAO extends BaseDAO<Segment> {

	public SegmentDAO() {
		String collectionName = "segment";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Segment.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		
	}

	public long countSegments(String collectionName, String accountId) {
			BasicDBObject query = new BasicDBObject();
			List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
			if(!StringHelper.isEmpty(collectionName)) {
				obj.add(new BasicDBObject("collectionName", collectionName));
			}
			if(!StringHelper.isEmpty(accountId)) {
				obj.add(new BasicDBObject("accountId", accountId));
			}		
			query.put("$and", obj);
			return getJCol().count(query);
	}
}
