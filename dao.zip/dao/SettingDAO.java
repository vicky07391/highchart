package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.PostType;
import com.crucialbits.cy.app.Constants.SettingType;
import com.crucialbits.cy.model.Section;
import com.crucialbits.cy.model.Setting;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class SettingDAO extends BaseDAO<Setting> {

	public SettingDAO() {
		String collectionName = "setting";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Setting.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {	
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("sectionId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("settingType", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("postType", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("fieldNo", 1), new BasicDBObject("background", true));
	}
	
	public void resetFieldNumberOnDrag(String accountId, PostType postType, SettingType settingType, 
			int dragFrom, int dragTo, boolean isDragFromGreater) {
		BasicDBObject andQuery = new BasicDBObject();
		
		List<BasicDBObject> searchQuery = new ArrayList<BasicDBObject>();
		searchQuery.add(new BasicDBObject("postType", postType));
		searchQuery.add(new BasicDBObject("settingType", settingType));
		searchQuery.add(new BasicDBObject("accountId", accountId));
		
		BasicDBObject newQuery = new BasicDBObject();
		
		if(isDragFromGreater) {
			searchQuery.add(new BasicDBObject("fieldNo", new BasicDBObject("$lt", dragFrom).append("$gte", dragTo)));
			andQuery.put("$and", searchQuery);
			newQuery.put("$inc", new BasicDBObject("fieldNo", 1));
		} else {
			searchQuery.add(new BasicDBObject("fieldNo", new BasicDBObject("$gt", dragFrom).append("$lte", dragTo)));
			andQuery.put("$and", searchQuery);
			newQuery.put("$inc", new BasicDBObject("fieldNo", -1));
		}
		
		getJCol().updateMulti(andQuery, newQuery);
	}
	
	public List<Setting> findSettingsByPostType(String accountId, SettingType settingType, PostType postType){
		List<Setting> settingList = new ArrayList<Setting>();
        
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("name", "url"));
		orList.add(new BasicDBObject("name", "author"));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(orQuery);
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(new BasicDBObject("settingType", settingType));
		andList.add(new BasicDBObject("postType", postType));
		andQuery.put("$and", andList);
		
		DBCursor<Setting> c = getJCol().find(andQuery);
		while(c.hasNext()) {
			settingList.add(c.next());
		}
		
		return settingList;
	}
	
}
