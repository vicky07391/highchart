package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.SimpleeCustomerData;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class SimpleeCustomerDataDAO extends BaseDAO<SimpleeCustomerData>{
	
	public SimpleeCustomerDataDAO() {
		String collectionName = "simpleecustomerdata";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SimpleeCustomerData.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex1 = new BasicDBObject();
        compoundIndex1.put("customerId", 1);
        compoundIndex1.put("mmyy", 1);
        getJCol().ensureIndex(compoundIndex1, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex2 = new BasicDBObject();
        compoundIndex2.put("customerId", 1);
        compoundIndex2.put("market", 1);
        compoundIndex2.put("mmyy", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("url", 1);
        compoundIndex3.put("mmyy", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
	}
	
	public List<String> getDistinctMarkets(String customerId, String mmyy) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("mmyy", mmyy));
		andQuery.put("$and", obj);
		return getJCol().distinct("market", andQuery);
	}
	
}