package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.SimpleeEligibility;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class SimpleeEligibilityDAO extends BaseDAO<SimpleeEligibility>{

	public SimpleeEligibilityDAO() {
		String collectionName = "simpleeeligibility";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SimpleeEligibility.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex1 = new BasicDBObject();
        compoundIndex1.put("customerId", 1);
        compoundIndex1.put("mmyy", 1);
        getJCol().ensureIndex(compoundIndex1, new BasicDBObject("background", true));
	}
	
	public List<String> getDistinctMarkets(String customerId, String mmyy) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("mmyy", mmyy));
		andQuery.put("$and", obj);
		return getJCol().distinct("market", andQuery);
	}
	
	public long countByFilters(String customerId, String market, String mmyy) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("market", market));
		obj.add(new BasicDBObject("mmyy", mmyy));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}
