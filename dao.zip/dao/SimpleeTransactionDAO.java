package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.SimpleeTransaction;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class SimpleeTransactionDAO extends BaseDAO<SimpleeTransaction>{

	public SimpleeTransactionDAO() {
		String collectionName = "simpleetransaction";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SimpleeTransaction.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex1 = new BasicDBObject();
        compoundIndex1.put("customerId", 1);
        compoundIndex1.put("market", 1);
        compoundIndex1.put("month", 1);
        compoundIndex1.put("mmyy", 1);
        getJCol().ensureIndex(compoundIndex1, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex2 = new BasicDBObject();
        compoundIndex2.put("customerId", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("customerId", 1);
        compoundIndex3.put("market", 1);
        compoundIndex3.put("mmyy", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex4 = new BasicDBObject();
        compoundIndex4.put("customerId", 1);
        compoundIndex4.put("market", 1);
        compoundIndex4.put("month", 1);
        compoundIndex4.put("dept", 1);
        compoundIndex4.put("mmyy", 1);
        getJCol().ensureIndex(compoundIndex4, new BasicDBObject("background", true));
	}
	
	public List<String> getDistinctMarkets(String customerId, String mmyy) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("mmyy", mmyy));
		andQuery.put("$and", obj);
		return getJCol().distinct("market", andQuery);
	}
	
	public Double getAmountSumUsingFilters(String customerId, String market, String department, String payment, String transactionMonth, String mmyy) {
		BasicDBObject matchQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("mmyy", mmyy));
		if(!StringHelper.isEmpty(market)) {
			obj.add(new BasicDBObject("market", market));
		}
		if(!StringHelper.isEmpty(department)) {
			obj.add(new BasicDBObject("dept", department));
		}
		if(!StringHelper.isEmpty(payment)) {
			obj.add(new BasicDBObject("payment", payment));
		}
		if(!StringHelper.isEmpty(transactionMonth)) {
			obj.add(new BasicDBObject("month", Integer.parseInt(transactionMonth)));
		}
		matchQuery.put("$and", obj);
		
		BasicDBObject match = new BasicDBObject("$match", matchQuery);
		
		BasicDBObject groupFields = new BasicDBObject();
		groupFields.put("_id", (!StringHelper.isEmpty(market)) ? "$market" : null);
		groupFields.put("total", new BasicDBObject("$sum", "$amount"));
		
		BasicDBObject groupQuery = new BasicDBObject("$group", groupFields);
		
		AggregationOutput output = getCol().aggregate(match, groupQuery);
		
		for(DBObject object : output.results()) {
			return (!StringHelper.isEmpty(object.get("total").toString())) ? Double.parseDouble(object.get("total").toString()) : 0D;
		}
		
		return 0D;
	}
	
	public List<String> getDistinctDepartments(String customerId, String market, String mmyy) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		if(!StringHelper.isEmpty(market)) {
			obj.add(new BasicDBObject("market", market));
		}
		obj.add(new BasicDBObject("mmyy", mmyy));
		andQuery.put("$and", obj);
		return getJCol().distinct("dept", andQuery);
	}
	
	public List<String> getDistinctPaymentMethods(String customerId, String market, String mmyy) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		if(!StringHelper.isEmpty(market)) {
			obj.add(new BasicDBObject("market", market));
		}
		obj.add(new BasicDBObject("mmyy", mmyy));
		andQuery.put("$and", obj);
		return getJCol().distinct("payment", andQuery);
	}
	
	public long countUsingFilters(String customerId, String market, String department, String payment, String transactionMonth, String mmyy) {
		BasicDBObject matchQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("mmyy", mmyy));
		if(!StringHelper.isEmpty(market)) {
			obj.add(new BasicDBObject("market", market));
		}
		if(!StringHelper.isEmpty(department)) {
			obj.add(new BasicDBObject("dept", department));
		}
		if(!StringHelper.isEmpty(payment)) {
			obj.add(new BasicDBObject("payment", payment));
		}
		if(!StringHelper.isEmpty(transactionMonth)) {
			obj.add(new BasicDBObject("month", Integer.parseInt(transactionMonth)));
		}
		matchQuery.put("$and", obj);
		
		return getJCol().count(matchQuery);
	}
	
}
