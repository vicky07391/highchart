package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Campaign;
import com.crucialbits.cy.model.SurveyForwarding;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class SurveyForwardingDAO extends BaseDAO<SurveyForwarding> {

	public SurveyForwardingDAO() {
		String collectionName = "surveyforwarding";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SurveyForwarding.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("surveyId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("forwardedBy", 1), new BasicDBObject("background", true));
	}
	
	public List<SurveyForwarding> findForwardingObjectsForSendingMails(int maxSize) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("forwarded", null));
		obj.add(new BasicDBObject("forwarded", false));
		orQuery.put("$or", obj);
		
		List<SurveyForwarding> objects = new ArrayList<SurveyForwarding>();
		DBCursor<SurveyForwarding> cursor = getJCol().find(orQuery);
		while(cursor.hasNext()) {
			objects.add(cursor.next());
			if (objects.size() == maxSize) {
				break;
			}
		}
		return objects;
	}

	public long countSurveyForwardings(String accountId, String surveyId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}
