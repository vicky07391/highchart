package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.SurveyPage;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class SurveyPageDAO extends BaseDAO<SurveyPage> {
	
	public SurveyPageDAO() {
		String collectionName = "surveypage";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SurveyPage.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("surveyId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("pageNo", 1), new BasicDBObject("background", true));
	}
	
	public void resetPageNumberOnDrag(String accountId, String surveyId, 
			int dragFrom, int dragTo, boolean isDragFromGreater) {
		BasicDBObject andQuery = new BasicDBObject();
		
		List<BasicDBObject> searchQuery = new ArrayList<BasicDBObject>();
		searchQuery.add(new BasicDBObject("surveyId", surveyId));
		searchQuery.add(new BasicDBObject("accountId", accountId));
		
		BasicDBObject newQuery = new BasicDBObject();
		
		if(isDragFromGreater) {
			searchQuery.add(new BasicDBObject("pageNo", new BasicDBObject("$lt", dragFrom).append("$gte", dragTo)));
			andQuery.put("$and", searchQuery);
			newQuery.put("$inc", new BasicDBObject("pageNo", 1));
		} else {
			searchQuery.add(new BasicDBObject("pageNo", new BasicDBObject("$gt", dragFrom).append("$lte", dragTo)));
			andQuery.put("$and", searchQuery);
			newQuery.put("$inc", new BasicDBObject("pageNo", -1));
		}
		
		getJCol().updateMulti(andQuery, newQuery);
	}
	
	public void resetPageNumbers(String accountId, String surveyId, int resetFrom) {
		BasicDBObject andQuery = new BasicDBObject();
		
		List<BasicDBObject> searchQuery = new ArrayList<BasicDBObject>();
		searchQuery.add(new BasicDBObject("surveyId", surveyId));
		searchQuery.add(new BasicDBObject("accountId", accountId));
		searchQuery.add(new BasicDBObject("pageNo", new BasicDBObject("$gt", resetFrom)));
		
		andQuery.put("$and", searchQuery);
		
		BasicDBObject newQuery = new BasicDBObject();
		newQuery.put("$inc", new BasicDBObject("pageNo", -1));
		
		getJCol().updateMulti(andQuery, newQuery);
	}
	
	public long countPageBySurveyId(String surveyId) {
		
		BasicDBObject query = new BasicDBObject();
		query.put("surveyId", surveyId);
		
		return getJCol().count(query);
	}
}
