package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.bson.types.ObjectId;
import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.DistributionType;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.SurveyResponse;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.jcraft.jsch.Logger;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.sun.org.apache.xalan.internal.xsltc.compiler.Pattern;

public class SurveyResponseDAO extends BaseDAO<SurveyResponse>{

	public SurveyResponseDAO() {
		String collectionName = "surveyresponse";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SurveyResponse.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex2 = new BasicDBObject();
		compoundIndex2.put("accountId", 1);
		compoundIndex2.put("surveyId", 1);
		BasicDBObject options2 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex2, options2);
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
		compoundIndex3.put("accountId", 1);
		compoundIndex3.put("surveyId", 1);
		compoundIndex3.put("campaignId", 1);
		BasicDBObject options3 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex3, options3);
        
        BasicDBObject compoundIndex4 = new BasicDBObject();
		compoundIndex4.put("accountId", 1);
		compoundIndex4.put("surveyId", 1);
		compoundIndex4.put("campaignId", 1);
		compoundIndex4.put("completedAt", 1);
		BasicDBObject options4 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex4, options4);
        
        /*BasicDBObject compoundIndex5 = new BasicDBObject();
		compoundIndex5.put("accountId", 1);
		compoundIndex5.put("surveyId", 1);
		compoundIndex5.put("campaignId", 1);
		compoundIndex5.put("completedAt", 1);
		compoundIndex5.put("response", 1);
		BasicDBObject options5 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex5, options5);*/
	        
		getJCol().ensureIndex(new BasicDBObject("surveyId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("pageId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("responseId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("userId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("uid", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("listId", 1), new BasicDBObject("background", true));
	}

	public int countSurveyAttempts(String surveyId) {
		BasicDBObject match = new BasicDBObject("$match", new BasicDBObject("surveyId", surveyId));
		BasicDBObject groupFields = new BasicDBObject("_id", "$responseId");
		BasicDBObject group = new BasicDBObject("$group", groupFields);

		AggregationOutput output = getCol().aggregate(match, group);
		int i = 0;
		for(DBObject object : output.results()){
			i++;
		}
		return i;
	}

	public List<String> findDistinctUserIds(String accountId, String surveyId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		query.put("$and", obj);
		return getJCol().distinct("userId", query);
	}

	public List<String> findDistinctResponseIds(String accountId, String surveyId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		query.put("$and", obj);
		return getJCol().distinct("responseId", query);
	}

	public Set<String> respondantIds(String accountId, String surveyId) {
		Set<String> ids = new HashSet<String>();
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
//		obj.add(new BasicDBObject("response", new BasicDBObject("$ne", null)));
		query.put("$and", obj);
		DBCursor<SurveyResponse> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			SurveyResponse surveyResponse = cursor.next();
			if(StringHelper.isEmpty(surveyResponse.getUserId())) {
				ids.add(surveyResponse.getResponseId());
			} else {
				ids.add(surveyResponse.getUserId() + "known");
			}
		}
		return ids;
	}

	public Set<String> respondantIds(String accountId, String surveyId, String listId, String campaignId) {
		Set<String> ids = new HashSet<String>();
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("listId", listId));
		if(!StringHelper.isEmpty(campaignId)) {
			obj.add(new BasicDBObject("campaignId", campaignId));
		}
//		obj.add(new BasicDBObject("response", new BasicDBObject("$ne", null)));
		query.put("$and", obj);
		DBCursor<SurveyResponse> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			SurveyResponse surveyResponse = cursor.next();
			ids.add(surveyResponse.getUid());
		}
		return ids;
	}

	public List<String> getDistinctResponseIds(String accountId, String surveyId, String campaignId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("response", new BasicDBObject("$ne", null)));
		if(!StringHelper.isEmpty(campaignId)) {
			obj.add(new BasicDBObject("campaignId", campaignId));
		}
		query.put("$and", obj);

		return getJCol().distinct("responseId", query);
	}

	public List<String> getDistinctUserIds(String accountId, String surveyId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("response", new BasicDBObject("$ne", null)));
		query.put("$and", obj);

		return getJCol().distinct("userId", query);
	}

	public List<String> getDistinctListIds(String accountId, String surveyId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		query.put("$and", obj);

		return getJCol().distinct("threadId", query);
	}

	public List<String> getDistinctCampaignListIds(String accountId, String surveyId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
//		obj.add(new BasicDBObject("response", new BasicDBObject("$ne", null)));
		query.put("$and", obj);

		return getJCol().distinct("listId", query);
	}

	public long countResponses(String accountId, String surveyId, String campaignId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		if(!StringHelper.isEmpty(campaignId)) {
			obj.add(new BasicDBObject("campaignId", campaignId));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}

	public List<String> groupedDataByUID(String accountId, String listId, String surveyId, String campaignId, String filter, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("listId", listId));
		if(!StringHelper.isEmpty(campaignId)) {
			obj.add(new BasicDBObject("campaignId", campaignId));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		query.put("$and", obj);

		BasicDBObject match = new BasicDBObject("$match", query);
		BasicDBObject groupFields = new BasicDBObject("_id", "$uid");
		groupFields.put("total", new BasicDBObject("$sum", 1));
		BasicDBObject group = new BasicDBObject("$group", groupFields);

		AggregationOutput output = null;

		if(limit > 0) {
			BasicDBObject skipNum = new BasicDBObject("$skip", skip);
			BasicDBObject limitNum = new BasicDBObject("$limit", limit);
			output = getCol().aggregate(match, group, skipNum, limitNum);
		} else {
			output = getCol().aggregate(match, group);
		}

		List<String> userIds = new ArrayList<String>();
		if(output != null) {
			for(DBObject object : output.results()) {
				if(object.get("_id") != null) {
					userIds.add(object.get("_id").toString());
				}
			}
		}
		
	
		return userIds;
	}

	public List<String> groupedDataByResponseIds(String accountId, String surveyId, String campaignId, String filter, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("distributionType", "E"));
		if(!StringHelper.isEmpty(campaignId)) {
			obj.add(new BasicDBObject("campaignId", campaignId));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		query.put("$and", obj);

		BasicDBObject match = new BasicDBObject("$match", query);

		BasicDBObject groupFields = new BasicDBObject("_id", "$responseId");
		groupFields.put("total", new BasicDBObject("$sum", 1));

		BasicDBObject group = new BasicDBObject("$group", groupFields);

//		BasicDBObject sortFields = new BasicDBObject("total", -1);
//		BasicDBObject sort = new BasicDBObject("$sort", sortFields);

		AggregationOutput output = null;

		if(limit > 0) {
			BasicDBObject skipNum = new BasicDBObject("$skip", skip);
			BasicDBObject limitNum = new BasicDBObject("$limit", limit);
//			output = getCol().aggregate(match, group, sort, skipNum, limitNum);
			output = getCol().aggregate(match, group, skipNum, limitNum);
		} else {
			output = getCol().aggregate(match, group);
		}

		List<String> userIds = new ArrayList<String>();
		for(DBObject object : output.results()) {
			if(object.get("_id") != null) {
				userIds.add(object.get("_id").toString());
			}
		}
		return userIds;
	}

	public List<SurveyResponse> findResponseByUserEmail(String accountId, String surveyId, String questionId, String email, String campaignId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", java.util.regex.Pattern.compile(accountId, 2)));
		obj.add(new BasicDBObject("surveyId", java.util.regex.Pattern.compile(surveyId, 2)));
		obj.add(new BasicDBObject("response." + questionId + ".1", java.util.regex.Pattern.compile(email, 2)));
		if(!StringHelper.isEmpty(campaignId)) {
			obj.add(new BasicDBObject("campaignId", java.util.regex.Pattern.compile(campaignId, 2)));
		}
		query.put("$and", obj);
		DBCursor<SurveyResponse> cursor = getJCol().find(query);
		List<SurveyResponse> responses = new ArrayList<SurveyResponse>();
		while(cursor.hasNext()) {
			responses.add(cursor.next());
		}
		return responses;
	}

	public long getQuestionAttemptCount(String accountId, String surveyId, String campaignId, String questionId, String anonymous) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", campaignId));
		obj.add(new BasicDBObject("response." + questionId, new BasicDBObject("$exists", true)));

		if (!StringHelper.isEmpty(anonymous)) {
			obj.add(new BasicDBObject("responseId", new BasicDBObject("$exists", true)));
		} else {
			obj.add(new BasicDBObject("uid", new BasicDBObject("$exists", true)));
			obj.add(new BasicDBObject("listId", new BasicDBObject("$exists", true)));
		}

		query.put("$and", obj);
		return getJCol().count(query);
	}

	public List<SurveyResponse> getScenarioResponses(String accountId, String surveyId, String campaignId, String anonymous) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", campaignId));

		if (!StringHelper.isEmpty(anonymous)) {
			obj.add(new BasicDBObject("responseId", new BasicDBObject("$exists", true)));
		} else {
			obj.add(new BasicDBObject("uid", new BasicDBObject("$exists", true)));
			obj.add(new BasicDBObject("listId", new BasicDBObject("$exists", true)));
		}

		query.put("$and", obj);

		List<SurveyResponse> responses = new ArrayList<SurveyResponse>();
		DBCursor<SurveyResponse> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			responses.add(cursor.next());
		}
		return responses;
	}

	public List<SurveyResponse> findSegmentedResponses(String accountId, String surveyId, String campaignId, Map<String, Object> queryMap, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();

		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", campaignId));
		obj.add(new BasicDBObject("response", new BasicDBObject("$ne", null)));
		for(Map.Entry<String, Object> entry : queryMap.entrySet()) {
			obj.add(new BasicDBObject("response." + entry.getKey() + ".1", entry.getValue()));
		}

		query.put("$and", obj);

		DBCursor<SurveyResponse> cursor = getJCol().find(query).sort(new BasicDBObject("name", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<SurveyResponse> responses = new ArrayList<SurveyResponse>();
		while (cursor.hasNext()) {
			responses.add(cursor.next());
		}
		return responses;
	}

	public long countSegmentedResponses(String accountId, String surveyId, String campaignId, Map<String, Object> queryMap) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", campaignId));
		obj.add(new BasicDBObject("response", new BasicDBObject("$ne", null)));
		for(Map.Entry<String, Object> entry : queryMap.entrySet()) {
			obj.add(new BasicDBObject("response." + entry.getKey() + ".1", entry.getValue()));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}

	public SurveyResponse findResponseByEmail(String accountId, String surveyId, String questionId, String email) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("email", java.util.regex.Pattern.compile(email, 2)));
		obj.add(new BasicDBObject("response." + questionId + ".1", new BasicDBObject("$ne", null)));



		query.put("$and", obj);
		return getJCol().findOne(query);
	}

	public long countAnswerAttemptForMatrixQuestions(String accountId, String surveyId, String[] campaignIds, String questionId, String subQuestion, Object answer, String filter) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", campaignIds)));
		obj.add(new BasicDBObject("response." + questionId + "." + subQuestion, answer));
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}

	public long countAnswerAttemptForMatrixForNormalQuestions(String accountId, String surveyId, String[] campaignIds, String questionId, int index, Object answer, String filter) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", campaignIds)));
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		obj.add(new BasicDBObject("response." + questionId + "." + index, answer));

		query.put("$and", obj);
		return getJCol().count(query);
	}

	public long countAnswerAttemptForMatrixForTextQuestions(String accountId, String surveyId, String[] campaignIds, String questionId, int index, String filter) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", campaignIds)));
		obj.add(new BasicDBObject("response." + questionId + "." + index, new BasicDBObject("$ne", null)));
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}

	public long countAnswerAttemptForMatrixForOtherOptions(String accountId, String surveyId, String[] campaignIds, String questionId, String filter) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", campaignIds)));
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		obj.add(new BasicDBObject("response." + questionId + ".customoption", new BasicDBObject("$ne", null)));

		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	//temp
	public List<String> getDistinctUIDs(String accountId, String surveyId, String[] listIds) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("listId", new BasicDBObject("$in", listIds)));
		query.put("$and", obj);

		return getJCol().distinct("uid", query);
	}
	
	
	public List<SurveyResponse> findAnswerAttemptForMatrixQuestions(String accountId, String surveyId, String[] campaignIds, String questionId, String subQuestion, Object answer, String filter, String responseId, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", campaignIds)));
		if(!StringHelper.isEmpty(responseId)) {
			obj.add(new BasicDBObject("_id", new ObjectId(responseId)));
		}
		obj.add(new BasicDBObject("response." + questionId + "." + subQuestion, answer));
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		query.put("$and", obj);

		DBCursor<SurveyResponse> cursor = getJCol().find(query).sort(new BasicDBObject("name", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<SurveyResponse> responses = new ArrayList<SurveyResponse>();
		while (cursor.hasNext()) {
			responses.add(cursor.next());
		}
		
		return responses;
	}

	public List<SurveyResponse> findAnswerAttemptForMatrixForNormalQuestions(String accountId, String surveyId, String[] campaignIds, String questionId, int index, Object answer, String filter, String responseId, int skip, int limit ) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", campaignIds)));
		if(!StringHelper.isEmpty(responseId)) {
			obj.add(new BasicDBObject("_id", new ObjectId(responseId)));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		obj.add(new BasicDBObject("response." + questionId + "." + index, answer));

		query.put("$and", obj);
		DBCursor<SurveyResponse> cursor = getJCol().find(query).sort(new BasicDBObject("name", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<SurveyResponse> responses = new ArrayList<SurveyResponse>();
		while (cursor.hasNext()) {
			responses.add(cursor.next());
		}
		
		return responses;
	}
	
	public List<SurveyResponse> findAnswerAttemptForMatrixForTextQuestions(String accountId, String surveyId, String[] campaignIds, String questionId, int index, String filter, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", campaignIds)));
		obj.add(new BasicDBObject("response." + questionId + "." + index, new BasicDBObject("$ne", null)));
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}

		query.put("$and", obj);
		DBCursor<SurveyResponse> cursor = getJCol().find(query).sort(new BasicDBObject("name", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<SurveyResponse> responses = new ArrayList<SurveyResponse>();
		while (cursor.hasNext()) {
			responses.add(cursor.next());
		}
		
		return responses;		
	}

	
	public List<SurveyResponse> findAnswerAttemptForMatrixForOtherOptions(String accountId, String surveyId, String[] campaignIds, String questionId, String filter, String responseId, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", campaignIds)));
		if(!StringHelper.isEmpty(responseId)) {
			obj.add(new BasicDBObject("_id", new ObjectId(responseId)));
		}
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}
		obj.add(new BasicDBObject("response." + questionId + ".customoption", new BasicDBObject("$ne", null)));

		query.put("$and", obj);
		DBCursor<SurveyResponse> cursor = getJCol().find(query).sort(new BasicDBObject("name", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<SurveyResponse> responses = new ArrayList<SurveyResponse>();
		while (cursor.hasNext()) {
			responses.add(cursor.next());
		}
		
		return responses;
	}
	
	public List<SurveyResponse> findBySurveyAndCampaign(String accountId, String surveyId, String[] campaignIds, String filter, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("surveyId", surveyId));
		
		List<String> cIds = new ArrayList<String>();
		for(String id : campaignIds) {
			if(!StringHelper.isEmpty(id)) {
				cIds.add(id);
			}
		}
		
		obj.add(new BasicDBObject("campaignId", new BasicDBObject("$in", cIds)));
		if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("completed")) {
			obj.add(new BasicDBObject("completedAt", new BasicDBObject("$ne", null)));
		} else if(!StringHelper.isEmpty(filter) && filter.equalsIgnoreCase("partial")) {
			obj.add(new BasicDBObject("completedAt", null));
		}

		query.put("$and", obj);
		
		DBCursor<SurveyResponse> cursor = getJCol().find(query).sort(new BasicDBObject("name", 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<SurveyResponse> responses = new ArrayList<SurveyResponse>();
		while (cursor.hasNext()) {
			responses.add(cursor.next());
		}
		return responses;
	}

}