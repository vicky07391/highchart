package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.SurveyTemplate;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;

public class SurveyTemplateDAO extends BaseDAO<SurveyTemplate> {
	public SurveyTemplateDAO() {
		String collectionName = "surveytemplate";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SurveyTemplate.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
	}
	
}
