package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.Report;
import com.crucialbits.cy.model.SystemAction;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class SystemActionDAO extends BaseDAO<SystemAction>{

	public SystemActionDAO() {
		String collectionName = "systemaction";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), SystemAction.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		
	}
	
	
	public long countByFilters(String accountIdFilter, String entity) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountIdFilter));
		if(!StringHelper.isEmpty(entity)){
		obj.add(new BasicDBObject("entity", entity));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<SystemAction> findSystemAction(String accountId, List<String> entities, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		if(entities != null) {
			obj.add(new BasicDBObject("entity", new BasicDBObject("$in", entities)));
		}
		
		andQuery.put("$and", obj);

		DBCursor<SystemAction> cursor = getJCol().find(andQuery).sort(new BasicDBObject("createdAt", -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<SystemAction> systemActions = new ArrayList<SystemAction>();
		while(cursor.hasNext()) {
			systemActions.add(cursor.next());
		}
		return systemActions;
	}
	
	public long countSystemAction(String accountId, List<String> entities) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
	
		if(entities != null) {
			obj.add(new BasicDBObject("entity", new BasicDBObject("$in", entities)));
		}
		

		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}
