package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.FeatureCategory;
import com.crucialbits.cy.model.Tag;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class TagDAO extends BaseDAO<Tag>{

	public TagDAO() {
		String collectionName = "tag";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Tag.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	private void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("parentId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("urlFriendlyName", 1), new BasicDBObject("background", true));
	}
	
	
	public Tag findByFriendlyId(String accountId, String friendlyId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("urlFriendlyName", friendlyId));
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
	
//	db.tag.update({accountId:"54a1000cb99a9289585e6f6a"},{$unset:{urlFriendlyName:1}},{multi:true})
}
