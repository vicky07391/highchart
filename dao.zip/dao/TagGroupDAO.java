package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Tag;
import com.crucialbits.cy.model.TagGroup;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class TagGroupDAO extends BaseDAO<TagGroup> {

	public TagGroupDAO() {
		String collectionName = "taggroup";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), TagGroup.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("parentId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("urlFriendlyName", 1), new BasicDBObject("background", true));
	}
	
	public TagGroup findByFriendlyId(String accountId, String friendlyId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("urlFriendlyName", friendlyId));
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
}
