package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Temp;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class TempDAO extends BaseDAO<Temp>{

	public TempDAO() {
		String collectionName = "temp";
		String dbName = AppProps.getInstance().getStringValue("databaseName");

		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Temp.class, String.class));

		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
        
		BasicDBObject compoundIndex1 = new BasicDBObject();
        compoundIndex1.put("accountId", 1);
        compoundIndex1.put("type", 1);
        compoundIndex1.put("entity", 1);
        getJCol().ensureIndex(compoundIndex1, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex2 = new BasicDBObject();
        compoundIndex2.put("accountId", 1);
        compoundIndex2.put("type", 1);
        compoundIndex2.put("entity", 1);
        compoundIndex2.put("dateRange", 1);
        getJCol().ensureIndex(compoundIndex2, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("accountId", 1);
        compoundIndex3.put("type", 1);
        compoundIndex3.put("entity", 1);
        compoundIndex3.put("dateRange", 1);
        compoundIndex3.put("groups", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex4 = new BasicDBObject();
        compoundIndex4.put("accountId", 1);
        compoundIndex4.put("podId", 1);
        compoundIndex4.put("entity", 1);
        compoundIndex4.put("type", 1);
        compoundIndex4.put("dateRange", 1);
        getJCol().ensureIndex(compoundIndex4, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex5 = new BasicDBObject();
        compoundIndex5.put("accountId", 1);
        compoundIndex5.put("podId", 1);
        compoundIndex5.put("entity", 1);
        compoundIndex5.put("entityId", 1);
        compoundIndex5.put("type", 1);
        compoundIndex5.put("dateRange", 1);
        getJCol().ensureIndex(compoundIndex5, new BasicDBObject("background", true));
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("type", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("entity", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("entityId", 1), new BasicDBObject("background", true));
	}
	
	public long countByFilters(String accountId, String type, String entity, Map<String, Object> paramMap) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("type", type));
		obj.add(new BasicDBObject("entity", entity));	
		for(Map.Entry<String, Object> mp : paramMap.entrySet()){
			if(mp.getValue() != null && !StringHelper.isEmpty(mp.getValue().toString())) {
				obj.add(new BasicDBObject(mp.getKey(), mp.getValue()));
			}
		}		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}
