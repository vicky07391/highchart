package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.TimeSeriesDate;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class TimeSeriesDateDAO extends BaseDAO<TimeSeriesDate>{


	public TimeSeriesDateDAO() {
		String collectionName = "timeseriesdate";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), TimeSeriesDate.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
        getJCol().ensureIndex(new BasicDBObject("fieldName", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("timestampDate", 1), new BasicDBObject("background", true));
	}
	
	public List<TimeSeriesDate> getData(String accountId, String customerId, String fieldName, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		obj.add(new BasicDBObject("fieldName", fieldName));
		if(from != null && today != null) {
			obj.add(new BasicDBObject("timestampDate", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		andQuery.put("$and", obj);
		List<TimeSeriesDate> dates = new ArrayList<TimeSeriesDate>();
		DBCursor<TimeSeriesDate> cursor = getJCol().find(andQuery).sort(new BasicDBObject("timestampDate", 1));
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}
	
}
