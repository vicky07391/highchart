package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.TimeseriesByDay;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class TimeseriesByDayDAO extends BaseDAO<TimeseriesByDay> {

	public TimeseriesByDayDAO() {
		String collectionName = "timeseriesbyday";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), TimeseriesByDay.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex2 = new BasicDBObject();
		compoundIndex2.put("accountId", 1);
		compoundIndex2.put("fieldName", 1);
		compoundIndex2.put("date", 1);
		BasicDBObject options2 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex2, options2);
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("accountId", 1);
        compoundIndex3.put("fieldName", 1);
		BasicDBObject options3 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex3, options3);
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("fieldName", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("date", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("fieldValue", 1), new BasicDBObject("background", true));
	}
	
	public List<TimeseriesByDay> getData(String accountId, String fieldName, Date from, Date today) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("fieldName", fieldName));
		if(from != null && today != null) {
			obj.add(new BasicDBObject("date", new BasicDBObject("$gte", from).append("$lte", today)));
		}
		andQuery.put("$and", obj);
		List<TimeseriesByDay> dates = new ArrayList<TimeseriesByDay>();
		DBCursor<TimeseriesByDay> cursor = getJCol().find(andQuery).sort(new BasicDBObject("date", 1));
		while(cursor.hasNext()) {
			dates.add(cursor.next());
		}
		return dates;
	}
}
