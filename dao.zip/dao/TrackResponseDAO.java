package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.TrackResponse;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class TrackResponseDAO extends BaseDAO<TrackResponse> {

	public TrackResponseDAO() {
		String collectionName = "trackresponse";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), TrackResponse.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {		
        getJCol().ensureIndex(new BasicDBObject("postId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("trackId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("userId", 1), new BasicDBObject("background", true));
	}
	
	public long countByTrackAndUser(String accountId, String trackId, String userId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("trackId", trackId));
		obj.add(new BasicDBObject("userId", userId));
		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<String> getDistinctUserIdsByTrack(String accountId, String trackId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("trackId", trackId));
		query.put("$and", obj);
		
		return getJCol().distinct("userId", query);
	}
}
