package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.PointType;
import com.crucialbits.cy.model.Report;
import com.crucialbits.cy.model.UserAction;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.AggregationOutput;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class UserActionDAO extends BaseDAO<UserAction> {
	
	public UserActionDAO() {
		String collectionName = "useraction";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), UserAction.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("userId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("contentId", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("contentType", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("ActionType", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("VoteType", 1), new BasicDBObject("background", true));
		getJCol().ensureIndex(new BasicDBObject("createdAt", 1), new BasicDBObject("background", true));
	}
	
	public List<UserAction> findActiveActionsByCategory(String accountId, 
			Date currentDate, Date firstDate) {
//		System.out.println(currentDate + "\t\t" + firstDate);
		List<UserAction> userActions = new ArrayList<UserAction>();
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", firstDate).append("$lte", currentDate)));
		
		query.put("$and", obj);
		
		DBCursor<UserAction> cursor = getJCol().find(query).sort(new BasicDBObject("createdAt", -1));
		while(cursor.hasNext()) {
			userActions.add(cursor.next());
		}
		return userActions;
	}
	
	public long countByDateAndPointType(String accountId, Date today, PointType pointType) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("actionType", pointType));
		obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", today)));
		
		andQuery.put("$and", obj);
		return count(andQuery);
	}
	
	public List<UserAction> findContentReportDetails(String accountId, String contentId, int skip, int limit) {

		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("contentId", contentId));
		obj.add(new BasicDBObject("actionType", "PAGEVIEW"));
		obj.add(new BasicDBObject("userId", new BasicDBObject("$ne", null)));
		
		query.put("$and", obj);
		DBCursor<UserAction> cursor = getJCol().find(query).sort(new BasicDBObject("createdAt", -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<UserAction> userActions = new ArrayList<UserAction>();
		while(cursor.hasNext()) {
			userActions.add(cursor.next());
		}
		return userActions;
	}
	
	public long countContentReportDetails(String accountId, String contentId) {

		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("contentId", contentId));
		obj.add(new BasicDBObject("actionType", "PAGEVIEW"));
		obj.add(new BasicDBObject("userId", new BasicDBObject("$ne", null)));
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<Report> getBasicViewReport(String accountId, String contentType, String actionType, Date from, Date to) {
		BasicDBObject matchQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("contentType", contentType));
		if(!StringHelper.isEmpty(actionType)) {
			obj.add(new BasicDBObject("actionType", actionType));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", from).append("$lte", to)));
		}
		matchQuery.put("$and", obj);
		
		BasicDBObject match = new BasicDBObject("$match", matchQuery);
		
		BasicDBObject groupFields = new BasicDBObject();
		groupFields.put("_id", "$userId");
		groupFields.put("count", new BasicDBObject("$sum", 1));
		groupFields.put("date", new BasicDBObject("$max", "$createdAt"));
		
		BasicDBObject groupQuery = new BasicDBObject("$group", groupFields);
		
		AggregationOutput output = getCol().aggregate(match, groupQuery);
		
		List<Report> reports = new ArrayList<Report>();
		for(DBObject object : output.results()) {
			if((!StringHelper.isEmpty(object.get("_id").toString()))) {
				Report r = new Report();
				r.setUserId(object.get("_id").toString());
				r.setPageViews(Long.parseLong(object.get("count").toString()));
				r.setFormattedDate(object.get("date").toString());
				reports.add(r);
			}
		}
		
		return reports;
	}
}
