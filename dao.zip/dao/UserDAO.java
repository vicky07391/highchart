package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.PostType;
import com.crucialbits.cy.app.Constants.UserRole;
import com.crucialbits.cy.model.Customer;
import com.crucialbits.cy.model.Issue;
import com.crucialbits.cy.model.Post;
import com.crucialbits.cy.model.User;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class UserDAO extends BaseDAO<User> {
	
	public UserDAO() {
		String collectionName = "user";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), User.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("email", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        getJCol().ensureIndex(new BasicDBObject("friendlyId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("password", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("email", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("firstName", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("partnerId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("externalId", 1), new BasicDBObject("background", true));
	}
	
	public List<User> findUnknownCustomerUsers(String accountId, int skip, int limit) {
		List<User> users = new ArrayList<User>();
		
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orList = new ArrayList<BasicDBObject>();
		orList.add(new BasicDBObject("customerId", null));
		orList.add(new BasicDBObject("customerId", ""));
		orQuery.put("$or", orList);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> andList = new ArrayList<BasicDBObject>();
		andList.add(new BasicDBObject("accountId", accountId));
		andList.add(orQuery);
		andQuery.put("$and", andList);
		
		DBCursor<User> cursor = getJCol().find(andQuery);
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			users.add(cursor.next());
		}
		
		return users;
	}
	
	public User checkCredentials(String userName, String password) {
		BasicDBObject query = new BasicDBObject();
		query.put("email", userName);
		query.put("password", password);
		return getJCol().findOne(query);
	}
	
	public User findOneByFriendlyId(String accountId, String friendlyId){
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("friendlyId", friendlyId));
		obj.add(new BasicDBObject("accountId", accountId));
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
	
	public long countByAccountId(String accountId, String pattern) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(pattern)) {
			obj.add(new BasicDBObject("firstName", Pattern.compile(pattern, 2)));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countByCustomerId(String customerId, String pattern) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("customerId", customerId));
		if(!StringHelper.isEmpty(pattern)) {
			obj.add(new BasicDBObject("firstName", Pattern.compile(pattern, 2)));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<User> yesterdaysUsers(String accountId, Date yesterday, Date today, int skip, int limit) {
		List<User> users = new ArrayList<User>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", yesterday).append("$lt", today)));
		
		andQuery.put("$and", obj);
		DBCursor<User> cursor = getJCol().find(andQuery).sort(new BasicDBObject("createdAt", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			users.add(cursor.next());
		}
		return users;
	}
	
	/*public List<User> findAllByIds(String accountId, String[] ids) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("_id", new BasicDBObject("$in", ids)));
		query.put("$and", obj);
		List<User> users = new ArrayList<User>();
		DBCursor<User> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			users.add(cursor.next());
		}
		return users;
	}*/
	
	public List<User> findUsingInRoles(String accountId, String[] roles, String name, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(name)) {
			obj.add(new BasicDBObject("firstName", Pattern.compile(name, 2)));
		}
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("role", new BasicDBObject("$in", roles)));
		query.put("$and", obj);
		List<User> users = new ArrayList<User>();
		DBCursor<User> cursor = getJCol().find(query);
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			users.add(cursor.next());
		}
		return users;
	}
	
	public long countByAccountAndRole(String accountId, UserRole userRole) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("role", userRole));
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<String> getDistinctEmails(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("email", query);
	}
	
	public long countByAccountAndCustomer(String accountId, String customerId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		query.put("$and", obj);
		return getJCol().count(query);
	}

	public List<User> findAllByCustomerIds(String accountId,List<String> customerIds) {
		List<User> users = new ArrayList<User>();
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId",accountId));
		if(customerIds !=null && customerIds.size() > 0){
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in",customerIds)));
		}
		query.put("$and", obj);
		DBCursor<User> cursor = getJCol().find(query);
		while(cursor.hasNext())
		{
			users.add(cursor.next());
		}
		
		return users;
	}
	
	

	public List<User> findDeletedUsers(String accountId, String sortBy, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deleted", true));
		andQuery.put("$and", obj);
		List<User> users = new ArrayList<User>();
		DBCursor<User> cursor = getJCol().find(andQuery).sort(new BasicDBObject(sortBy, 1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			users.add(cursor.next());
		}
		return users;
	}
	
	public void deleteLastThirtyDaysDeletedUsers(String accountId, Calendar calendar) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deletedAt", new BasicDBObject("$lte", calendar.getTime())));
		andQuery.put("$and", obj);
		getJCol().remove(andQuery);
	}
	

	public long countDeletedUsers(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("deleted", true));
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<User> findActiveUsers(String accountId, String role, String customerId, String pattern, int skip, int limit) {
		List<User> users = new ArrayList<User>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(role)) {
			obj.add(new BasicDBObject("role", UserRole.valueOf(role)));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(pattern)) {
			obj.add(new BasicDBObject("firstName", Pattern.compile(pattern, 2)));
		}
		
		andQuery.put("$and", obj);
		DBCursor<User> cursor = getJCol().find(andQuery).sort(new BasicDBObject("name", 1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			users.add(cursor.next());
		}
		return users;
	}
	
	public long findActiveUsersCount(String accountId, String role, String customerId, String pattern) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		if(!StringHelper.isEmpty(accountId)) {
			obj.add(new BasicDBObject("accountId", accountId));
		}
		if(!StringHelper.isEmpty(role)) {
			obj.add(new BasicDBObject("role", UserRole.valueOf(role)));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(pattern)) {
			obj.add(new BasicDBObject("firstName", Pattern.compile(pattern, 2)));
		}
		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<User> findUndeletedUsers(String accountId, String role, String externalRole, 
			String customerId, String pattern, boolean deleted, int skip, int limit) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("deleted", deleted));
		if(!StringHelper.isEmpty(accountId)) {
			obj.add(new BasicDBObject("accountId", accountId));
		}
		if(!StringHelper.isEmpty(role)) {
			obj.add(new BasicDBObject("role", UserRole.valueOf(role)));
		}
		if(!StringHelper.isEmpty(externalRole)) {
			obj.add(new BasicDBObject("externalRole", externalRole));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(pattern)) {
			obj.add(new BasicDBObject("firstName", Pattern.compile(pattern, 2)));
		}
		
		andQuery.put("$and", obj);
		DBCursor<User> cursor = getJCol().find(andQuery).sort(new BasicDBObject("name", 1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<User> users = new ArrayList<User>();
		while(cursor.hasNext()) {
			users.add(cursor.next());
		}
		return users;
	}
	
	public long countUndeletedUsers(String accountId, String role, String externalRole, 
			String customerId, String pattern, boolean deleted) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("deleted", deleted));
		if(!StringHelper.isEmpty(accountId)) {
			obj.add(new BasicDBObject("accountId", accountId));
		}
		if(!StringHelper.isEmpty(role)) {
			obj.add(new BasicDBObject("role", UserRole.valueOf(role)));
		}
		if(!StringHelper.isEmpty(externalRole)) {
			obj.add(new BasicDBObject("externalRole", externalRole));
		}
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(!StringHelper.isEmpty(pattern)) {
			obj.add(new BasicDBObject("firstName", Pattern.compile(pattern, 2)));
		}
		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
}