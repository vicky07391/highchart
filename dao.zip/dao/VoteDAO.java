package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.Vote;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class VoteDAO extends BaseDAO<Vote> {
	
	public VoteDAO() {
		String collectionName = "vote";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Vote.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {		
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("accountId", 1);
		compoundIndex.put("postId", 1);
		compoundIndex.put("userId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        
        getJCol().ensureIndex(new BasicDBObject("postType", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("voteType", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("userId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("postId", 1), new BasicDBObject("background", true));
	}
	
	public Vote checkVoteByUser(String accountId, String userId, String postId) {
		BasicDBObject query = new BasicDBObject();
		query.put("userId", userId);
		query.put("postId", postId);
		query.put("accountId", accountId);
		return getJCol().findOne(query);
	}
	
	public long countVotesByUserId(String accountId, String userId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("userId", userId));
		
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<Vote> yesterdaysVotes(String accountId, Date yesterday, Date today, int skip, int limit) {
		List<Vote> votes = new ArrayList<Vote>();
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("createdAt", new BasicDBObject("$gte", yesterday).append("$lt", today)));
		
		andQuery.put("$and", obj);
		DBCursor<Vote> cursor = getJCol().find(andQuery).sort(new BasicDBObject("createdAt", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			votes.add(cursor.next());
		}
		return votes;
	}
}