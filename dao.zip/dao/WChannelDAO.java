package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.WChannel;
import com.crucialbits.cy.model.WTrigger;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class WChannelDAO extends BaseDAO<WChannel> {

	public WChannelDAO() {
		String collectionName = "wchannel";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), WChannel.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("friendlyId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        getJCol().ensureIndex(compoundIndex, options);
	}
	
	public List<WChannel> findCommonChannels(String type) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orObj = new ArrayList<BasicDBObject>();
		orObj.add(new BasicDBObject("preferredAccount", null));
		orObj.add(new BasicDBObject("preferredAccount", ""));
		orQuery.put("$or", orObj);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("type", type.toUpperCase()));
		
		obj.add(orQuery);
		
		andQuery.put("$and", obj);
		DBCursor<WChannel> cursor = getJCol().find(andQuery);
		
		List<WChannel> triggers = new ArrayList<WChannel>();
		while(cursor.hasNext()) {
			triggers.add(cursor.next());
		}
		return triggers;
	}
	
	public List<WChannel> findAccountChannels(String accountId, String type) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("type", type.toUpperCase()));
		obj.add(new BasicDBObject("preferredAccount", accountId));
		
		andQuery.put("$and", obj);
		DBCursor<WChannel> cursor = getJCol().find(andQuery);
		
		List<WChannel> triggers = new ArrayList<WChannel>();
		while(cursor.hasNext()) {
			triggers.add(cursor.next());
		}
		return triggers;
	}
	
	
	
}
