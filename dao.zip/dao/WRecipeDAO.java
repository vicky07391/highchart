package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.WRecipeStatus;
import com.crucialbits.cy.model.Campaign;
import com.crucialbits.cy.model.WRecipe;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class WRecipeDAO extends BaseDAO<WRecipe> {

	public WRecipeDAO() {
		String collectionName = "wrecipe";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), WRecipe.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {}

	public long countAll(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<WRecipe> findRecipesForTrigger(int maxSize) {
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("status", WRecipeStatus.ENABLED));
		obj.add(new BasicDBObject("processing", false));
		andQuery.put("$and", obj);
		
		List<WRecipe> recipes = new ArrayList<WRecipe>();
		DBCursor<WRecipe> cursor = getJCol().find(andQuery);
		while(cursor.hasNext()) {
			recipes.add(cursor.next());
			if (recipes.size() == maxSize) {
				break;
			}
		}
		return recipes;
	}
	
	public List<WRecipe> findRecipesForTriggerEnhanced(int maxSize) {
		
		BasicDBObject query = new BasicDBObject("status", WRecipeStatus.ENABLED);
		List<WRecipe> recipes = new ArrayList<WRecipe>();
		DBCursor<WRecipe> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			recipes.add(cursor.next());
			if (recipes.size() == maxSize) {
				break;
			}
		}
		return recipes;
	}
}
