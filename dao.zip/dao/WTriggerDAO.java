package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.WTrigger;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class WTriggerDAO extends BaseDAO<WTrigger> {

	public WTriggerDAO() {
		String collectionName = "wtrigger";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), WTrigger.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {		
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("friendlyId", 1);
		compoundIndex.put("channelId", 1);
		compoundIndex.put("preferredAccount", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
	}
	
	public long countByChannel(String channelId) {
		BasicDBObject query = new BasicDBObject();
		query.put("channelId", channelId);
		return getJCol().count(query);
	}
	
	public List<WTrigger> findCommonChannelTriggers(String channelId) {
		BasicDBObject orQuery = new BasicDBObject();
		List<BasicDBObject> orObj = new ArrayList<BasicDBObject>();
		orObj.add(new BasicDBObject("preferredAccount", null));
		orObj.add(new BasicDBObject("preferredAccount", ""));
		orQuery.put("$or", orObj);
		
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("channelId", channelId));
		
		obj.add(orQuery);
		
		andQuery.put("$and", obj);
		DBCursor<WTrigger> cursor = getJCol().find(andQuery);
		
		List<WTrigger> triggers = new ArrayList<WTrigger>();
		while(cursor.hasNext()) {
			triggers.add(cursor.next());
		}
		return triggers;
	}
	
	public List<WTrigger> findAccountChannelTriggers(String accountId, String channelId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("channelId", channelId));
		obj.add(new BasicDBObject("preferredAccount", accountId));
		
		andQuery.put("$and", obj);
		DBCursor<WTrigger> cursor = getJCol().find(andQuery);
		
		List<WTrigger> triggers = new ArrayList<WTrigger>();
		while(cursor.hasNext()) {
			triggers.add(cursor.next());
		}
		return triggers;
	}
	
}
