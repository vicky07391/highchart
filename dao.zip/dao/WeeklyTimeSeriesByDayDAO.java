package com.crucialbits.cy.dao;


import org.mongojack.JacksonDBCollection;
import com.crucialbits.app.AppProps;
import com.crucialbits.cy.model.WeeklyTimeSeriesByDay;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;

public class WeeklyTimeSeriesByDayDAO extends BaseDAO<WeeklyTimeSeriesByDay>{
	
	public WeeklyTimeSeriesByDayDAO() {
		String collectionName = "weeklytimeseriesbyday";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), WeeklyTimeSeriesByDay.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		
	}
	
}
