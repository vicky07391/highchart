package com.crucialbits.cy.dao;

import com.crucialbits.cy.model.WidgetSetting;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.bson.BSONObject;
import org.bson.types.ObjectId;
import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.cy.app.Constants.CustomerTaskPriority;
import com.crucialbits.cy.app.Constants.CustomerTaskStatus;
import com.crucialbits.cy.model.CustomerTask;
import com.crucialbits.cy.model.Meeting;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;


public class WidgetSettingDAO extends BaseDAO<WidgetSetting>{
	public WidgetSettingDAO() {
		String collectionName = "widgetsetting";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), WidgetSetting.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}

	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("widgetIdentifier", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
	}
	
	public List<WidgetSetting> findAllByWidgetIds(String accountId, String widgetIds, String widgetType) {
		List<ObjectId> ids = new ArrayList<ObjectId>();
		if(!StringHelper.isEmpty(widgetIds)) {
			for(String id : widgetIds.split(",")) {
				ids.add(new ObjectId(id));
			}
		}
		BasicDBObject query = new BasicDBObject();
		
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(widgetType)) {
			obj.add(new BasicDBObject("widgetType", Pattern.compile(widgetType, 2)));
		}
		if(!StringHelper.isEmpty(widgetIds)) {
			obj.add(new BasicDBObject("_id", new BasicDBObject("$in", ids)));
		}
		query.put("$and", obj);
		List<WidgetSetting> wss = new ArrayList<WidgetSetting>();
		DBCursor<WidgetSetting> cursor = getJCol().find(query);
		while(cursor.hasNext()) {
			wss.add(cursor.next());
		}
		return wss;
	}
	
}
