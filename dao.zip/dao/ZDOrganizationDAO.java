package com.crucialbits.cy.dao;

import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.client.zendesk.Organization;
import com.crucialbits.client.zendesk.User;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.mongodb.BasicDBObject;

public class ZDOrganizationDAO extends BaseDAO<Organization> {

	public ZDOrganizationDAO() {
		String collectionName = "zdorganization";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Organization.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("id", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("accountId", 1);
        compoundIndex3.put("id", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("fetchedAt", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("id", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("externalId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("groupId", 1), new BasicDBObject("background", true));
	}
	
	
}