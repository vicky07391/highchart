package com.crucialbits.cy.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.mongojack.DBCursor;
import org.mongojack.JacksonDBCollection;

import com.crucialbits.app.AppProps;
import com.crucialbits.client.zendesk.Priority;
import com.crucialbits.client.zendesk.Status;
import com.crucialbits.client.zendesk.Ticket;
import com.crucialbits.cy.app.Constants.IssuePriority;
import com.crucialbits.cy.app.Constants.IssueStatus;
import com.crucialbits.mongodb.BaseDAO;
import com.crucialbits.mongodb.Mongo;
import com.crucialbits.util.StringHelper;
import com.mongodb.BasicDBObject;

public class ZDTicketDAO extends BaseDAO<Ticket> {

	public ZDTicketDAO() {
		String collectionName = "zdticket";
		String dbName = AppProps.getInstance().getStringValue("databaseName");
		
		Mongo mongo = Mongo.getInstance();
		setDbName(dbName);
		setColName(collectionName);
		setCol(mongo.getDB(dbName).getCollection(collectionName));
		setJCol(JacksonDBCollection.wrap(getCol(), Ticket.class, String.class));
		
		if (!mongo.getIndexStatus(collectionName)) {
			buildIndexes();
			mongo.setIndexStatus(collectionName, true);
		}
	}
	
	public void buildIndexes() {
		BasicDBObject compoundIndex = new BasicDBObject();
		compoundIndex.put("id", 1);
		compoundIndex.put("accountId", 1);
		BasicDBObject options = new BasicDBObject("unique", true);
        options.put("background", true);
        
        getJCol().ensureIndex(compoundIndex, options);
        
        BasicDBObject compoundIndex2 = new BasicDBObject();
		compoundIndex2.put("accountId", 1);
		compoundIndex2.put("customerId", 1);
		BasicDBObject options2 = new BasicDBObject("background", true);
        getJCol().ensureIndex(compoundIndex2, options2);
        
        BasicDBObject compoundIndex3 = new BasicDBObject();
        compoundIndex3.put("accountId", 1);
        compoundIndex3.put("id", 1);
        getJCol().ensureIndex(compoundIndex3, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex4 = new BasicDBObject();
        compoundIndex4.put("accountId", 1);
        compoundIndex4.put("status", 1);
        compoundIndex4.put("customerId", 1);
        getJCol().ensureIndex(compoundIndex4, new BasicDBObject("background", true));
        
        BasicDBObject compoundIndex5 = new BasicDBObject();
        compoundIndex5.put("accountId", 1);
        compoundIndex5.put("status", 1);
        compoundIndex5.put("customerId", 1);
        compoundIndex5.put("created_at", 1);
        getJCol().ensureIndex(compoundIndex5, new BasicDBObject("background", true));
        
        getJCol().ensureIndex(new BasicDBObject("accountId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("fetchedAt", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("externalId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("type", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("priority", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("recipient", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("submitterId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("assigneeId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("customerId", 1), new BasicDBObject("background", true));
        getJCol().ensureIndex(new BasicDBObject("id", 1), new BasicDBObject("background", true));
	}
	
	public long countByStatusOrUser(String accountId, Status status, String requesterId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("status", status.toString()));
		if(!StringHelper.isEmpty(requesterId)) {
			obj.add(new BasicDBObject("requester_id", Integer.parseInt(requesterId)));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countAllOpenTicketsWithCustomerImpact(String accountId, String customerId, List<String> statusList, String type, String priority, List<String> customerIdsByManager, String recent) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIdsByManager != null && customerIdsByManager.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIdsByManager)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countAllOpenTicketsWithOutCustomerImpact(String accountId, List<String> statusList) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<Ticket> findAllOpenTicketsWithOutCustomerImpact(String accountId, List<String> statusList, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query).sort(new BasicDBObject("updated_at", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public List<Ticket> findAllOpenTicketsWithCustomerImpact(String accountId, String customerId, List<String> statusList, String type, String priority, List<String> customerIdsByManager, String recent, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIdsByManager != null && customerIdsByManager.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIdsByManager)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query).sort(new BasicDBObject("updated_at", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public List<Ticket> findAllOpenTicketsWithCustomerImpactAndDateRange(String accountId, String customerId, List<String> statusList, String type, String priority, List<String> customerIdsByManager, Date from, Date to, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIdsByManager != null && customerIdsByManager.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIdsByManager)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gte", from).append("$lte", new Date())));
		}
		
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query).sort(new BasicDBObject("updated_at", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public List<Integer> getDistinctUserIds(String accountId, String status) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", status.toLowerCase()));
		}
		query.put("$and", obj);
		
		return getJCol().distinct("requester_id", query);
	}
	
	public long countAllOpenTicketsByUser(String accountId, String status, Integer userId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", status.toLowerCase()));
		}
		obj.add(new BasicDBObject("requester_id", userId));
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countAllOpenTicketsByCustomer(String accountId, String status, String customerId, Date date) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("open")) {
			String[] statusArr = {Status.OPEN.toString(), Status.NEW.toString()};
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusArr)));
		} else if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", status.toLowerCase()));
		}
		obj.add(new BasicDBObject("customerId", customerId));
		
		if(date != null) {
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gte", date)));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<String> getDistinctStatus(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("status", query);
	}
	
	public List<String> getDistinctPriority(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("priority", query);
	}
	
	public List<String> getDistinctType(String accountId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		query.put("$and", obj);
		
		return getJCol().distinct("type", query);
	}
	
	public long countAllTicketsByCustomer(String accountId, String status, String priority, String type, String customerId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", customerId));
		if(!StringHelper.isEmpty(status)) {
			obj.add(new BasicDBObject("status", status));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countCustomerIssuesByDateRange(String accountId, String status, Date from, Date to, String customerId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		if(status != null) {
			obj.add(new BasicDBObject("status", status));
		}
		if(customerId != null) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(from != null && to != null) {
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gte", from).append("$lte", to)));
		}
		andQuery.put("$and", obj);
		return getJCol().count(andQuery);
	}
	
	public List<Long> findDistinctIssueIds(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		List<String> inList = new ArrayList<String>();
		inList.add(Status.NEW.toString());
		inList.add(Status.OPEN.toString());
		inList.add(Status.PENDING.toString());
		obj.add(new BasicDBObject("status", new BasicDBObject("$in", inList)));
		andQuery.put("$and", obj);
		return getJCol().distinct("id", andQuery);
	}
	
	public List<Ticket> findAllHighPriorityTickets(String accountId, Date from) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("priority", "high"));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(from != null) {
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gte", from).append("$lte", new Date())));
		}
		
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query);
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public long countAllTicketsByCreationDateRangeWithCustomer(String accountId, String customerId, Date from, Date to) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		obj.add(new BasicDBObject("customerId", customerId));
		if(from != null && to != null) {
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gte", from).append("$lte", new Date())));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public long countAllTicketsByDateRangeAndStatus(String accountId, String customerId, String status, Date from, Date to) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(!StringHelper.isEmpty(customerId)) {
			obj.add(new BasicDBObject("customerId", customerId));
		}
		if(from != null && to != null && !StringHelper.isEmpty(status) && status.equalsIgnoreCase("closed")) {
			obj.add(new BasicDBObject("updated_at", new BasicDBObject("$gte", from).append("$lt", new Date())));
		} else 
		if(from != null && to != null && !StringHelper.isEmpty(status) && status.equalsIgnoreCase("open")) {
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gte", from).append("$lt", new Date())));
		} else if(from != null && to != null && !StringHelper.isEmpty(status) && status.equalsIgnoreCase("solved")) {
			obj.add(new BasicDBObject("updated_at", new BasicDBObject("$gte", from).append("$lt", new Date())));
		}
		if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("open")) {
			String[] statusArr = {Status.OPEN.toString(), Status.NEW.toString()};
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusArr)));
		} else if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("closed")) {
			obj.add(new BasicDBObject("status", Status.CLOSED.toString()));
		} else if(!StringHelper.isEmpty(status) && status.equalsIgnoreCase("solved")) {
			obj.add(new BasicDBObject("status", Status.SOLVED.toString()));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<Ticket> findAllTicketsWithOutCustomerImpact(String accountId, List<String> statusList, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query).sort(new BasicDBObject("updated_at", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public List<Ticket> findTicketsForDashboard(String accountId, List<String> statusList, String type, String priority, 
			List<String> customerIds, String recent, int skip, int limit) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query).sort(new BasicDBObject("updated_at", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public long countAllTicketsForDashboard(String accountId, List<String> statusList, String type, String priority, 
			List<String> customerIds, String recent) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public List<Ticket> findAllTicketsForDashboard(String accountId, List<String> statusList, String type, String priority, 
			List<String> customerIds, String recent, int skip, int limit) {
		
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}
		if(customerIds != null && customerIds.size() > 0) {
			obj.add(new BasicDBObject("customerId", new BasicDBObject("$in", customerIds)));
		}
		if(!StringHelper.isEmpty(priority)) {
			obj.add(new BasicDBObject("priority", priority));
		}
		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(recent)) {
			Calendar cal = Calendar.getInstance();
	    	cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			cal.set(Calendar.MILLISECOND, 0);
			cal.add(Calendar.DATE, -1);
			obj.add(new BasicDBObject("created_at", new BasicDBObject("$gt", cal.getTime())));
		}
		
		query.put("$and", obj);
		
		List<Ticket> tickets = new ArrayList<Ticket>();
		DBCursor<Ticket> cursor = getJCol().find(query);
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public List<Ticket> findTickets(String accountId, List<String> statusList, String type, String requesterId, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
//		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}

		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(requesterId)) {
			obj.add(new BasicDBObject("requester_id", Integer.parseInt(requesterId)));
		}
		
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query).sort(new BasicDBObject("updated_at", -1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public long countTickets(String accountId, List<String> statusList, String type, String requesterId) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
//		obj.add(new BasicDBObject("customerId", new BasicDBObject("$exists", true)));
		
		if(statusList != null && statusList.size() > 0) {
			obj.add(new BasicDBObject("status", new BasicDBObject("$in", statusList)));
		}

		if(!StringHelper.isEmpty(type)) {
			obj.add(new BasicDBObject("type", type));
		}
		
		if(!StringHelper.isEmpty(requesterId)) {
			obj.add(new BasicDBObject("requester_id", Integer.parseInt(requesterId)));
		}
		
		query.put("$and", obj);
		return getJCol().count(query);
	}
	
	public Ticket findUnassignedTicketForDemoAccount(String accountId) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", null));
		
		andQuery.put("$and", obj);
		return getJCol().findOne(andQuery);
	}
	
	public List<Ticket> findUnknownTickets(String accountId, int skip, int limit) {
		BasicDBObject query = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", null));
		query.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(query).sort(new BasicDBObject("id", 1));
		if (skip > 0) {
			cursor.skip(skip);
		}
		if (limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
	
	public List<Ticket> findUnassignedTickets(String accountId, int skip, int limit) {
		BasicDBObject andQuery = new BasicDBObject();
		List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
		obj.add(new BasicDBObject("accountId", accountId));
		obj.add(new BasicDBObject("customerId", null));
		
		andQuery.put("$and", obj);
		DBCursor<Ticket> cursor = getJCol().find(andQuery).sort(new BasicDBObject("id", -1));
		if(skip > 0) {
			cursor.skip(skip);
		}
		if(limit > 0) {
			cursor.limit(limit);
		}
		List<Ticket> tickets = new ArrayList<Ticket>();
		while(cursor.hasNext()) {
			tickets.add(cursor.next());
		}
		return tickets;
	}
}